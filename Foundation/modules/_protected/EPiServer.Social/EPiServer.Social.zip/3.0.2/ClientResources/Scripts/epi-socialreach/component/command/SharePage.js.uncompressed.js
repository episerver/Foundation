﻿define([
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/Deferred",

// Epi Framework
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi-cms/_ContentContextMixin",

// Resource
    "epi/i18n!epi-cms/nls/socialreach.gadget"

], function (
// Dojo base
    declare,
    lang,
    Deferred,

// Epi Framework
    dependency,
    _Command,
    _ContentContextMixin,

// Resource
    res

    ) {

    // module:
    //      epi/socialreach/component/command/SharePage
    // summary:
    //      A command that opens the Outreach Panel.

    return declare([_Command, _ContentContextMixin], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.sharepagecommand,

        // modulePath: [public] String
        //      Path to the EPiServer.SocialReach module
        modulePath: null,

        // category: [readonly] String
        //      A category which provides a hint about how the command could be displayed.
        category: "setting",

        postscript: function () {
            this.inherited(arguments);

            this.set("canExecute", true);
        },

        _execute: function () {
            // summary:
            //      Executes this command; navigate to Outreach Panel
            // tags:
            //      protected

            Deferred.when(this.getCurrentContent(), lang.hitch(this, function (currentContent) {
                window.location.href = this.modulePath + "Outreach?contentLink=" + currentContent.contentLink;
            }));    // end deferred

        },

        _onModelChange: function () {
            // summary:
            //      set can execute for command when model changed
            // tags:
            //      protected
            var canSharePage = this.model.get("shareLinkEnable");
            this.set("canExecute", canSharePage);
        }
    });
});
