﻿define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",
    "dojo/string",
    "dojo/_base/Deferred",
    "dojo/DeferredList",
    "dojo/_base/xhr",

//EPi
    "epi/epi",
    "epi/datetime",
    "epi/dependency",
    "epi/shell/TypeDescriptorManager",

//CMS
    "epi-cms/ApplicationSettings",

    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/core/ContentReference",

// Resources
   "epi/i18n!epi-cms/nls/socialreach.gadget"
],

function (
// Dojo
    array,
    declare,
    lang,
    Stateful,
    dojoString,
    Deferred,
    DeferredList,
    xhr,

// EPi
    epi,
    epiDatetime,
    dependency,
    TypeDescriptorManager,

//CMS
    ApplicationSettings,
    _ContentContextMixin,
    ContentActionSupport,
    ContentReference,

// Resources
    res

    ) {

    // summary:
    //      View model object for the SocialReach widget.
    return declare([Stateful, _ContentContextMixin], {

        // store: [protected] Object
        //      Rest store for manipulate model data.
        store: null,

        // res: [protected] Object
        //      Localization resource using for the SocialReach widget.
        res: null,

        // messages: [protected] Array
        //      Contains list of message objects which sent along with a page.
        messages: null,

        // query: [protected] Object
        //      Query object contains query information of a specified page.
        query: null,

        // hasOutreachAccess: [protected] Boolean
        //      Determine if the current user has right to access to the module path [Outreach]
        hasOutreachAccess: false,

        postscript: function () {
            // summary:
            //      Initialize store and data displayed for page.
            // tags:
            //      protected

            this.inherited(arguments);

            this.res = this.res || res;

            var registry = dependency.resolve("epi.storeregistry");
            
            this.set("store", this.store || registry.get("epi-socialreach.message"));

            var self = this;
            var d1 = this._getModulePathAccess("Outreach");
            var d2 = new Deferred();
            d2.resolve(this.getCurrentContext());
            var dl = new DeferredList([d1, d2]);
            Deferred.when(dl, function (result) {
                self.hasOutreachAccess = result[0][1];
                if (!self.hasOutreachAccess) {
                    self.set("shareLinkEnable", false);
                    self.set("shareInfo", res.outreachdeniedmessage);
                    return;
                }
                self._fetchData(result[1][1]);
            });
        },

        contentContextChanged: function (context, callerData) {
            // summary:
            //      Fetching data when the context change.
            // tags:
            //      override

            if (!this.hasOutreachAccess) {
                return;
            }

            this.inherited(arguments);
            this._fetchData(context);
        },


        _getModulePathAccess: function (path) {
            // summary:
            //      Get access to the module path.
            // tags:
            //      private


            var def = new Deferred();
            xhr.get({
                url: this.modulePath + "/Settings/HasModulePathAccess/",
                content: { modulePath: path },
                handleAs: "json",
                load: function (data) {
                    def.resolve(data);
                }
            });

            return def.promise;
        },

        _isNotSupportContentType: function (context) {
            if (this.notSupportContentTypes) {
                return array.some(this.notSupportContentTypes, function (value, index) {
                    return TypeDescriptorManager.isBaseTypeIdentifier(context.dataType, value);
                });
            }

            return false;
        },

        _fetchData: function (context) {
            // summary:
            //      Get data from store depend on context and set properties for the model.
            // tags:
            //      private

            // always set query, show the grid will display empty for the content without shared messages.
            this.set("sharedMessageQuery", { "parent": context.id, "query": "getSharedMessages" });
            this.set("scheduledMessageQuery", { "parent": context.id, "query": "getScheduledMessages" });

            // hide schedule section as default
            this.set("scheduledNodeVisibility", false);
            // show the shared message node as default
            this.set("sharedMessageNodeVisibility", true);

            // show cannot be shared message for the not support content type
            if (!context.capabilities) {
                this.set("shareLinkEnable", false);
                // disable share link
                this.set("sharedInfo", res.cannotbeshared);
                // hide shared message node
                this.set("sharedMessageNodeVisibility", false);

                return;
            }

            if (this._isNotSupportContentType(context)) {
                this.set("shareLinkEnable", false);
                this.set("sharedInfo", res.cannotbeshared);
            }
            else {
                // We use this.getContentDataStore().refresh(context.id) instead of this.getCurrentContent()
                // to avoid cache then the contentData.status can be updated correctly.
                Deferred.when(this.getContentDataStore().refresh(context.id), lang.hitch(this, function (contentData) {

                    // query scheduled messages statistic from server
                    var queryScheduledStatistic = { "parent": context.id, "query": "getScheduledStatictis" };
                    Deferred.when(this.store.query(queryScheduledStatistic), lang.hitch(this, function (result) {
                        if (result.total > 0) {
                            var message = result.total == 1 ?
                                res.onescheduledshare : lang.replace(res.scheduledshares, result);
                            this.set("scheduledNodeVisibility", true);
                            this.set("scheduledInfo", message);
                        }
                    }));

                    // check if the current content can be visible for every one or not published yet,
                    // show the indicated message, and disable share link
                    if (!contentData.visibleToEveryOne
                        || contentData.isDeleted
                        || (contentData.status !== ContentActionSupport.versionStatus.Published && contentData.status !== ContentActionSupport.versionStatus.DelayedPublish)
                        ) {

                        this.set("shareLinkEnable", false);
                        var text = (!contentData.visibleToEveryOne || contentData.isDeleted) ? res.pagenotreadablebyeveryone : res.pagenotpublished;
                        this.set("sharedInfo", text);

                        return;
                    }

                    // show "cannot be shared message" when user selected container page (hasTemplate = false), root page or waste basket
                    var contentReference = new ContentReference(contentData.contentLink);
                    var pageId = contentReference.createVersionUnspecificReference().toString();


                    if (!contentData.hasTemplate || contentData.isWastebasket || pageId == ApplicationSettings.rootPage ||
                        this._isNotSupportContentType(context)) {
                        this.set("shareLinkEnable", false);
                        this.set("sharedInfo", res.cannotbeshared);
                        this.set("sharedMessageNodeVisibility", false);

                        return;
                    }

                    // query shared messages statistic from server
                    var querySharedStatistic = { "parent": context.id, "query": "getSharedStatictis" };
                    Deferred.when(this.store.query(querySharedStatistic), lang.hitch(this, function (result) {
                        var message = result.total == 0 ?
                            res.notsharedyet : result.total == 1 ?
                            res.sharedonetime : lang.replace(res.sharedtimes, { "total": result.total });
                        this.set("sharedInfo", message);
                        this.set("shareLinkEnable", true);
                    }));
                }));
            }
        }
    });
});