#region Copyright © 1997-2008 EPiServer AB. All Rights Reserved.
/*
This code may only be used according to the EPiServer License Agreement.
The use of this code outside the EPiServer environment, in whole or in
parts, is forbidden without prior written permission from EPiServer AB.

EPiServer is a registered trademark of EPiServer AB. For more information
see http://www.episerver.com/license or request a copy of the EPiServer
License Agreement by sending an email to info@episerver.com
*/
#endregion

using System;
using EPiServer.Core;
using EPiServer.Security;
using EPiServer.Web;
using EPiServer.UI;
using EPiServer.ServiceLocation;
using EPiServer.ChangeApproval.Core.Internal.Command;
using EPiServer.ChangeApproval.UI.Implementation;
using EPiServer.Framework.Localization;
using EPiServer.ChangeApproval.UI.Implementation.Internal;

namespace EPiServer.ChangeApproval.UI.UICustomization
{
    /// <summary>
    /// Summary description for Security.
    /// </summary>
    public partial class Security : SecurityBase
    {
        private Injected<SecuritySettingCommandService> _securitySettingCommandService;
        private Injected<LocalizationService> _localizationService;
        private Injected<ApprovalCommandService> _approvalCommandService;

        /// <summary>
        /// The flag used to indicate whether we should disable GUI.
        /// </summary>
        protected bool ShouldDisableUI = false;

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            /*
              This code segment is added by ChangeApproval
              1. if settings of this page have been changed by another person before, GUI of the security setting page is disabled
                 The variable ShouldDisableUI is a flag used to indicate whether we should disable GUI.
              2. The variable ShouldDisableUI is used by .aspx file to check whether the GUI is disabled.
              3. We will set up a message shown to users explaining why GUI should be disabled
              4.  IsInherited is disabled
              5. Disable SaveButton
              6. Disable RecursiveCheckbox
           */

            // check whether command is associated with a content link and it is in review status
            var approvalCommand = _approvalCommandService.Service.GetCommandByContentReferenceAssociatedWith(CurrentContent.ContentLink);

            if (approvalCommand != null)
            {
                var message = (approvalCommand is SecuritySettingCommand) ? _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/security") 
                                                                          : _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/general");
                message += $" {_securitySettingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContentLink.ToReferenceWithoutVersion(), true)}";

                DisableGUIForChangeApproval(message);
            }

            /*
             The code segment below is original code of the CMS team.
            */
            Page.Form.DefaultButton = UserGroupAddButton.UniqueID;

            if (!IsPostBack)
            {
                PopulateUserGroupList();
                UserGroupAddButton.Enabled = !ReadOnly;
            }
            SystemMessageContainer.Name = CurrentContent.Name;
            contentDataSource.DataBind();

            IsPageLeaveCheckEnabled = true;
        }

        /// <summary>
        /// Handles the Click event of the SaveButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void SaveButton_Click(object sender, EventArgs e)
        {
            try
            {

                if (CurrentContent.ContentLink.IsExternalProvider)
                {
                    SystemMessageContainer.Message = Translate("#notsupportedoperation");
                    PopulateUserGroupList();
                    return;
                }

                if (CurrentContent.ParentLink == SiteDefinition.Current.ContentAssetsRoot)
                {
                    SystemMessageContainer.Message = Translate("#cannoteditcontentassetfolder");
                    PopulateUserGroupList();
                    return;
                }

                AccessControlList acl = MergeAcl(sidList.PostedAcl);
                if (acl != null)
                {
                    acl.IsInherited = IsInherited.Checked;

                    CurrentContent.SaveSecurityInfo(ContentSecurityRepository, acl, SecuritySaveType.Replace);
                    if (RecursiveCheckbox.Checked)
                    {
                        CurrentContent.SaveSecurityInfo(ContentSecurityRepository, acl, acl.IsInherited ? SecuritySaveType.ReplaceChildPermissions : SecuritySaveType.MergeChildPermissions);
                    }

                    //Clear the current content to reload settings before populating the access rights list.
                    CurrentContent = null;
                    SystemMessageContainer.Message = Translate("#savemessage");
                }
            }
            catch (EPiServerException ex)
            {
                AddError(ex.Message);
            }

            PopulateUserGroupList();

            // if there is no approval sequence defined
            if (!_securitySettingCommandService.Service.IsContentLockedByChangeApproval(CurrentContent.ContentLink))
            {
                return;
            }

            /*
              ChangeApproval
              1. Set up the variable ShouldDisableUI to be true, meaning that GUI at client side will be disabled.
              2. Set up the message shown to users after GUI is disabled.
              3. Disable  IsInherited ;
              4. Disable RecursiveCheckbox;
              5. Disable SaveButton
            */
            var message = $"{_localizationService.Service.GetString("/episerver/changeapproval/interceptui/messagesentforreviewrequest")} {_securitySettingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContent.ContentLink, true)}";
            DisableGUIForChangeApproval(message);
        }

        /// <summary>
        /// Returns AccessLevel.
        /// </summary>
        /// <returns>AccessLevel</returns>
        public override AccessLevel RequiredAccess()
        {
            // This file should be protected by NTFS file access rights and/or URL access restrictions
            // I e the fact that the user can access this file should be enough to give them full access
            // to change access rights for pages.
            return AccessLevel.NoAccess;
        }



        /// <summary>
        /// Populates the user group list.
        /// </summary>
        private void PopulateUserGroupList()
        {
            var isReadOnly = ReadOnly || ShouldDisableUI; // code changed in ChangeApproval. ShouldDisableUI is set up as GUI is required to be disable.

            // Readonly is replaced by isReadOnly to disable GUI for ChangeApproval.
            sidList.ReadOnly = isReadOnly;  // Disable inhertied until proven in GetAclFromContent method that ACL can be inherited
            sidList.RenderAcl = GetAclFromContent();
            IsInherited.Checked = sidList.RenderAcl.IsInherited;
            IsInherited.Enabled = !isReadOnly && IsContentSecurable;
            RecursiveCheckbox.Enabled = !isReadOnly;
            sidList.DataBind();
        }

        /// <summary>
        /// Disable GUI because security settings of the page have been changed by another person before. Refer to PageLoad for more details of this function.
        /// </summary>
        /// <param name="msg"></param>
        private void DisableGUIForChangeApproval(string msg)
        {
            SystemMessageContainer.Message = msg;
            ShouldDisableUI = true;
            IsInherited.Enabled = false;
            RecursiveCheckbox.Enabled = false;
            SaveButton.Enabled = false;
        }
    }
}
