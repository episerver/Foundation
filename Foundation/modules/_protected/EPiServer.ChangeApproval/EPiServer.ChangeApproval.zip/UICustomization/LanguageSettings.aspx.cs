using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web.UI.WebControls;
using EPiServer.ChangeApproval.Core.Internal.Command;
using EPiServer.ChangeApproval.Core.Internal;
using EPiServer.ChangeApproval.UI.Implementation;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.Editor;
using EPiServer.Framework.Localization;
using EPiServer.Security;
using EPiServer.ServiceLocation;
using EPiServer.Shell.WebForms;
using EPiServer.ChangeApproval.UI.Implementation.Internal;

namespace EPiServer.ChangeApproval.UI.UICustomization
{
    /// <summary>
    /// Language settings class
    /// Handle render, modify, save the language setting.
    /// </summary>
    public partial class LanguageSettings : ContentWebFormsBase
    {
        private const int MaxFallbackColumns = 5;
        private IDictionary<string, ContentLanguageSetting> _settings;
        private int _fallbackColumns;

        private Injected<ILanguageBranchRepository> _languageBranchRepository;
        private Injected<ContentLanguageSettingRepository> _languageSettingsRepository;
        private Injected<LocalizationService> _localizationService;
        private Injected<LanguageSettingCommandService> _languageSettingCommandService;
        private Injected<IContentLanguageSettingsHandler> _contentLanguageSettingsHandler;

        private ILanguageBranchRepository LanguageBranchRepository { get { return _languageBranchRepository.Service; } }
        private ContentLanguageSettingRepository LanguageSettingsRepository { get { return _languageSettingsRepository.Service; } }

        private IDictionary<string, ContentLanguageSetting> Settings
        {
            get
            {
                if (_settings == null)
                {
                    _settings = new Dictionary<string, ContentLanguageSetting>();

                    IList<LanguageBranch> langBranches = LanguageBranchRepository.ListEnabled();

                    foreach (ContentLanguageSetting langSetting in _contentLanguageSettingsHandler.Service.Get(CurrentContent.ContentLink))
                    {
                        foreach (LanguageBranch lb in langBranches)
                        {
                            if (string.Compare(langSetting.LanguageBranch, lb.LanguageID, true) == 0)
                            {
                                _settings.Add(lb.LanguageID, langSetting);
                                break;
                            }
                        }
                    }
                }
                return _settings;
            }
        }

        private IDictionary<string, ContentLanguageSetting> cloneSettings;
        private Injected<ApprovalCommandService> _approvalCommandService;
        /// <summary>
        /// Gets a value indicating whether this page is opened in a wrapper dialog for Legacy.
        /// </summary>
		/// <remark>
		/// We still want to use some legacy dialogs (prior to CMS 6) in a DOJO-style dialog.
		/// The URL of legacy dialog provide to the DOJO dialog will have a parameter IsInLegacyWrapper=true
		/// </remark>
        /// <value>
        /// 	<c>true</c> if this page is opened in dialog; otherwise, <c>false</c>.
        /// </value>
        protected bool IsInLegacyWrapper
        {
            get
            {
                bool isOpenedInDialog = false;
                bool.TryParse(Request.QueryString["IsInLegacyWrapper"] ?? "false", out isOpenedInDialog);
                return isOpenedInDialog;
            }
        }

        /// <summary>
        /// Event when show the language settings popup
        /// </summary>
        /// <param name="e">The source of the event.</param>
        protected override void OnLoad(EventArgs e)
        {
            SystemMessageContainer.Heading = string.Format(Translate("#heading"), CurrentContent.Name == string.Empty ? "-" : CurrentContent.Name);

            var viewstateLanguageSettings = ViewState["LanguageSettings"];
            if (viewstateLanguageSettings != null)
            {
                cloneSettings = viewstateLanguageSettings.ToString().ToObject<IDictionary<string, ContentLanguageSetting>>();
            }

            base.OnLoad(e);

            bool currentPageAccess = true;
            ISecurable securableContent = CurrentContent as ISecurable;
            if (securableContent != null)
            {
                currentPageAccess = securableContent.GetSecurityDescriptor().HasAccess(PrincipalInfo.CurrentPrincipal, AccessLevel.Administer);
            }
            availableEditButton.Enabled = currentPageAccess;
            replacementEditButton.Enabled = currentPageAccess;
            fallbackEditButton.Enabled = currentPageAccess;

            if (!IsPostBack)
            {
                cloneSettings = Settings.ToJson().ToObject<IDictionary<string, ContentLanguageSetting>>();
                ReloadGui();
            }

            // check whether command is associated with a content link and it is in review status
            var approvalCommand = _approvalCommandService.Service.GetCommandByContentReferenceAssociatedWith(CurrentContent.ContentLink);

            if (approvalCommand != null)
            {
                var message = (approvalCommand is LanguageSettingCommand) ? _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/language") 
                                                                          : _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/general");
                DisableViewAndShowMessage($"{message} {_languageSettingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContent.ContentLink)}");
            }
        }

        /// <summary>
        /// Reload event
        /// Handle binding the data
        /// </summary>
        protected void ReloadGui()
        {
            _settings = null;//reload data
            ViewState["LanguageSettings"] = cloneSettings.ToJson();

            availableLanguages.DataSource = LanguageBranchRepository.ListEnabled().Select(l => new EncodedLanguage
            {
                Name = WebUtility.HtmlEncode(l.Name),
                LanguageID = l.LanguageID
            });
            availableLanguages.DataTextField = "Name";
            availableLanguages.DataValueField = "LanguageID";
            availableLanguages.DataBind();

            availableLanguagesList.DataSource = cloneSettings.Values.Where(setting => setting.IsActive);
            availableLanguagesList.DataBind();

            fallbackLanguagesList.DataSource = ListFallbackLanguages();
            fallbackLanguagesList.DataBind();

            replacementLanguagesList.DataSource = ListAvailableSettings(true);
            replacementLanguagesList.DataBind();

            var settingDefinedButNotSaved = cloneSettings.Values.Any(l => l.DefinedOnContent.Equals(CurrentContent.ContentLink));

            inheritSettings.Checked = !settingDefinedButNotSaved;
            if ((QueryAccess() & AccessLevel.Administer) == AccessLevel.Administer)
            {
                if (inheritSettings.Checked)
                {
                    inheritSettings.Attributes.Add("onclick", "if(!confirm('" + TranslateForScript("#addwarning") + "')){return false;}");
                }
                else
                {
                    inheritSettings.Attributes.Add("onclick", "if(!confirm('" + TranslateForScript("#deletewarning") + "')){return false;}");
                }
            }
            else
            {
                inheritSettings.Enabled = false;
            }

            var parent = _contentLanguageSettingsHandler.Service.Get(CurrentContent.ParentLink)?.FirstOrDefault()?.DefinedOnContent;

            availableEditButton.Visible = !inheritSettings.Checked || ContentReference.IsNullOrEmpty(parent);
            replacementEditButton.Visible = !inheritSettings.Checked || ContentReference.IsNullOrEmpty(parent);
            fallbackEditButton.Visible = !inheritSettings.Checked || ContentReference.IsNullOrEmpty(parent);

            if (!ContentReference.IsNullOrEmpty(parent))
            {
                inheritSettings.Text = string.Format(Translate("#inheritsettings"), ContentRepository.Get<IContent>(parent).Name);
            }
            else
            {
                inheritSettings.Visible = false;
            }

        }

        private ContentLanguageSetting LoadSettings(string langBranch)
        {
            ContentLanguageSetting settings;
            cloneSettings.TryGetValue(langBranch, out settings);
            return settings;
        }

        /// <summary>
        /// Get list of available settings
        /// </summary>
        /// <param name="hasReplacement"></param>
        /// <returns>list available settings</returns>
        protected IList ListAvailableSettings(bool hasReplacement)
        {
            ArrayList al = new ArrayList();

            foreach (ContentLanguageSetting setting in cloneSettings.Values)
            {
                if (setting.ReplacementLanguageBranch == null && !hasReplacement)
                {
                    al.Add(setting);
                }
                if (setting.ReplacementLanguageBranch != null && hasReplacement)
                {
                    al.Add(setting);
                }
            }
            return al;
        }

        /// <summary>
        /// Get list of available branches
        /// </summary>
        /// <param name="addEmpty"></param>
        /// <param name="hasReplacement"></param>
        /// <returns>list available branches</returns>
        protected IList ListAvailableBranches(bool addEmpty, bool hasReplacement)
        {
            ArrayList al = new ArrayList();
            if (addEmpty)
            {
                al.Add(new LanguageBranch());
            }
            foreach (ContentLanguageSetting setting in cloneSettings.Values)
            {
                if (setting.ReplacementLanguageBranch == null && !hasReplacement)
                {
                    al.Add(LanguageBranchRepository.Load(setting.LanguageBranch));
                }
                if (setting.ReplacementLanguageBranch != null && hasReplacement)
                {
                    al.Add(LanguageBranchRepository.Load(setting.LanguageBranch));
                }
            }
            return al;
        }

        /// <summary>
        /// Get language branch name
        /// </summary>
        /// <param name="branchID">branch id</param>
        /// <returns>Name of branch</returns>
        protected string GetBranchName(object branchID)
        {
            return LanguageBranchRepository.Load(branchID.ToString()).Name;
        }

        /// <summary>
        /// Handler for inheritSettings checkbox change
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void InheritChanged(object sender, EventArgs e)
        {
            RequireAdminister();

            if (inheritSettings.Checked)
            {
                availableEditButton.Visible = false;
                fallbackEditButton.Visible = false;
                replacementEditButton.Visible = false;

                ContentReference parent = _contentLanguageSettingsHandler.Service.GetClosestSetting(CurrentContent.ParentLink);
                cloneSettings = _languageSettingCommandService.Service.GetLanguageSettings(parent);
            }
            else
            {
                //saveLanguageButton.Enabled = true;
                foreach (ContentLanguageSetting setting in cloneSettings.Values)
                {
                    cloneSettings[setting.LanguageBranch].DefinedOnContent = CurrentContent.ContentLink;
                }
            }

            ReloadGui();
        }

        private void RequireAdminister()
        {
            ISecurable securableContent = CurrentContent as ISecurable;
            if (securableContent != null)
            {
                if (!securableContent.GetSecurityDescriptor().HasAccess(PrincipalInfo.CurrentPrincipal, AccessLevel.Administer))
                {
                    AccessDenied();
                }
            }
        }

        /// <summary>
        /// Change available languages handler
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void ChangeAvailableLanguages(object sender, EventArgs e)
        {
            availableEditButton.Enabled = false;
            replacementEditButton.Enabled = false;
            fallbackEditButton.Enabled = false;
            inheritSettings.Enabled = false;

            saveLanguageButton.Enabled = false;
            availableLanguagesView.Visible = false;
            availableLanguagesEdit.Visible = true;

            foreach (ListItem li in availableLanguages.Items)
            {
                if (li.Value.Length > 0)
                {
                    ContentLanguageSetting setting = LoadSettings(li.Value);
                    li.Selected = setting != null ? setting.IsActive : false;
                }
            }
        }

        /// <summary>
        /// Save available languages handler
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void SaveAvailableLanguages(object sender, EventArgs e)
        {
            RequireAdminister();

            foreach (ListItem li in availableLanguages.Items)
            {
                ContentLanguageSetting setting = null;

                if (li.Value.Length > 0)
                {
                    setting = LoadSettings(li.Value);
                }

                if (li.Selected)
                {
                    setting = setting == null ? new ContentLanguageSetting(CurrentContent.ContentLink, li.Value) : setting.CreateWritableClone();
                    setting.IsActive = true;
                    cloneSettings[setting.LanguageBranch] = setting;
                }
                else if (setting != null)
                {
                    setting = setting.CreateWritableClone();
                    setting.IsActive = false;
                    cloneSettings[setting.LanguageBranch] = setting;
                }
            }

            ReloadGui();

            inheritSettings.Enabled = true;
            availableLanguagesView.Visible = true;
            availableLanguagesEdit.Visible = false;
            saveLanguageButton.Enabled = true;
        }

        /// <summary>
        /// Setup the language dropdown
        /// </summary>
        /// <param name="languageBranch">language branch</param>
        /// <returns>html template of language dropdown</returns>
        protected string SetupLanguageDropDown(string languageBranch)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("<select name=\"Replacement-" + languageBranch + "\">");
            sb.Append("<option />");
            ContentLanguageSetting pls = LoadSettings(languageBranch);

            foreach (LanguageBranch lb in LanguageBranchRepository.ListEnabled())
            {
                if (languageBranch == lb.LanguageID)
                {
                    continue;
                }

                if (pls != null && pls.ReplacementLanguageBranch == lb.LanguageID)
                {
                    sb.Append("<option selected=\"selected\" value=\"" + lb.LanguageID + "\">" + Server.HtmlEncode(lb.Name) + "</option>");
                }
                else
                {
                    sb.Append("<option value=\"" + lb.LanguageID + "\">" + Server.HtmlEncode(lb.Name) + "</option>");
                }
            }
            sb.Append("</select>");

            return sb.ToString();
        }

        /// <summary>
        /// Change the replacement languages
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void ChangeReplacementLanguages(object sender, EventArgs e)
        {
            availableEditButton.Enabled = false;
            replacementEditButton.Enabled = false;
            fallbackEditButton.Enabled = false;
            inheritSettings.Enabled = false;

            saveLanguageButton.Enabled = false;
            replacementLanguagesView.Visible = false;
            replacementLanguagesEdit.Visible = true;

            replacementLanguages.DataSource = cloneSettings.Values;
            replacementLanguages.DataBind();
        }

        /// <summary>
        /// Save replacement languages
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void SaveReplacementLanguages(object sender, EventArgs e)
        {
            RequireAdminister();

            foreach (LanguageBranch lb in LanguageBranchRepository.ListEnabled())
            {
                string replacement = Request.Form["Replacement-" + lb.LanguageID];
                if (replacement == null)
                {
                    continue;
                }

                ContentLanguageSetting setting = LoadSettings(lb.LanguageID);
                if (setting == null && replacement.Length == 0)
                {
                    continue;
                }

                setting = setting == null ? new ContentLanguageSetting(CurrentContent.ContentLink, lb.LanguageID) : setting.CreateWritableClone();
                setting.ReplacementLanguageBranch = replacement.Length == 0 ? null : replacement;
                cloneSettings[setting.LanguageBranch] = setting;
            }

            inheritSettings.Enabled = true;
            replacementLanguagesView.Visible = true;
            replacementLanguagesEdit.Visible = false;
            saveLanguageButton.Enabled = true;

            ReloadGui();
        }

        /// <summary>
        /// Gets the number of fallback columns to display in the grid.
        /// </summary>
        /// <returns>number of fallback columns</returns>
        protected virtual int GetNumberOfFallbackColumns()
        {
            if (_fallbackColumns == 0)
            {
                //Make column show (availablebranches)- 1 since you can't fallback to yourself
                _fallbackColumns = Math.Min(MaxFallbackColumns, ListAvailableBranches(false, false).Count - 1);
            }
            return _fallbackColumns;
        }

        /// <summary>
        /// Render empty fallback columns
        /// </summary>
        /// <returns>html template of empty fallback columns</returns>
        protected string RenderEmptyFallbackColumns()
        {
            StringBuilder sb = new StringBuilder();

            var columns = GetNumberOfFallbackColumns();

            for (int i = 0; i < columns; i++)
            {
                sb.Append("<th>" + Translate("#fallbacklanguageheading") + " " + (i + 1).ToString() + "</th>");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Render the fallback language columns
        /// </summary>
        /// <param name="setting">the settings of fallback columns</param>
        /// <returns>html template of fallback columns</returns>
        protected string RenderFallbackColumns(object setting)
        {
            ContentLanguageSetting pls = (ContentLanguageSetting)setting;
            StringBuilder sb = new StringBuilder();

            var columns = GetNumberOfFallbackColumns();

            for (int i = 0; i < columns; i++)
            {
                sb.Append("<td>");
                sb.Append(SetupFallbackLanguageDropDown(pls.LanguageBranch, i));
                sb.Append("</td>");
            }
            return sb.ToString();
        }

        /// <summary>
        /// Setup fallback language dropdown
        /// </summary>
        /// <param name="languageBranch">language branch</param>
        /// <param name="index">index of fallback column</param>
        /// <returns>html template of fallback language dropdown</returns>
        protected string SetupFallbackLanguageDropDown(string languageBranch, int index)
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("<select name=\"Fallback-" + languageBranch + "\">");
            sb.Append("<option />");
            ContentLanguageSetting pls = LoadSettings(languageBranch);

            foreach (LanguageBranch lb in LanguageBranchRepository.ListEnabled())
            {
                if (languageBranch == lb.LanguageID)
                    continue;

                ContentLanguageSetting curSetting = LoadSettings(lb.LanguageID);
                if (curSetting == null || curSetting.ReplacementLanguageBranch != null)
                    continue;

                if (pls != null && pls.LanguageBranchFallback.Length > index && lb.LanguageID == pls.LanguageBranchFallback[index])
                    sb.Append("<option selected=\"selected\" value=\"" + lb.LanguageID + "\">" + Server.HtmlEncode(lb.Name) + "</option>");
                else
                    sb.Append("<option value=\"" + lb.LanguageID + "\">" + Server.HtmlEncode(lb.Name) + "</option>");
            }
            sb.Append("</select>");

            return sb.ToString();
        }

        /// <summary>
        /// Change fallback languages
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void ChangeFallbackLanguages(object sender, EventArgs e)
        {
            availableEditButton.Enabled = false;
            replacementEditButton.Enabled = false;
            fallbackEditButton.Enabled = false;
            inheritSettings.Enabled = false;

            saveLanguageButton.Enabled = false;
            fallbackLanguagesView.Visible = false;
            fallbackLanguagesEdit.Visible = true;

            fallbackLanguages.DataSource = ListAvailableSettings(false);
            fallbackLanguages.DataBind();
        }

        /// <summary>
        /// Save fallback languages
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void SaveFallbackLanguages(object sender, EventArgs e)
        {
            foreach (LanguageBranch lb in LanguageBranchRepository.ListEnabled())
            {
                string fallback = Request.Form["Fallback-" + lb.LanguageID];
                if (fallback == null)
                    continue;

                ContentLanguageSetting setting = LoadSettings(lb.LanguageID);
                if (setting == null)
                    continue;

                setting = setting.CreateWritableClone();

                if (fallback.Length == 0)
                    setting.LanguageBranchFallback = new string[] { };
                else
                {
                    ArrayList formList = new ArrayList(fallback.Split(','));
                    ArrayList saveList = new ArrayList();
                    for (int i = 0; i < formList.Count; i++)
                    {
                        if (formList[i].ToString().Length == 0)
                            continue;

                        if (!saveList.Contains(formList[i]))
                            saveList.Add(formList[i]);
                    }
                    setting.LanguageBranchFallback = (string[])saveList.ToArray(typeof(string));
                }
                cloneSettings[setting.LanguageBranch] = setting;
            }

            inheritSettings.Enabled = true;
            fallbackLanguagesView.Visible = true;
            fallbackLanguagesEdit.Visible = false;
            saveLanguageButton.Enabled = true;

            ReloadGui();
        }

        /// <summary>
        /// Event of cancel save the language settings
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void CancelSave(object sender, EventArgs e)
        {
            availableLanguagesView.Visible = true;
            availableLanguagesEdit.Visible = false;

            fallbackLanguagesView.Visible = true;
            fallbackLanguagesEdit.Visible = false;

            replacementLanguagesView.Visible = true;
            replacementLanguagesEdit.Visible = false;

            inheritSettings.Enabled = true;
            saveLanguageButton.Enabled = true;
        }

        /// <summary>
        /// Render fallback list
        /// </summary>
        /// <param name="setting"></param>
        /// <returns>html template of fallback list</returns>
        protected string RenderFallbackList(object setting)
        {
            string fallBack = LanguageBranchRepository.Load(((ContentLanguageSetting)setting).LanguageBranch).Name;
            foreach (string s in ((ContentLanguageSetting)setting).LanguageBranchFallback)
            {
                LanguageBranch lb = LanguageBranchRepository.Load(s);
                fallBack += " > " + (lb == null ? s : lb.Name);
            }
            return fallBack;
        }

        /// <summary>
        /// Get list of fallback languages
        /// </summary>
        /// <returns>list fallback language</returns>
        protected IList ListFallbackLanguages()
        {
            ArrayList al = new ArrayList();

            foreach (ContentLanguageSetting setting in cloneSettings.Values)
            {
                if (setting.LanguageBranchFallback.Length == 0)
                    continue;
                al.Add(setting);
            }
            return al;
        }

        /// <summary>
        /// Event when click cancel
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void Cancel_Click(object sender, EventArgs e)
        {
            Response.Redirect(PageEditing.GetEditUrl(CurrentContent.ContentLink));
        }

        private void HelpJoinArrayWithSelected(string[] selected, ListControl c)
        {
            foreach (ListItem l in c.Items)
            {
                foreach (string s in selected)
                    l.Selected |= s == l.Value;
            }
        }

        private string[] HelpJoinSelectedToArray(ListControl c)
        {
            ArrayList al = new ArrayList();

            foreach (ListItem l in c.Items)
            {
                if (l.Selected && l.Value.Length > 0)
                    al.Add(l.Value);
            }
            return (string[])al.ToArray(typeof(string));
        }

        private string HelpToNull(string val)
        {
            if (val == null || val.Length == 0)
                return null;
            return val;
        }

        private class EncodedLanguage
        {
            public string Name { get; set; }

            public string LanguageID { get; set; }
        }


        #region Functions for ChangeApproval

        /// <summary>
        /// Save the language settings
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">instance containing the event data.</param>
        protected void SaveLanguageSetting(object sender, EventArgs e)
        {
            // if no setting was changed, don't save the settings
            if (!IsSettingChanged())
            {
                return;
            }

            if (!cloneSettings.Any(l => l.Value.DefinedOnContent.Equals(CurrentContent.ContentLink)))
            {
                foreach (ContentLanguageSetting setting in Settings.Values)
                {
                    if (setting.DefinedOnContent == CurrentContent.ContentLink)
                    {
                        LanguageSettingsRepository.Delete(setting.DefinedOnContent, setting.LanguageBranch);
                    }
                }
            }
            else
            {
                foreach (ContentLanguageSetting lb in cloneSettings.Values)
                {
                    LanguageSettingsRepository.Save(lb);
                }
            }

            // id there is Approval sequence defined for this content then disable view
            if (_languageSettingCommandService.Service.IsContentLockedByChangeApproval(CurrentContent.ContentLink))
            {
                DisableViewAndShowMessage($"{_localizationService.Service.GetString("/episerver/changeapproval/interceptui/messagesentforreviewrequest")} {_languageSettingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContent.ContentLink)}");
                saveLanguageButton.Enabled = false;
            }
            else
            {
                if (IsInLegacyWrapper)
                {
                    // publish event so that the DialogWrapper know does it need to close the dialog when data was successfully saved
                    // "this" is the iframe (showing the legacy page)
                    // "this.parent" is the context of the dojo dialog wrapper
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "/IsInLegacyWrapper/NeedToBeCloseOnLoad", "this.parent.dojo.publish('/IsInLegacyWrapper/NeedToBeCloseOnLoad');", true);
                }
            }
        }

        private void DisableViewAndShowMessage(string message)
        {
            changeApprovalMessage.InnerHtml = message;
            changeApprovalMessage.Visible = true;

            saveLanguageButton.Enabled = false;
            inheritSettings.Enabled = false;
            availableEditButton.Enabled = false;
            fallbackEditButton.Enabled = false;
            replacementEditButton.Enabled = false;
        }

        private bool IsSettingChanged()
        {
            if (cloneSettings.Count != Settings.Count)
            {
                return true;
            }

            foreach (var contentLanguageSetting in Settings)
            {
                var key = contentLanguageSetting.Key;
                if (!cloneSettings.ContainsKey(key)) return true;

                var equal = contentLanguageSetting.Value.DefinedOnContent.CompareToIgnoreWorkID(cloneSettings[key].DefinedOnContent)
                            && contentLanguageSetting.Value.IsActive == cloneSettings[key].IsActive
                            && (contentLanguageSetting.Value.LanguageBranchFallback ?? new string[] { }).OrderBy(l => l).SequenceEqual((cloneSettings[key].LanguageBranchFallback ?? new string[] { }).OrderBy(l => l))
                            && (contentLanguageSetting.Value.ReplacementLanguageBranch ?? string.Empty).Equals(cloneSettings[key].ReplacementLanguageBranch ?? string.Empty);

                if (!equal) return true;
            }
            return false;
        }
        #endregion Functions for ChangeApproval
    }
}
