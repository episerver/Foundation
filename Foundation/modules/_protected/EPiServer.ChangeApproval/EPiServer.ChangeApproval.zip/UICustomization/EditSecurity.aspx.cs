#region Copyright © 1997-2007 EPiServer AB. All Rights Reserved.
/*
This code may only be used according to the EPiServer License Agreement.
The use of this code outside the EPiServer environment, in whole or in
parts, is forbidden without prior written permission from EPiServer AB.

EPiServer is a registered trademark of EPiServer AB. For more information
see http://www.episerver.com/license or request a copy of the EPiServer
License Agreement by sending an email to info@episerver.com
*/
#endregion

using System;
using System.Collections.Generic;
using EPiServer.ClientScript;
using EPiServer.Core;
using EPiServer.Security;
using EPiServer.UI.ClientScript.Events;
using EPiServer.ServiceLocation;
using EPiServer.ChangeApproval.Core.Internal.Command;
using EPiServer.ChangeApproval.UI.Implementation;
using EPiServer.UI;
using EPiServer.Framework.Localization;
using EPiServer.ChangeApproval.UI.Implementation.Internal;

namespace EPiServer.ChangeApproval.UI.UICustomization
{
    /// <summary>
    /// Summary description for EditSecurity.
    /// </summary>
    public partial class EditSecurity : SecurityBase
    {
        private Injected<SecuritySettingCommandService> _securitySettingCommandService;
        private Injected<LocalizationService> _localizationService;
        private Injected<ApprovalCommandService> _approvalCommandService;

        /// <summary>
        /// Indicate whether we have to disable GUI because security settings of the page have been changed by another person before.
        /// </summary>
        protected bool ShouldDisableUI { get; set; }

        /// <summary>
        /// Raises the <see cref="E:System.Web.UI.Control.Load"></see> event.
        /// </summary>
        /// <param name="e">The <see cref="T:System.EventArgs"></see> object that contains the event data.</param>
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            /*
               This code segment is added by ChangeApproval
               1. if settings of this page have been changed by another person before, GUI of the security setting page is disabled
                  The variable ShouldDisableUI is a flag used to indicate whether we should disable GUI.
               2. The variable ShouldDisableUI is used by .aspx file to check whether the GUI is disabled.
               3. We will set up a message shown to users explaining why GUI should be disabled
               4. Disable IsInherited
               5. Disable RecursiveCheckbox
               6. Disable SaveButton
            */

            // check whether command is associated with a content link and it is in review status
            var approvalCommand = _approvalCommandService.Service.GetCommandByContentReferenceAssociatedWith(CurrentContent.ContentLink);

            if (approvalCommand != null)
            {
                var message = (approvalCommand is SecuritySettingCommand) ? _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/security") 
                                                                          : _localizationService.Service.GetString("/episerver/changeapproval/interceptui/ongoingapprovalmessages/general");
                message += $" {_securitySettingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContentLink.ToReferenceWithoutVersion())}";
                DisableGUIForChangeApproval(message);
            }

            /*
              The code segment below is original code of the CMS team.
             */
            RegisterClientScriptFile(UriSupport.ResolveUrlFromUIBySettings("javascript/membershipaccesslevel.js"));

            if (!IsPostBack)
            {
                PopulateUserRoleList();
                UserGroupAddButton.Enabled = !ReadOnly;
            }

            PopulateRolesList();
            SystemMessageContainer.Name = CurrentContent.Name;

            if (Context.User != null)
            {
                RoleInfo.StringFormatObjects = new object[] { Context.User.Identity.Name };
            }

            //Register event that checks if the save button is clicked. This is done in order
            //to check if the reload comes from clicking the save button or not.
            string saveAccessButtonClicked = string.Format("button = document.getElementById('{0}');\nif(button != null)\n{{\n\tEPi.AddEventListener(button, 'click', onClick );}}", SaveButton.ClientID);

            Page.ClientScript.RegisterStartupScript(GetType(), "SaveAccessRights", saveAccessButtonClicked, true);

            IsPageLeaveCheckEnabled = true;
        }

        /// <summary>
        /// Handles the Click event of the SaveButton control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void SaveButton_Click(object sender, EventArgs e)
        {
            HandleSaveForm(SecuritySaveType.Replace, null);
        }

        /// <summary>
        /// Populates the user/role list.
        /// </summary>
        private void PopulateUserRoleList()
        {
            //In order to re-read the access rights for page
            CurrentContent = null;
            if (ReadOnly)
            {
                sidList.ReadOnly = true;
                IsInherited.Enabled = false;
                IsInherited.CssClass += " epi-disabled";
            }
            sidList.RenderAcl = new AccessControlList(CurrentContent.ToRawACEArray());
            IContentSecurable securable = CurrentContent as IContentSecurable;
            if (securable != null)
            {
                IsInherited.Checked = securable.GetContentSecurityDescriptor().IsInherited;
            }
            sidList.DataBind();
        }

        /// <summary>
        /// Populates the roles list.
        /// </summary>
        private void PopulateRolesList()
        {
            ICollection<string> roleList = PrincipalInfo.Current.RoleList;
            if (roleList == null)
            {
                return;
            }
            ListRoles.DataSource = roleList;
            ListRoles.DataBind();
        }

        /// <summary>
        /// Handles the save form.
        /// </summary>
        /// <param name="saveType">Type of the save.(SecuritySaveType)</param>
        /// <param name="acl">The AccessControlList.</param>
        private void HandleSaveForm(SecuritySaveType saveType, AccessControlList acl)
        {
            var saved = false;
            try
            {
                // Always needs to merge posted ACL with ACL from content, otherwise we will loose the existing ACL when saving
                acl = acl ?? MergeAcl(sidList.PostedAcl);
                ContentAccessControlList postedAcl = new ContentAccessControlList(CurrentContent.ContentLink, acl);
                postedAcl.IsInherited = IsInherited.Checked;

                //Checks so we dont remove permissions for current user to administer this page.
                if (CheckACLForPermission(postedAcl, RequiredAccess()))
                {
                    CurrentContent.SaveSecurityInfo(ContentSecurityRepository, postedAcl, saveType);
                    SystemMessageContainer.Message = Translate("#savemessage");
                    saved = true;
                }
                else
                {
                    SystemMessageContainer.Message = Translate("#aclremovepermissionrights");
                }
            }
            catch (EPiServerException ex)
            {
                AddError(ex.Message);
            }
            PopulateUserRoleList();
            /*
              The code segment below is added for ChangeApproval. It will disable the GUI at client side, show the message to users after GUI is disabled, and prevent the
              dialog from being closed as normal after users click on the save button.

               1. if settings of this page have been changed by another person before, GUI of the security setting page is disabled
                  The variable ShouldDisableUI is a flag used to indicate whether we should disable GUI.
               2. The variable ShouldDisableUI is used by .aspx file to check whether the GUI is disabled.
               3. We will set up a message shown to users explaining why GUI should be disabled
               4. Disable IsInherited
               5. Disable RecursiveCheckbox
               6. Disable SaveButton
           */
            if (saved && _securitySettingCommandService.Service.IsContentLockedByChangeApproval(CurrentContent.ContentLink))
            {
                var message = _localizationService.Service.GetString("/episerver/changeapproval/interceptui/messagesentforreviewrequest");
                message += $" {_securitySettingCommandService.Service.GenerateApprovalCommandDetailLink(CurrentContent.ContentLink)}";
                DisableGUIForChangeApproval(message);
                return; // Prevent the dialog from being closed as normal after users click on the save button.
            }

            /*
              original code of CMS
             */
            if (saved)
            {
                // When this page is openned in Legacy Dialog Wrapper,
                // It is needed to close the dialog when user successfully save the access rights
                if (IsInLegacyWrapper)
                {
                    // publish event so that the DialogWrapper know does it need to close the dialog when data was successfully saved (and when receiving response from this page)
                    // "this" is the iframe (showing the legacy page)
                    // "this.parent" is the context of the dojo dialog wrapper
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "/IsInLegacyWrapper/NeedToBeCloseOnLoad",
                        string.Format("this.parent.dojo.publish('/IsInLegacyWrapper/NeedToBeCloseOnLoad', [{{type: 'success', message: '{0}'}}]);", Translate("/edit/editsecurity/saved")),
                        true);
                }
                // In old edit mode, we need to nofify other frames about the PageUpdated event.
                else
                {
                    // Send PageUpdated event to other frames
                    ScriptManager.AddEventListener(this, new CommandEvent(EventType.Load, CommandEvent.CommandType.PageUpdated, null, CurrentContent.ContentLink.ToString()));
                }
            }
        }

        /// <summary>
        /// Checks so we dont remove permissions for current user to administer current page.
        /// </summary>
        /// <param name="postedAcl">The posted PageAccessControlList.</param>
        /// <param name="accessLevel"></param>
        /// <remarks>Merge current ACL and posted ACL and checks that current user has rights to administer current page.</remarks>
        private bool CheckACLForPermission(ContentAccessControlList postedAcl, AccessLevel accessLevel)
        {
            AccessControlList mergedAcl = new AccessControlList(postedAcl);
            IContentSecurable securableContent = CurrentContent as IContentSecurable;
            if (securableContent != null)
            {
                IContentSecurityDescriptor csd = securableContent.GetContentSecurityDescriptor();
                if (csd != null)
                {
                    foreach (AccessControlEntry entry in csd.Entries)
                    {
                        if (!mergedAcl.Contains(entry.Name))
                        {
                            AccessControlEntry newEntry = new AccessControlEntry(entry.Name, entry.Access, entry.EntityType);
                            mergedAcl.Add(newEntry);
                        }
                    }
                }
            }
            //We check so we dont take away rights you need to have for this page.
            if (!mergedAcl.QueryDistinctAccess(accessLevel))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Editing the access rights requires Admin rights
        /// </summary>
        /// <returns>AccessLevel</returns>
        public override AccessLevel RequiredAccess()
        {
            return AccessLevel.Administer;
        }

        /// <summary>
        /// Gets a value indicating whether this page is opened in a wrapper dialog for Legacy.
        /// </summary>
        /// <remark>
        /// We still want to use some legacy dialogs (prior to CMS 6) in a DOJO-style dialog.
        /// The URL of legacy dialog provide to the DOJO dialog will have a parameter IsInLegacyWrapper=true
        /// </remark>
        /// <value>
        /// 	<c>true</c> if this page is opened in dialog; otherwise, <c>false</c>.
        /// </value>
        protected bool IsInLegacyWrapper
        {
            get
            {
                bool isOpenedInDialog = false;
                bool.TryParse(Request.QueryString["IsInLegacyWrapper"] ?? "false", out isOpenedInDialog);
                return isOpenedInDialog;
            }
        }

        /// <summary>
        /// Disable GUI because security settings of the page have been changed by another person before. Refer to PageLoad for more details of this function.
        /// </summary>
        /// <param name="msg"></param>
        private void DisableGUIForChangeApproval(string msg)
        {
            SystemMessageContainer.Message = msg;
            ShouldDisableUI = true;
            IsInherited.Enabled = false;
            SaveButton.Enabled = false;
        }
    }
}
