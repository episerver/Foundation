define("epi-changeapproval/command/_ChangeApprovalCommand", [
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/dom-construct",
    "dojo/topic",
    "dojo/when",
    "dojo/_base/lang",

    "epi/dependency",

    // Parent class and mixins
    "epi/shell/command/_Command",
    "epi/shell/widget/ValidationTextarea",
    "epi-cms/contentediting/command/_CommandWithDialogMixin",

    "epi-changeapproval/ModuleSettings"
], function (
    declare,
    Deferred,
    domConstruct,
    topic,
    when,
    lang,

    dependency,

    // Parent class and mixins
    _Command,
    ValidationTextarea,
    _CommandWithDialogMixin,

    ModuleSettings
) {

    return declare([_Command, _CommandWithDialogMixin], {
        // summary:
        //      Base class approval transitions that might need a comment
        // tags:
        //      internal

        // dialogContentClass: [readonly] ValidationTextarea
        //      Input field for the approve comment
        dialogContentClass: ValidationTextarea,

        dialogClass: "epi-dialog-confirm",

        // executeMethod: [readonly] String
        //      The method to execute on the approval service
        executeMethod: null,

        // isCommentRequiredPropertyName: [readonly] String
        //      The name of the property to look at to determine if a comment is required
        isCommentRequiredPropertyName: null,

        // dialogPlaceHolder: String
        //      Placeholder text for the text area
        dialogPlaceHolder: null,

        // dialogText: String
        //      Text to be displayed above text area, if any
        dialogText: null,

        // contextHistory: [readonly] epi-cms/BackContextHistory
        //      The context history
        contextHistory: null,

        postscript: function () {
            this.inherited(arguments);

            this.changeApprovalService = this.changeApprovalService || dependency.resolve("epi-changeapproval.changeapprovalservice");
            this.contextHistory = this.contextHistory || dependency.resolve("epi.cms.BackContextHistory");

            this.dialogContentParams = {
                required: true,
                intermediateChanges: true,
                placeHolder: this.dialogPlaceHolder,
                "class": "epi-textarea--max-height--500"
            };
        },

        _canExecuteGetter: function () {
            // summary:
            //      Check content is deleted or not
            // tags:
            //      protected

            if (!this.model) {
                return false;
            }

            return this.model.canExecute;
        },

        _onModelChange: function () {
            // summary:
            //      Get the approval so its available when we execute the command
            // tags:
            //      protected

            this.set("canExecute", false);

            if (!this.model) {
                return;
            }

            this.set({
                canExecute: !!this.model.canExecute
            });
        },

        _execute: function () {
            return this.changeApprovalService.getApprovalRelatedDefinition(this.model.appliedOnContent)
                .then(function (approvalDefinition) {
                    if (approvalDefinition[this.isCommentRequiredPropertyName]) {
                        this._executeDeferred = new Deferred();
                        this.showDialog();
                        return this._executeDeferred.promise;
                    } else {
                        return this._executeServiceMethod();
                    }
                }.bind(this));
        },

        showDialog: function () {
            this.inherited(arguments);

            this._disableActionButton(true);

            if (this.dialogText && typeof this.dialogText === "string") { // Add text, if any, above the comment text area
                domConstruct.place("<p>" + this.dialogText + "</p>", this.dialogContent.domNode, "before");
            }

            this._dialog.own(this.dialogContent.on("change", this._onDialogContentChanged.bind(this)));
        },

        _onDialogContentChanged: function (value) {
            // summary:
            //      Called when the dialog content is changed.
            // tags:
            //      private

            this._disableActionButton(!value || !(value.trim()));
        },

        _disableActionButton: function (disable) {
            // summary:
            //      Disables the confirm button if the disable parameter is true.
            // tags:
            //      private

            this._dialog.onActionPropertyChanged({ name: this._dialog._okButtonName }, "disabled", disable);
        },

        onDialogExecute: function () {
            // summary:
            //      Resolves the execute promise after the dialog is executed.
            // tags:
            //      public virtual

            this._executeDeferred.resolve(this._executeServiceMethod.call(this, this.dialogContent.value));
        },

        onDialogCancel: function () {
            // summary:
            //      Rejects the execute promise after the dialog is canceled.
            // tags:
            //      public virtual

            this._executeDeferred.reject();
        },

        _executeServiceMethod: function (reason) {
            return this.changeApprovalService[this.executeMethod](this.model.id, reason)
                .then(this._onApprovalChange.bind(this));
        },

        _onApprovalChange: function () {
            // summary:
            //      Callback which updates the context after the approval command status has been changed.
            // tags:
            //      protected

            this.approvalCommandStore = this.approvalCommandStore || dependency.resolve("epi.storeregistry").get("epi-changeapproval.commanddata");

            when(this.approvalCommandStore.query({ id: this.model.approvalID }), lang.hitch(this, function (command) {
                if (!command) {

                    // when moving content between providers the source content and its command will be deleted 
                    // in this case we close change details view and navigate back to previous view
                    this.contextHistory.closeAndNavigateBack(this);

                    // Moving between providers causes changing ID of content => refresh the destination content to see the changes
                    if (this._getCommandType() === "movingcontentcommand") {
                        this._refreshHierarchicalTree(this.model.appliedOnContent);
                        var destination = JSON.parse(this.model.newSettingsJson).Destination;
                        this._refreshHierarchicalTree(destination);
                    }
                    return;
                }

                var contextParameters = { uri: "epi.cms.changeapproval:///" + this.model.approvalID };
                var callerData = {
                    sender: this,
                    trigger: "internal",
                    forceContextChange: true,
                    forceReload: this.forceReload
                };

                topic.publish("/epi/shell/context/request", contextParameters, callerData);

                if (this._getCommandType() === "movingcontentcommand" && command.status === ModuleSettings.approvalStatus.ACCEPTED) {
                    this._refreshHierarchicalTree(command.appliedOnContent);
                }
            }));
        },

        _refreshHierarchicalTree: function (contentLink) {
            // summary:
            //      Update page/block tree to see the changes
            // tags:
            //      private
            topic.publish("/epi/cms/contentdata/updated", {
                contentLink: contentLink,
                recursive: true
            });
        },

        _getCommandType: function () {
            // summary:
            //      Get type of current command
            // tags:
            //      private
            if (!this.model) {
                return "";
            }

            var typeIdentifiers = this.model.typeIdentifier.split(".");
            return typeIdentifiers[typeIdentifiers.length - 1];
        }
    });
});
