define("epi-changeapproval/widget/ExpirationChangeDetailsView", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",

    "epi/dependency",
    "epi-cms/core/ContentReference",

    "./ApprovalCommandDetailsView",
    "epi-changeapproval/widget/dgrid/Formatter",
    "epi/i18n!epi/cms/nls/episerver.changeapproval.expirationdatesettingcommand"
], function (
    declare,
    lang,
    when,

    dependency,
    ContentReference,

    ApprovalCommandDetailsView,
    formatters,
    res
) {

    return declare([ApprovalCommandDetailsView], {
        // summary:
        //      Display the change details of expiration date
        // tags:
        //      internal

        _renderNameItem: function (item, value, node) {
            node.innerText = res[value];
        },

        _renderValueItem: function (item, value, node) {
            if (!value) {
                return ;
            }

            if (item.name === "pagearchivelink") {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = this.store || registry.get("epi.cms.content.light");
                var currentContentReference = new ContentReference(value),
                    currentContentId = currentContentReference.createVersionUnspecificReference().toString();
                when(this.store.get(currentContentId), lang.hitch(this, function (result) {
                    if (result.name) {
                        return formatters.breadcrumbFormatter(value, node, { displayAsText: true, showCurrentNode: true });
                    }
                    return formatters.breadcrumbFormatter(null, node, { displayAsText: true, showCurrentNode: true }, res.contentnotavailable);
                }));
            }

            if (item.name === "pagestoppublish") {
                return formatters.dateTimeFormatter(value, node);
            }
        }
    });
});
