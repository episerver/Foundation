define("epi-changeapproval/notification/InReviewNotification", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/Stateful",

    // addon
    "epi-changeapproval/command/ViewChangeDetails",

    // epi
    "epi/shell/command/_Command",
    "epi/dependency",
    "epi/i18n!epi/cms/nls/episerver.changeapproval.inreviewmessagebar"

], function (
    // dojo
    declare,
    lang,
    Stateful,

    // addon
    ViewChangeDetails,

    // epi
    _Command,
    dependency,
    res
) {

        return declare([Stateful], {
            // summary:
            //      Notification when content has settings awaiting for approval
            // tags:
            //      internal

            _viewChangeDetailCommand: null,

            postscript: function () {
                this.inherited(arguments);
                this.changeApprovalService = this.changeApprovalService || dependency.resolve("epi-changeapproval.changeapprovalservice");
            },

            _createViewChangeDetailsLink: function (changeApprovalCommand) {
                var viewChangeDetailCommand = new ViewChangeDetails();
                viewChangeDetailCommand.set("model", changeApprovalCommand);

                this._viewChangeDetailCommand = viewChangeDetailCommand;
            },

            _getNotificationText: function (changeApprovalCommand) {
                var typeIdentifiers = changeApprovalCommand.typeIdentifier.split(".");
                var commandType = typeIdentifiers[typeIdentifiers.length - 1];

                switch (commandType) {
                    case "securitysettingcommand": return res.securitysettingcommand;
                    case "languagesettingcommand": return res.languagesettingcommand;
                    case "movingcontentcommand": return res.movingcontentcommand;
                    case "expirationdatesettingcommand":
                        var message = res.expirationdatesettingcommand;
                        var languageBranch = changeApprovalCommand.appliedOnLanguageBranch;
                        message = lang.replace(message, {
                            language: languageBranch ? languageBranch.toUpperCase() : ""
                        });
                        return message;
                    default: return "";
                }
            },

            _valueSetter: function (value) {
                // summary:
                //      Updates the notification when the property/contentData or context changes
                // value: Object
                // tags:
                //      private

                this.value = value;

                // Set the notification if content has a pending Change Approval command. Otherwise unset it
                this.changeApprovalService.getPendingApprovalCommand(this.value.contentData.contentLink)
                    .then(function (pendingCommand) {

                        if (pendingCommand) {
                            this._createViewChangeDetailsLink(pendingCommand);

                            // The content for the notification can either be a domNode or a string
                            // To add commands to the notification, push them to the commands property
                            this.set("notification", {
                                content: this._getNotificationText(pendingCommand),
                                commands: [this._viewChangeDetailCommand]
                            });
                        }
                        else {
                            this._viewChangeDetailCommand = null;
                            this.set("notification", { });
                        }
                    }.bind(this));
            }
        });

    });
