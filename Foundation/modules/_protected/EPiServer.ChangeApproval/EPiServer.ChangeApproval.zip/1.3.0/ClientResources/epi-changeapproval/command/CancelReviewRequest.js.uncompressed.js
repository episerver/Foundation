define("epi-changeapproval/command/CancelReviewRequest", [
     "dojo/_base/declare",
    "./_ChangeApprovalCommand",
    "epi/i18n!epi/cms/nls/episerver.changeapproval.command.cancel"
], function (
    declare,
    _ChangeApprovalCommand,
    localization
) {

    return declare([_ChangeApprovalCommand], {
        // summary:
        //      Approve the current approval
        // tags:
        //      internal

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: localization.label,

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconClose",

        // executeMethod: [readonly] String
        //      The method to execute on the approval service
        executeMethod: "cancel"
    });
});
