define("epi-changeapproval/widget/viewmodels/ApprovalCommandViewModel", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/Deferred",
    "dojo/Stateful",
    "dojo/when",
// epi
    "epi/shell/DestroyableByKey",
    "epi/dependency",
    "epi/shell/ViewSettings",
// epi-cms
    "epi-cms/_ContentContextMixin"
],
function (
// dojo
    declare,
    lang,
    topic,
    Deferred,
    Stateful,
    when,

// epi
    DestroyableByKey,
    dependency,
    ViewSettings,

// epi-cms
    _ContentContextMixin
) {

    return declare([Stateful, DestroyableByKey, _ContentContextMixin], {
        // tags:
        //      internal

        getCommand: function () {
            // summary:
            //      Get the change command of current context
            // tags:
            //      internal

            var def = new Deferred();
            this._store = this._store || dependency.resolve("epi.storeregistry").get("epi-changeapproval.commanddata");
            when(this.getCurrentContext(), lang.hitch(this, function (context) {
                when(this._store.query({ id: context.id }), function (command) {
                    def.resolve(command);
                });
            }));

            return def;
        }
    });
});
