define("epi-changeapproval/widget/MovingContentCommandView", [
    "dojo/_base/declare",
    "./ApprovalCommandDetailsView",
    "epi-changeapproval/widget/dgrid/Formatter",

// resources
    "epi/i18n!epi/cms/nls/episerver.changeapproval.movingcontentcommand"
], function (
    declare,
    ApprovalCommandDetailsView,
    formatters,
    res
) {
    return declare([ApprovalCommandDetailsView], {
        // summary:
        //      Display the change details of moving command  
        // tags:
        //      internal

        _renderValueItem: function (item, value, node) {
            return formatters.breadcrumbFormatter(value, node, { displayAsText: true, showCurrentNode: true, showLastBracket: true }, res.contentnotavailable);
        }
    });
});
