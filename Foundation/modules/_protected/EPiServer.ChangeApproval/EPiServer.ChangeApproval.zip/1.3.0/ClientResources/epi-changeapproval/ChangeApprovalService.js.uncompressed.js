define("epi-changeapproval/ChangeApprovalService", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/Deferred",
    "dojo/Stateful",
    "dojo/when",

// epi
    "epi/shell/DestroyableByKey",
    "epi/shell/xhr/errorHandler",
    "epi/dependency",
    "epi/shell/ViewSettings",

// epi-cms
    "epi-cms/core/ContentReference",
    "epi-cms/_ContentContextMixin"
],
function (
// dojo
    declare,
    lang,
    topic,
    Deferred,
    Stateful,
    when,

// epi
    DestroyableByKey,
    errorHandler,
    dependency,
    ViewSettings,

// epi-cms
    ContentReference,
    _ContentContextMixin
) {

    return declare([Stateful, DestroyableByKey, _ContentContextMixin], {
        // summary:
        //      manipulate change approval data
        // tags:
        //      internal

        store: null,
        approvalStore: null,
        postscript: function () {
            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this.approvalDefinitionStore = this.approvalDefinitionStore || registry.get("epi-changeapproval.definition");
            this.store = this.store || registry.get("epi-changeapproval.commanddata");
            this.approvalStore = this.approvalStore || registry.get("epi-changeapproval.changeapproval");
        },

        approve: function (commandId, reason) {
            // summary:
            //      Approve the current command.
            // tags:
            //      public
            return errorHandler.wrapXhr(this.store.executeMethod("Approve", null, { commandId: commandId, reason: reason }));
        },

        decline: function (commandId, reason) {
            // summary:
            //      Decline the current command.
            // tags:
            //      public
            return errorHandler.wrapXhr(this.store.executeMethod("Decline", null, { commandId: commandId, reason: reason }));
        },

        cancel: function (commandId) {
            // summary:
            //      Cancel the current command.
            // tags:
            //      public
            return errorHandler.wrapXhr(this.store.executeMethod("Cancel", null, { commandId: commandId }));
        },

        forceCompleteApproval: function (commandId, forceReason) {
            // summary:
            //      Force completes an approval instance as approved.
            // tags:
            //      public
            return errorHandler.wrapXhr(this.store.executeMethod("ForceComplete", null, { commandId: commandId, forceReason: forceReason }));
        },

        getApprovalRelatedDefinition: function (contentLink) {
            var def = new Deferred();

            when(this.approvalDefinitionStore.query({ id: contentLink, getApprovalRelatedDefinition: true }))
            .then(function (approvalDefinition) {
                def.resolve(approvalDefinition);
            }).otherwise(function () {
                def.resolve(null);
            });

            return def;
        },

        getPendingApprovalCommand: function (contentLink) {
            // summary:
            //      Get pending Change Approval command for a content if existed
            // tags:
            //      public

            return this.store.executeMethod("GetPendingApprovalCommand", null, { contentLink: contentLink });
        },

        getApproval: function (contentLink) {
            // summary:
            //      Get Change Approval associated with the content link
            // tags:
            //      public

            return this.approvalStore.query({ id: contentLink });
        }
    });
});
