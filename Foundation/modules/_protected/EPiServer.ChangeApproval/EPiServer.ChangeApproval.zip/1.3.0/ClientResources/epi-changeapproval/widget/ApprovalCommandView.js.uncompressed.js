require({cache:{
'url:epi-changeapproval/widget/templates/ApprovalCommandView.html':"﻿<div class=\"epi-changeapproval-detailsview\">\n    <div data-dojo-attach-point=\"toolbar\" class=\"epi-changeapproval-detailsview__toolbar epi-viewHeaderContainer epi-localToolbar\">\n        <div class=\"epi-changeapproval-detailsview__toolbar__leading epi-toolbarLeading\">\n            <div data-dojo-type=\"epi-cms/widget/Breadcrumb\" data-dojo-attach-point=\"breadCrumb\" data-dojo-props=\"showCurrentNode:false\"></div>\n            <div class=\"dijitInline\">\n                <h1 data-dojo-attach-point=\"titleNode\"></h1>\n            </div>\n        </div>\n\n        <div class=\"epi-changeapproval-detailsview__toolbar__trailing\">\n            <div style=\"display:inline-block\">\n                <div class=\"dijitInline dijitReset epi-statusIndicator\" data-dojo-attach-point=\"stateNode\">\n                    <span data-dojo-attach-point=\"statusNonEditableIcon\" class=\"dijitInline dijitReset dijitIcon\">&nbsp;</span>\n                    <span class=\"epi-statusContainer dijitInline dijitReset\">\n                        <span data-dojo-attach-point=\"statusTextIcon\" class=\"dijitInline dijitReset dijitIcon\"></span>\n                        <span data-dojo-attach-point=\"statusTextNode\" class=\"epi-statusText\"></span>\n                    </span>\n                    <span class=\"epi-statusArrow dijitInline dijitReset\"></span>\n                </div>\n                <div data-dojo-attach-point=\"dropDownButton\" data-dojo-type=\"dijit/form/DropDownButton\"\n                     data-dojo-props=\"'class': 'epi-mediumButton epi-button--bold'\">\n                    <div data-dojo-attach-point=\"dropDownMenu\" data-dojo-type=\"epi-changeapproval/ApprovalMenu\"></div>\n                </div>\n                <button data-dojo-type=\"dijit/form/Button\"\n                        data-dojo-attach-point=\"closeButton\"\n                        data-dojo-attach-event=\"onClick:_close\"\n                        data-dojo-props=\"showLabel: true, label: '${res.close}'\"\n                        class=\"epi-mediumButton epi-button--bold\"></button>\n            </div>\n        </div>\n    </div>\n    <div>\n        <div data-dojo-attach-point=\"commandNode\"></div>\n    </div>\n</div>\n"}});
define("epi-changeapproval/widget/ApprovalCommandView", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/dom-construct",
    "dojo/dom-class",
    "dojo/dom-attr",
    "dojo/string",
    "dojo/when",
    "dojo/topic",
    "dojo/html",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/_Widget",
    "dijit/form/Button", // used in template

// epi
    "epi/ModuleManager",
    "epi-cms/core/ContentReference",
    "epi/string",
    "epi/datetime",
    "epi/username",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/dependency",
    "epi-cms/widget/Breadcrumb",
    "epi/shell/TypeDescriptorManager",
    "epi-cms/_ContentContextMixin",

// add on
    "epi-changeapproval/ModuleSettings",
    "epi-changeapproval/widget/viewmodels/ApprovalCommandViewModel",
    "epi-changeapproval/_UtilityMixin",
    "epi-changeapproval/ApprovalMenu", // used in template
    "epi-changeapproval/viewmodel/ApprovalMenuViewModel",

// resources
    "epi/i18n!epi/cms/nls/episerver.changeapproval.approvalcommandview",
    "dojo/text!./templates/ApprovalCommandView.html"
],
function (
    declare,
    lang,
    all,
    domConstruct,
    domClass,
    domAttr,
    string,
    when,
    topic,
    html,

// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _Widget,
    Button, // used in template

// epi
    ModuleManager,
    ContentReference,
    epiString,
    epiDateTime,
    username,
    _ModelBindingMixin,
    dependency,
    Breadcrumb,
    TypeDescriptorManager,
    _ContentContextMixin,

// add-on
    ModuleSettings,
    ApprovalCommandViewModel,
    _UtilityMixin,
    ApprovalMenu,
    ApprovalMenuViewModel,

// resources
    res,
    template
 ) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _UtilityMixin, _ContentContextMixin], {
        // tags:
        //		internal

        res: res,

        templateString: template,

        modelClass: ApprovalCommandViewModel,

        _detailViewWidget: null,

        _updatingUI: false,

        defaultDetailView: "epi-changeapproval.widget.ApprovalCommandDetailsView",

        // contextHistory: [readonly] epi-cms/BackContextHistory
        //      The context history
        contextHistory: null,

        postscript: function () {
            this.inherited(arguments);
            this.res = this.res || res;
            this.contextHistory = this.contextHistory || dependency.resolve("epi.cms.BackContextHistory");
        },

        postCreate: function () {
            this.inherited(arguments);
            this.set("model", new this.modelClass());
        },

        updateView: function () {
            // summary:
            //		Recreate command widget with new model.
            // tags:
            //		protected

            if (this._updatingUI) {
                return;
            }

            // check if the change approval module has been initialized
            var moduleManager = dependency.resolve("epi.ModuleManager");
            var cappModuleInstance = moduleManager._moduleInstances["EPiServer.ChangeApproval"];
            if (!cappModuleInstance || !cappModuleInstance._initialized) {
                var cappModule = moduleManager.getModule("EPiServer.ChangeApproval");
                when(cappModule._started, lang.hitch(this, this.updateView));
                return;
            }

            // begin update the UI
            this._updatingUI = true;

            // always destroys the command detail view and rebuild new one
            if (this._detailViewWidget) {
                this._detailViewWidget.destroy();
            }
            // setup option menu
            this.dropDownMenu.set("model", new ApprovalMenuViewModel());

            when(this.model.getCommand(), lang.hitch(this, function (command) {
                if (command) {
                    this.command = command;
                    var contentReference = new ContentReference(this.command["appliedOnContent"]);
                    var approvalStatus = this.command["status"];

                    this.dropDownMenu.model.set("dataModel", this.command);
                    this.breadCrumb.set("contentLink", contentReference.createVersionUnspecificReference());
                    this.titleNode.innerText = string.substitute("${0} - ${1}", [this.command.name, this._getContextTitle(this.command)]);
                    var isCurrentUserInActiveStepReviewerList = !!this.command["isCurrentUserInActiveStepReviewerList"];

                    if (approvalStatus === ModuleSettings.approvalStatus.PENDING && isCurrentUserInActiveStepReviewerList && command.isCommandDataValid && command.canUserActOnHisOwnChanges) {
                        // if current user is part of active step reviewers and command is valid and canUserActOnHisOwnChanges is true, change dropdown button label to "Approve?"
                        this._setDropdownButtonLabel(res.approvalmenu.label.approve);
                    } else {
                        this._setDropdownButtonLabel(res.approvalmenu.label.option);
                    }
                    switch (approvalStatus) {
                        case ModuleSettings.approvalStatus.PENDING:
                            this._setAdditionalClassAttr(isCurrentUserInActiveStepReviewerList ? "epi-statusIndicatorAwaitingApproval dijitAwaitingApproval animated8 shake" : "epi-statusIndicatorAwaitingApproval dijitAwaitingApproval");
                            this._setStatusNodeText(isCurrentUserInActiveStepReviewerList && command.canUserActOnHisOwnChanges ? this.res["status"]["awaitingapproval"]: this.res["status"]["pending"]);
                            this._setStatusIconAttr("epi-icon--inverted epi-iconGlasses");
                            break;
                        case ModuleSettings.approvalStatus.ACCEPTED:
                            this._setAdditionalClassAttr("epi-statusIndicatorPublished dijitPublished");
                            this._setStatusNodeText(this.res["status"]["accepted"]);
                            this._setStatusIconAttr("");
                            break;
                        case ModuleSettings.approvalStatus.DECLINED:
                            this._setAdditionalClassAttr("epi-statusIndicatorRejected dijitRejected");
                            this._setStatusNodeText(this.res["status"]["declined"]);
                            this._setStatusIconAttr("epi-icon--inverted epi-iconStop");
                            break;
                        case ModuleSettings.approvalStatus.CANCELLED:
                            this._setAdditionalClassAttr("epi-statusIndicatorRejected dijitRejected");
                            this._setStatusNodeText(this.res["status"]["canceled"]);
                            this._setStatusIconAttr("epi-icon--inverted epi-iconStop");
                            break;
                        default:
                            this._setAdditionalClassAttr("");
                            this._setStatusNodeText("");
                            this._setStatusIconAttr("");
                            break;
                    }

                    // create a dojo widget based on the type identifier of the command and then, add it to the current widget's domNode.
                    var customView = this._getCommandCustomView(this.command);
                    var detailView = customView || this.defaultDetailView;
                    when(this.getInstanceFromType(detailView, { commandId: this.command.id }), lang.hitch(this, function (widget) {
                        this._detailViewWidget = widget;
                        domConstruct.place(widget.domNode, this.commandNode);
                        this._updatingUI = false;
                    }));
                }
                else {
                    this.command = null;
                    this.titleNode.innerText = "";
                    this._updatingUI = false;
                }
            }));
        },

        _getContextTitle: function (command) {
            var typeIdentifiers = command.typeIdentifier.split(".");
            var commandType = typeIdentifiers[typeIdentifiers.length - 1];

            switch (commandType) {
                case "securitysettingcommand": return this.res.titles.security;
                case "languagesettingcommand": return this.res.titles.language;
                case "movingcontentcommand": return this.res.titles.moving;
                case "expirationdatesettingcommand": return this.res.titles.expirationdate;
            }

            return this.res.titles[commandType];
        },

        _getCommandCustomView: function (command) {
            if (!command) {
                return null;
            }
            return TypeDescriptorManager.getValue(command.typeIdentifier, "defaultView");
        },

        _close: function () {
            // summary:
            //		Handle close button click.
            // tags:
            //		internal

            this.contextHistory.closeAndNavigateBack(this);
        },

        _getFriendlyUsername: function (name, capitalizeUsername) {
            // summary:
            //      Get friendly username: if the username to be displayed is the same
            //      as the current username, this will returns "you"
            // name:
            //      the username to be displayed
            // capitalizeUsername:
            //      If the first character should always be displayed with upper case.
            // tags:
            //      private

            return username.toUserFriendlyHtml(name, null, capitalizeUsername);
        },

        _setAdditionalClassAttr: function (val) {
            // remove
            var currentAdditionalClass = this.get("additionalClass");
            if (currentAdditionalClass) {
                domClass.remove(this.stateNode, currentAdditionalClass);
            }
            // add new
            this._set("additionalClass", val);
            domClass.add(this.stateNode, val);
        },

        _setStatusNodeText: function (/*String*/ statusText) {
            // summary:
            //      Updates the content status indication with the supplied text
            // tags: private

            this.statusTextNode.innerHTML = statusText;

            domAttr.set(this.stateNode, "title", !this.expanded ? epiString.stripHtmlTags(statusText) : "");
        },

        // statusIcon: [protected] String
        //      Content status icon.
        _setStatusIconAttr: function (val) {
            if (this.get("statusIcon")) {
                domClass.remove(this.statusTextIcon, this.get("statusIcon"));
            }
            this._set("statusIcon", val);
            domClass.add(this.statusTextIcon, val);
        },

        // set label for approval dropdown
        _setDropdownButtonLabel: function (text) {
            this.dropDownButton.set("label", text);
        }
    });

});
