﻿define("epi-changeapproval/commandproviders/ChangeApprovalMenu", [
    "dojo/_base/declare",
    "dojo/_base/lang",
    "epi/shell/command/withConfirmation",
    "epi/shell/command/_CommandProviderMixin",
    "epi/shell/DestroyableByKey",
    
    "epi-changeapproval/command/ApproveChanges",
    "epi-changeapproval/command/RejectChanges",
    "epi-changeapproval/command/CancelReviewRequest",
    "epi-changeapproval/command/ForceCompleteChangeApproval"
], function (
    declare,
    lang,
    withConfirmation,
    _CommandProviderMixin,
    DestroyableByKey,
    
    ApproveChangesCommand,
    RejectChangesCommand,
    CancelReviewRequest,
    ForceCompleteChangeApproval
) {

    return declare([_CommandProviderMixin, DestroyableByKey], {
        // summary:
        //      Builtin Command provider for publish menu.
        // tags:
        //      internal

        commandMap: null,

        mixin: function(command, options) {
            options = lang.mixin({
                isMain: false,
                priority: 0,
                resetLabelAfterExecution: true,
                mainButtonClass: null,
                keepMenuOpen: false,
                successStatus: null
            }, options);

            command.options = options;
            return command;
        },

        constructor: function () {
            // Should we retrieve all commands from a service at backend? 
            // In this case, our clients can inject their own commands easily and manipulate with our own ones for their businesses.
            this.commandMap = {                
                approvesettingchanges: this.mixin(new ApproveChangesCommand(), {
                    isMain: true,
                    priority: 10000,
                    mainButtonClass: "epi-success"
                }),

                declinesettingchanges: this.mixin(new RejectChangesCommand(), null, {}),

                forcecompletechangeaproval: this.mixin(new ForceCompleteChangeApproval(), null, {}),

                cancelreviewrequest: this.mixin(new CancelReviewRequest(), null, {})
            };

            this.commandMap.approvesettingchanges.order = 0;
            this.commandMap.forcecompletechangeaproval.order = 100;
            this.commandMap.declinesettingchanges.order = 200;
            this.commandMap.cancelreviewrequest.order = 300;
        },

        updateCommandModel: function (model) {

            this.destroyByKey("builtinCommands");
            var commands = [];           

            model.transitions.forEach(function (transition) {
                var command = this.commandMap[transition.name];
                if (command) {
                    commands.push(command);
                }
            }, this);

            this.set("commands", commands);
            this.inherited(arguments);
        }
    });
});
