﻿/// <reference path="jquery-1.7.1-vsdoc.js" />
/// <reference path="knockout-2.0.0.debug.js" />

StatViewModel = function () {
    var self = this;

    this.initialized = ko.observable(false).extend({ throttle: 100 });
    
    this.refreshCount = 0;
    this.sentMessage = 0;

    // isActive: [Boolean] 
    //      The flag to indicator Overview tab is active (having focus and user's attention) or not
    this.isActive = true;

    this.queryParams = ko.observable({
        PageIndex: ko.observable(0),
        PageSize: ko.observable(10),
        Filters: ko.observable(10)
    });

    this.scheduleQueryParams = ko.observable({
        PageIndex: ko.observable(0),
        PageSize: ko.observable(10),
        Filters: ko.observable(10)
    });

    /* total count of SCHEDULE message of current page */
    this.scheduleTotalCount = ko.observable(0);
    /* scheduled messages, for SCHEDULE message status list */
    this.scheduleMessages = ko.observableArray([]).extend({ throttle: 50 });

    /* total count of SENT message of current page */
    this.totalCount = ko.observable(0);
    /* normal messages, for SENT message status list */
    this.messages = ko.observableArray([]).extend({ throttle: 50 });

    this.detailedSocialMessage = ko.observable(null);
    
    this.initSocialChannel = function (elements, data) {
        if (data === undefined) {
            return;
        }
        $('.logo', elements).attr('src', g_ModuleResourcePath + 'Providers/' + data.Channel.ProviderName.toLowerCase() + '/logo.png');

        if (data.Message !== null) {
            $('.default-message', elements).text(res.client.custommessage);
        }
        else {
            $('.custom-message', elements).hide();
        }
    };

    this.pages = ko.computed(function () {

        var p = [];
        var pageSize = self.queryParams().PageSize();

        for (var i = 0; (i * pageSize) < self.totalCount(); i++) {
            p.push({ Text: i + 1, NewPageIndex: i });
        }

        return p;
    });

    this.schedulepages = ko.computed(function () {

        var p = [];
        var pageSize = self.scheduleQueryParams().PageSize();

        for (var i = 0; (i * pageSize) < self.scheduleTotalCount(); i++) {
            p.push({ Text: i + 1, NewPageIndex: i });
        }

        return p;
    });

    this.gotoPage = function (newPageIndex) {
        self.queryParams().PageIndex(newPageIndex);
        this.queryMessages();
    };

    this.gotoSchedulePage = function (newPageIndex) {
        self.scheduleQueryParams().PageIndex(newPageIndex);
        this.queryScheduleMesage();
    };

    this.deleteMessage = function (socialMessage) {
        // summary:
        //      Delete a social message
        // parameters:
        //      socialMessage: The message will be deleted.  
        // tags:
        //      public

        var data = "id=" + socialMessage.Id;
        this.sendAjaxRequest('POST', "Overview/Remove", data, function () {
            self.detailedSocialMessage(null);

            var currentPageIndex = self.queryParams().PageIndex();
            // if user deleting the last message item of a page,
            // try to display the previous page after delete
            if (currentPageIndex === self.pages().length - 1
                && self.totalCount() % self.queryParams().PageSize() === 1
                && currentPageIndex > 0) {
                currentPageIndex --;
                self.queryParams().PageIndex(currentPageIndex);
            }

            self.queryMessages();

            $('#details-view').hide();
            $('#normal-view').slideDown('fast');
        });
    };

    this.resendMessage = function (socialMessage) {

        if (socialMessage.Status() == Social.ChannelMessageStatus.Error) {

            $(socialMessage.ChannelMessages).each(function () {
                this.Enabled = (this.Status == Social.ChannelMessageStatus.Error);
            });
        }

        $form = $('<form method="POST" action="' + g_ModulePath + 'ResendMessage"></form>');
        $input = $('<input type="hidden" name="socialMessageId"></input>');
        $input.val(socialMessage.Id);
        $form.append($input);

        $form.append(createAntiForgeryHidenField());

        $('body').append($form);
        $form.submit();
    };

    this.queryMessages = function () {
        // summary:
        //      Query to server to get social messages with paging supported. 
        //      if the current view is social message detailed, then reload the message statistics.
        // tags:
        //      public
        var defer = $.Deferred();

        var currentDetailSocialMessage = self.detailedSocialMessage();
        if (currentDetailSocialMessage) {
            // detail view
            self.querySpecifiedMessage(currentDetailSocialMessage.Id);
        }
        else {
            var sentMsgDefer = $.Deferred();

            // normal list view
            self.queryParams().Filters(null);
            data = "json=" + ko.mapping.toJSON(self.queryParams);
            self.sendAjaxRequest('GET', "Overview/Query", data, function (data) {

                self.messages(populateMessageArray(data.Messages));
                self.totalCount(data.TotalCount);
                self.initialized(true);
                sentMsgDefer.resolve();
                self.updatePageIndexSelected();
            });
            
            var scheduleMsgDefer = this.queryScheduleMesage();
        }
        
        $.when(sentMsgDefer, scheduleMsgDefer).always(function () {
            defer.resolve();
        });
        
        return defer.promise();
    };

    this.queryScheduleMesage = function () {
        // summary:
        //      Query to server to get scheduled social messages with paging supported. 
        // tags:
        //      public
        // get schedule messages

        var defer = $.Deferred();

        self.scheduleQueryParams().Filters({"isSchedule":"true"});
        data = "json=" + ko.mapping.toJSON(self.scheduleQueryParams);
        self.sendAjaxRequest('GET', "Overview/Query", data, function (data) {
            self.scheduleMessages(populiateScheduleMessageArray(data.Messages));
            self.scheduleTotalCount(data.TotalCount);
            defer.resolve();
            self.updatePageIndexSelected();
        });

        return defer.promise();
    };

    this.querySpecifiedMessage = function (messageId) {
        // summary:
        //      Query to server to get social message by Id
        // tags:
        //      public

        self.sendAjaxRequest('GET', "Overview/Details", { messageId: messageId }, function (data) {
            var messages = populateMessageArray([data]);
            if (messages.length == 0) {
                return;
            }
            self.loadDetailedStatistics(messages[0]);
        });
    };

    this.updatePageIndexSelected = function () {
        /// <summary>Update the class for page-index element with current PageIndex in viewModel</summary>


        $(".overview .paging .page-index").removeClass('selected');
        $(".overview .schedule-messages .paging .page-index:nth-child(" + (self.scheduleQueryParams().PageIndex() + 1) + ")").addClass('selected');
        $(".overview .sent-messages     .paging .page-index:nth-child(" + (self.queryParams().PageIndex() + 1)         + ")").addClass('selected');
    };


    this.refresh = function () {
        // summary
        //      Call repeatly to server to update information
        //      isActive: [Boolean]
        //          The flag to indicator Overview tab is active or not. Do nothing if this Overview tab is not active to save CPU time/memory/network usage
        //      refreshCount: [Integer]
        //          The call refresh times, if greater than refreshCount then increate timeout to 30 seconds
        // tags
        //      protected

        // TECHNOTE: for performance optimization
        if (!self.isActive) {
            return;
        }

        $('#feedback').hide();

        viewModel.queryMessages();

        var timeout = 30000;
        if (viewModel.sentMessage && viewModel.refreshCount < 4) {
            viewModel.refreshCount++;
            timeout = 4000;
        }

        window.setTimeout(viewModel.refresh, timeout);
    };

    this.hasreadaccess = function (accessRighfacets) {
        return true;
    };

    this.loadDetailedStatistics = function (socialMessage) {

        $(socialMessage.ChannelMessages).each(function () {
            this.ProviderSpecific = Provider.Get(this.Channel.ProviderName).LoadDetailedStatistics(this, socialMessage);
        });

        viewModel.detailedSocialMessage(socialMessage);
    };

    this.sendAjaxRequest = function (/*GET POST*/ requestType, /* String */path, /* String */data, /* function */callback) {
        // summary:
        //      Send a ajax asyn request to server,
        //      then call the [callback] function with received data as prameters.
        // parameters:
        //      requestType:
        //          The query path relative from the module path.
        //      path:
        //          The query path relative from the module path.
        //      data: 
        //           The data which contains parameters send along with the request.
        //      callback:
        //          The callback function which is called when ajax request completed.
        // tags:
        //      public
        if (!requestType) {
            requestType = 'POST';
        }

        $.ajax({
            url: g_ModulePath + path,
            data: data,
            cache: false,
            type: requestType,
            async: true,
            dataType: "json",
            success: function (data) {
                if (typeof (callback) !== "function") {
                    return;
                }

                callback(data);
            }
        });
    };
}


$(".overview #normal-view .schedulePageIndex").live("click", function (e) {
    /**
    onclick of paging number, switch page
    */

    e.preventDefault();

    var page = ko.dataFor(this);
    viewModel.gotoSchedulePage(page.NewPageIndex);
});

$(".overview #normal-view .sentPageIndex").live("click", function (e) {
    /**
    onclick of paging number, switch page
    */

    e.preventDefault();
    
    var page = ko.dataFor(this);
    viewModel.gotoPage(page.NewPageIndex);
});

$('.overview #normal-view .stats').find('tbody tr').live('click', function (e) {
    /**
    Click on normal-view row, show the details-view
    */
    e.preventDefault();

    var socialMessage = ko.dataFor(this);
    viewModel.loadDetailedStatistics(socialMessage);

    $('#normal-view').slideUp('fast');
    $('#details-view').slideDown('fast');
});

$('.overview #normal-view .schedule').find('tbody tr').live('click', function (e) {
    /**
    Click on schedule view row, show edit schedule message screen
    */
    e.preventDefault();

    var socialMessage = ko.dataFor(this);

    $form = $('<form method="POST" action="' + g_ModulePath + 'Outreach"></form>');
    $input = $('<input type="hidden" name="messageId"></input>');
    $input.val(socialMessage.Id);
    $form.append($input);

    $form.append(createAntiForgeryHidenField());

    $('body').append($form);
    $form.submit();
});

$('.overview #details-view .back').live('click', function (e) {
    e.preventDefault();

    $('#details-view').hide();
    $('#normal-view').slideDown('fast');

    // update view detail message model
    viewModel.detailedSocialMessage(null);
    viewModel.queryMessages();
});

$('.overview #details-view .refresh').live('click', function (e) {
    e.preventDefault();

    var socialMessage = ko.dataFor(this);
    viewModel.querySpecifiedMessage(socialMessage.Id);
});


$('.detailed-channel-link').live('click', function (e) {
    /**
    Show message when user click on ErrorIcon of ChannelMessage
    */
    e.preventDefault();

    var socialChannelMessage = ko.dataFor(this);
    alert(socialChannelMessage.StatusMessage);
});

$(".message-delete").live("click", function (e) {
    /**
    Delete the whole SocialMessage
    */
    e.preventDefault();

    if (confirm(res.client.confirmmessagedelete)) {
        viewModel.deleteMessage(ko.dataFor(this));
    }
});

$(".message-resend").live("click", function (e) {
    e.preventDefault();
    viewModel.resendMessage(ko.dataFor(this));
});

function createAntiForgeryHidenField() {
    var $antiForgeryToken = $('<input type="hidden" name="__epiXSRF" id="__epiXSRF"></input>');
    $antiForgeryToken.val(g_AntiForgeryToken);

    return $antiForgeryToken;
}
function populiateScheduleMessageArray(data) {
    /**
    process data (come from AJAX response), populate schelude messages
    */

    messages = [];

    $(data).each(function () {
        var scheduleSocialMessage = this;

        $(scheduleSocialMessage.ChannelMessages).each(function () {
            this.MessageUrl = Provider.Get(this.Channel.ProviderName).GetMessageUrl(this);
            this.ProviderSpecific = {};
        });

        scheduleSocialMessage.Clicks = ko.computed(function () {
            var clicks = 0;
            $(scheduleSocialMessage.ChannelMessages).each(function () {
                clicks += this.Clicks;
            });

            return clicks;

        }, scheduleSocialMessage);

        scheduleSocialMessage.Status = ko.computed(function () {
            return Social.ChannelMessageStatus.Queued;

        }, scheduleSocialMessage);

        messages.push(scheduleSocialMessage);
    });

    return messages;
}

function populateMessageArray(data) {
    /**
    process data (come from AJAX response), populate the messages
    */
    messages = [];

    $(data).each(function () {
        var socialMessage = this;

        $(socialMessage.ChannelMessages).each(function () {
            this.MessageUrl = Provider.Get(this.Channel.ProviderName).GetMessageUrl(this);
            this.ProviderSpecific = {};
        });

        socialMessage.Clicks = ko.computed(function () {
            var clicks = 0;
            $(socialMessage.ChannelMessages).each(function () {
                clicks += this.Clicks;
            });

            return clicks;

        }, socialMessage);

        socialMessage.Status = ko.computed(function () {
            var errors = 0;
            var queued = 0;
            var cancelled = 0;

            $(socialMessage.ChannelMessages).each(function () {
                if (this.Status == Social.ChannelMessageStatus.Error) errors++;
                if (this.Status == Social.ChannelMessageStatus.Queued) queued++;
                if (this.Status == Social.ChannelMessageStatus.Cancelled) cancelled++;
            });

            var status = Social.ChannelMessageStatus.Success;
            if (0 < errors)
                status = Social.ChannelMessageStatus.Error;
            else if (0 < cancelled)
                status = Social.ChannelMessageStatus.Cancelled;
            else if (0 < queued)
                status = Social.ChannelMessageStatus.Queued;
            return status;

        }, socialMessage);


        // Show meaningful message when there is no account for the channels.
        $(socialMessage.ChannelMessages).each(function () {
            if (this.Channel.AccountDisplayName === null) {
                this.StatusMessage = res.error.channelnoaccount;
            }
        });

        messages.push(socialMessage);
    });

    return messages;
}

function formatDateTime(data) {
    /**
    format a date time string to locale date time string
    */
    var date = new Date(data);
    if (!date) {
        return data;
    }

    return date.toLocaleString();
}

///////////////////////
// ONLOAD /////////////
///////////////////////
var viewModel = new StatViewModel();
ko.applyBindings(viewModel);

var messageGuidToLoad = $.trim(window.location.hash.split('#')[1]);
// if hash is existing, mean user navigate from widget,
// need to load that message statistics.
if (messageGuidToLoad) {
    $('#normal-view').hide();
    $('#details-view').show();
    viewModel.querySpecifiedMessage(messageGuidToLoad);
} else {
    viewModel.queryMessages();
}

// TECHNOTE: for performance optimization
window.onfocus = function () {
    // summary:
    //      Call refresh method if window is focus
    //      isActive: [Boolean]
    //          The flag to indicator Overview tab is active or not
    // tags
    //      protected

    viewModel.isActive = true;
    viewModel.refresh();
};
window.onblur = function () {
    // summary:
    //      Store refresh method if window is lost focus
    //      isActive: [Boolean]
    //          The flag to indicator Overview tab is active or not
    // tags
    //      protected

    viewModel.isActive = false;
};

window.setTimeout(viewModel.refresh, 3000);


if (Social.getQueryString('sent')) {    // navigate here back from OutReach Create or Update

    viewModel.sentMessage = true;
    $('#feedback').show().find('.epi-feedbackLabel').text(res.client.sendingmessage);
    $('#feedback').find('.epi-feedback-closeButton').live('click', function (e) {
        e.preventDefault();

        $('#feedback').hide().find('.epi-feedbackLabel').text('');
    });
}
