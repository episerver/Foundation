﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/array",
    "dojo/json",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/dom-geometry",
    "dojo/dom-attr",
    "dojo/html",
    "dojo/store/Memory",
    "dojo/store/Observable",
    "dojo/on",
    "dojo/when",

// Dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetBase",
    "dijit/_Container",
    "dijit/layout/_LayoutWidget",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",

// EPi Framework
    "epi/dependency",
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/command/_WidgetCommandProviderMixin",
    "epi/shell/dgrid/util/misc",
    "epi/shell/widget/_FocusableMixin",
    "epi/datetime",

//CMS
    "epi-cms/_ContentContextMixin",
    

// Social Reach
    "epi-socialreach/component/viewmodel/SocialReachViewModel",
    "epi-socialreach/component/command/Settings",
    "epi-socialreach/component/command/SharePage",

// Resources
   "epi/i18n!epi-cms/nls/socialreach.gadget"

], function (
// Dojo
    declare,
    lang,
    array,
    json,
    domConstruct,
    domStyle,
    domClass,
    domGeometry,
    domAttr,
    html,
    Memory,
    Observable,
    on,
    when,

// Dijit
    _TemplatedMixin,
    _WidgetBase,
    _Container,
    _LayoutWidget,
    OnDemandGrid,
    Selection,

// EPi Framework
    dependency,
    _ModelBindingMixin,
    _WidgetCommandProviderMixin,
    GridMiscUtil,
    _FocusableMixin,
    epiDate,

//CMS
    _ContentContextMixin,
    

// Social Reach
    SocialReachViewModel,
    SettingsCommand,
    SharePageCommand,

// Resources
    res
) {

    return declare([_Container, _LayoutWidget, _TemplatedMixin, _ModelBindingMixin, _WidgetCommandProviderMixin, _FocusableMixin, _ContentContextMixin], {

        // modulePath: [protected] String
        //      Path to the EPiServer.SocialReach module,
        //      this property will be sent as settings when create SocialReach component (from server side)
        modulePath: null,

        notSupportContentTypes: null,

        hasOutreachAccess: false,

        // modelBindingMap: [protected] Object
        //      Contains information which is used for mapping properties between View and ViewModel.
        modelBindingMap: {
            "messages": ["messages"],
            "sharedInfo": ["sharedInfo"],
            "scheduledInfo": ["scheduledInfo"],
            "store": ["store"],
            "sharedMessageQuery": ["sharedMessageQuery"],
            "scheduledMessageQuery": ["scheduledMessageQuery"],
            "shareLinkEnable": ["shareLinkEnable"],
            "sharedMessageNodeVisibility": ["sharedMessageNodeVisibility"],
            "scheduledNodeVisibility": ["scheduledNodeVisibility"]
        },

        // model: [protected] SocialReachViewModel object
        //      ViewModel for the current widget.
        model: null,

        // sharedMessageGrid: [protected] Object
        //      dgrid object using to display list of messages associated with a page
        sharedMessageGrid: null,

        // scheduledMessageGrid: [protected] Object
        //      dgrid object using to display list of messages schedules to share with a page
        scheduledMessageGrid: null,

        // _settingsCommand: [private] SettingCommand object
        //      Command for settings of Social Reach
        _settingsCommand: null,

        // _sharedPageCommand: [private] SharePageCommand object
        //      Command for sharing a page via the gadget
        _sharePageCommand: null,


        // templateString: [protected] String
        //      Template string for the SocialReach widget
        templateString: '<div class="episocialreach">\
                            <div data-dojo-attach-point="shareLinkNode" class="sharedLinkNode">\
                                <a href="#" data-dojo-attach-point="shareLink"></a>\
                            </div>\
                            <div data-dojo-attach-point="scheduledNode" class="scheduledNode">\
                                <div data-dojo-attach-point="scheduledInfoNode" class="scheduledInfoNode"></div>\
                                <div data-dojo-attach-point="scheduledMessageNode" class="scheduledMessageNode"></div>\
                            </div>\
                            <div data-dojo-attach-point="sharedNode" class="sharedNode">\
                                <div data-dojo-attach-point="sharedInfoNode" class="sharedInfoNode"></div>\
                                <div data-dojo-attach-point="sharedMessageNode" class="sharedMessageNode"></div>\
                            </div>\
                         </div>',

        postscript: function () {
            // summary:
            //      Initialize view model, setting up the grid and register events as well.
            // tags:
            //      protected

            this.inherited(arguments);

            var customGridClass = declare([OnDemandGrid, Selection]);
            this.sharedMessageGrid = new customGridClass({
                columns: {
                    name: {
                        label: "Name",
                        renderCell: lang.hitch(this, function (item, value, node, options) {
                            var name = GridMiscUtil.htmlEncode(item.name);
                            var title = GridMiscUtil.htmlEncode(item.name);
                            node.innerHTML = lang.replace("<div class='socialMessage dojoxEllipsis' title='{title}'>{name}<span>&nbsp;</span></div>",
                                                            {
                                                                "name": name,
                                                                "title": title
                                                            });
                        })
                    },
                    clicks:{
                        label: "Clicks",
                        renderCell: function (item, value, node, options) {
                            node.innerHTML = lang.replace("<div><span>&nbsp;</span>({clicks})</div>", item);
                            domClass.toggle(node, "errorImage", item.hasError);
                        }
                    },
                    startedGMTString: {
                        label: "StartedGMTString",
                        renderCell: function (item, value, node, options) {
                            var date = new Date(value);
                            node.innerHTML = epiDate.toUserFriendlyString(date);
                        }
                    },
                },
                selectionMode: "single",
            }, this.sharedMessageNode);

            this.sharedMessageGrid.set("showHeader", false);
            this.sharedMessageGrid.on(".dgrid-row:click", lang.hitch(this, function (evt) {
                var row = this.sharedMessageGrid.row(evt);
                this._redirectToMessageStatistics(row.data);
            }));


            this.scheduledMessageGrid = new customGridClass({
                columns: {
                    name: {
                        label: "Name",
                        renderCell: lang.hitch(this, function (item, value, node, options) {
                            var name = GridMiscUtil.htmlEncode(item.name)
                            var title = GridMiscUtil.htmlEncode(item.name);
                            node.innerHTML = lang.replace("<div class='socialMessage dojoxEllipsis' title='{title}'>{name}<span>&nbsp;</span></div>",
                                                            {
                                                                "name": name,
                                                                "title": title
                                                            });
                            domClass.toggle(node, "errorImage", item.hasError);
                        })
                    },
                    scheduleGMTString: {
                        label: "ScheduleGMTString",
                        renderCell: function (item, value, node, options) {
                            var date = new Date(value);
                            node.innerHTML = epiDate.toUserFriendlyString(date);
                        }
                    }
                },
                selectionMode: "single",
            }, this.scheduledMessageNode);

            this.scheduledMessageGrid.set("showHeader", false);
            this.scheduledMessageGrid.on(".dgrid-row:click", lang.hitch(this, function (evt) {
                var row = this.scheduledMessageGrid.row(evt);
                this._redirectToEditScheduleMessage(row.data);
            }));

            this._setupCommands();
            // set text for the link
            var shareThisPageHtml = lang.replace("<span>{sharethispage}</span>", { "sharethispage": res.sharethispage });
            html.set(this.shareLink, shareThisPageHtml);

            // connect to onClick event of share link
            on(this.shareLink, "click", lang.hitch(this, "_onShareLinkClick"));

            when(this.getCurrentContext(), lang.hitch(this, function (ctx) {

                // NOTE: we need to make sure query send to server contains enough paramerters,
                // to avoid the 404 result.
                var sharedMessagesQuery = { "parent": ctx.id, "query": "getSharedMessages" },
                    scheduledMessageQuery = { "parent": ctx.id, "query": "getScheduledMessages" };

                this.set("sharedMessageQuery", sharedMessagesQuery);
                this.set("scheduledMessageQuery", scheduledMessageQuery);

                // init model for the widget
                this.set("model", this.model || new SocialReachViewModel({
                    modulePath: this.modulePath,
                    notSupportContentTypes: this.notSupportContentTypes,
                    "sharedMessageQuery": sharedMessagesQuery,
                    "scheduledMessageQuery": scheduledMessageQuery
                }));
            }));
        },

        resize: function (newSize) {
            // summary:
            //      Customize default resize method
            // newSize: object
            //      The new size of SocialReach component
            // tags:
            //      Public

            this.inherited(arguments);

            var remainSize = this._caculateSharedMessageNodeSize(newSize);
            domAttr.set(this.sharedMessageNode, "style", "height: " + remainSize.h + "px;");
        },

        _caculateSharedMessageNodeSize: function (newSize) {
            // summary:
            //      Calculate the new Size of the Content Query
            // newSize: object
            //      The new size of SocialReach component
            // tags:
            //      Private

            var shareLinkNodeSize = domGeometry.getMarginBox(this.shareLinkNode);
            var scheduledNodeSize = domGeometry.getMarginBox(this.scheduledNode);

            // console.log(shareLinkNodeSize, scheduledNodeSize);
            return { w: newSize.w, h: newSize.h - (shareLinkNodeSize.h + scheduledNodeSize.h + 60) };
        },

        _setSharedInfoAttr: function (/*String*/infoText) {
            // summary:
            //      Set the shared info text displaying on the widget.
            // parameters:
            //      infoText: The text message to display.
            // tags:
            //      private

            html.set(this.sharedInfoNode, infoText);
        },

        _setScheduledInfoAttr: function (/*String*/infoText) {
            // summary:
            //      Set the schedule info text displaying on the widget.
            // parameters:
            //      infoText: The text message to display.
            // tags:
            //      private

            html.set(this.scheduledInfoNode, infoText);
        },

        _setStoreAttr: function (/*Object*/store) {
            // summary:
            //      Set the store associatated with the grid.
            // parameters:
            //      store: Rest store object.
            // tags:
            //      private

            this.sharedMessageGrid.set("store", store);
            this.scheduledMessageGrid.set("store", store);
        },

        _setShareLinkEnableAttr: function (/*Boolean*/enable) {
            // summary:
            //      Disable/Enable share link depend on the context.
            // parameters:
            //      enable: true if enable, otherwise false.
            // tags:
            //      private

            domClass.toggle(this.shareLink, "disabled", !enable);
            // update model for the command
            this._sharePageCommand.set("model", this.model);
        },

        _setSharedMessageQueryAttr: function (/*Object*/value) {
            // summary:
            //      Set the query for fetching data from the store and fill into grid.
            // parameters:
            //      query: the query paramenter will be sent to rest store.
            // tags:
            //      private

            this.sharedMessageGrid.cleanup();

            var query = value ? value: { "parent": null };
            this.sharedMessageGrid.set("query", query);
        },

        _setScheduledMessageQueryAttr: function (/*Object*/value) {
            // summary:
            //      Set the query for fetching data from the store and fill into grid.
            // parameters:
            //      query: the query paramenter will be sent to rest store.
            // tags:
            //      private

            this.scheduledMessageGrid.cleanup();

            var query = value ? value : { "parent": null };
            this.scheduledMessageGrid.set("query", query);
        },

        _setScheduledNodeVisibilityAttr: function (/*Boolean*/ visible) {
            // summary:
            //      Set schedule node visibility.
            // parameters:
            //      visible: true if display the node, otherwise hide the node.
            // tags:
            //      private

            domStyle.set(this.scheduledNode, "display", visible ? "" : "none");
        },

        _setSharedMessageNodeVisibilityAttr: function (/*Boolean*/ visible) {
            // summary:
            //      Set shared node visibility.
            // parameters:
            //      visible: true if display the node, otherwise hide the node.
            // tags:
            //      private

            // TECHNOTE: We cannot set the display css property of the node to "none"
            // because of the dgrid will overwrite style attribute when init
            domClass.toggle(this.sharedMessageNode, "invisible", !visible);
        },

        _redirectToMessageStatistics: function (/*Object*/message) {
            // summary:
            //      Redirect to the statistics of the message with detailed information.
            // parameters:
            //      message: The message to show statistics.
            // tags:
            //      private

            var messageStatUrl = "{modulePath}Overview#{messageId}";
            window.location.href = lang.replace(messageStatUrl, { "modulePath": this.modulePath, "messageId": message.id });
        },

        _redirectToEditScheduleMessage: function (/*Object*/message) {
            // summary:
            //      Redirect to edit schedule for the message
            // parameters:
            //      message: The message to to edit schedule
            // tags:
            //      private

            var outreachUrl = lang.replace("{modulePath}Outreach", this);
            window.location.href = outreachUrl + "?messageId=" +message.id;
        },

        _setupCommands: function () {
            // summary:
            //    Add command buttons to Gadget Toolbar
            //
            // tags:
            //    private

            this._settingsCommand = new SettingsCommand({ modulePath: this.modulePath });
            this._sharePageCommand = new SharePageCommand({ modulePath: this.modulePath, model:  this.model });

            this.set('commands', [
                this._settingsCommand,
                this._sharePageCommand
            ]);
        },

        _onShareLinkClick: function () {
            // summary:
            //    Raised when the share link is clicked.
            //
            // tags:
            //    private

            this._sharePageCommand.execute();
        }
    });
});