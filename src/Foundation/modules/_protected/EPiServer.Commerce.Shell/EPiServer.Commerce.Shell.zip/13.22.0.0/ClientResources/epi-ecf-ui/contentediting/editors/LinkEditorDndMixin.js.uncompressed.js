﻿define("epi-ecf-ui/contentediting/editors/LinkEditorDndMixin", [
    //dojo
    "dojo/aspect",
    "dojo/_base/declare",
    "dojo/dom-class",

    // EPi Framework
    "epi/shell/_ContextMixin",

    // epi-cms
    "epi-cms/core/ContentReference"
], function (
    //dojo
    aspect,
    declare,
    domClass,
    // EPi Framework
    _ContextMixin,
    // epi-cms
    ContentReference) {

    return declare([_ContextMixin], {

        setupDndActions: function (dndSource, func ) {
            // summary:
            //      Sets Dnd actions.
            //
            //
            if (func === "checkAcceptance") {
                this.own(aspect.around(dndSource, func, function (original) {
                    return function (source, nodes) {
                        var items = nodes.map(function (node) {
                            var item = source.getItem(node.id);
                            return item.data.item || item.data;
                        });
                        var item = items[0];
                        //we assume _currentContext is resolved otherwise we'd need to use a deferred and it's not possible here
                        if (this._currentContext && item && ContentReference.compareIgnoreVersion(this._currentContext.id, item.contentLink)) {
                            return false;
                        }
                        return original.apply(dndSource, arguments);
                    }.bind(this);
                }.bind(this)));
            }
            this.own(aspect.after(dndSource, "onDndStart", function (source, nodes) {
                var accepted = dndSource.accept && dndSource.checkAcceptance(source, nodes);
                domClass[accepted ? "add" : "remove"](this.dropContainer, this.gridOverlayClass);
            }.bind(this), true));
        }
    });
});