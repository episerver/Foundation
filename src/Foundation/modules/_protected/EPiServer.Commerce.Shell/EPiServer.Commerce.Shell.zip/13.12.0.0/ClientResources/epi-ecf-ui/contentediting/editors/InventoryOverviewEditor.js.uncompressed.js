define("epi-ecf-ui/contentediting/editors/InventoryOverviewEditor", [
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/when",

    // DGrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/selector",
    "dgrid/extensions/ColumnResizer",
    "dgrid/editor",

    // EPi
    "epi/shell/dgrid/_EditorMetadataMixin",
    "epi/shell/dgrid/Formatter",
    "epi/shell/widget/CheckBox",

    //epi-CMS
    "epi-cms/dgrid/WithContextMenu",
    "epi-cms/dgrid/formatters",

    // epi commerce
    "./_OverviewEditorBase",
    "../viewmodel/InventoryOverviewEditorModel",

    //resources
    "epi/i18n!epi/cms/nls/commerce.widget.inventoryoverview.grid",
    "epi/i18n!epi/cms/nls/commerce.widget.inventorycollection.message"
],
function (
    // Dojo
    array,
    declare,
    aspect,
    domConstruct,
    when,

    // DGrid
    OnDemandGrid,
    Selection,
    selector,
    ColumnResizer,
    editor,

    // EPi
    _EditorMetadataMixin,
    Formatter,
    Checkbox,

    //epi-CMS
    WithContextMenu,
    formatters,

    // epi commerce
    _OverviewEditorBase,
    InventoryOverviewEditorModel,

    // Resources
    resources,
    messageResources
) {
    return declare([_OverviewEditorBase], {

        grid: null,

        modelType: InventoryOverviewEditorModel,

        itemType: "EPiServer.Commerce.Shell.ObjectEditing.InternalMetadata.InventoryRecordModel",

        activeEditor: null,

        includedColumns: ["WarehouseName", "WarehouseCode", "IsTracked", "PurchaseAvailableQuantity", "PurchaseAvailableUtc", "BackorderAvailableQuantity", "BackorderAvailableUtc", "PreorderQuantity", "PreorderAvailableUtc", "ReorderMinQuantity"],

        editableColumns: ["IsTracked", "PurchaseAvailableQuantity", "PurchaseAvailableUtc", "BackorderAvailableQuantity", "BackorderAvailableUtc", "PreorderQuantity", "PreorderAvailableUtc", "ReorderMinQuantity"],

        additionalEditorGridSettings: null,

        editorGrid: null,

        storeKey: "epi.commerce.inventory",

        title: resources.commands.title,

        _noDataMessage: resources.nodatamessage,

        postMixInProperties: function () {
            this.model = this.model || new this.modelType({
                itemType: this.itemType
            });
        },

        postCreate: function () {
            // Set up metadata capable grid type
            this.editorGrid = declare([OnDemandGrid, Selection, Formatter, _EditorMetadataMixin, ColumnResizer, WithContextMenu]);
            this.additionalEditorGridSettings = { getBeforePut: false, sort: ["WarehouseCode"] };
            
            this.inherited(arguments);
        },

        _setupEvents: function (grid) {
            this.own(grid,
                grid.on("dgrid-editor-show", function (e) {
                    this.activeEditor = e.editor;
                    this._showEditorInPopup(e);
                }.bind(this)),
                grid.on("dgrid-datachange", function (e) {
                    //invalid value will result in no changes to the inventory row.
                    if (this.activeEditor && this.activeEditor.isValid && !this.activeEditor.isValid()) {
                        e.preventDefault();
                    }
                }.bind(this)),
                grid.on(".epi-iconContextMenu:click", this.onContextMenuClick.bind(this)),
                this.model.watch("contentLink", this._changeGridQuery.bind(this)),
                this.model.on("itemAdded", grid.refresh.bind(grid)),
                this.model.on("itemsRemoved", grid.refresh.bind(grid)),
                // Listen remove command event
                this.model.on("removeCommandEvent", function() {
                    // Show confirmation dialog to confirm delete inventory item
                    when(this._showConfirmation(resources.deleteconfirmation.inventorytitle, resources.deleteconfirmation.inventorydescription), function () {
                        if (this.model) {
                            return this.model.removeItems([this.selectedRecord]);
                        }
                    }.bind(this));
                }.bind(this))
            );
        },

        _showEditorInPopup: function (e) {
            //we're wrapping the editor in a div to give it a popup styling.
            var popupElement = domConstruct.create("div", { "class": "epi-dgrid-popup" }, e.cell.element, "last");
            var editorWrapper = domConstruct.create("div", { "class": "epi-dgrid-popup__content" }, popupElement, "last");

            domConstruct.place(e.editor.domNode, editorWrapper);

            if (e.editor instanceof (Checkbox)) {
                var labelNode = '<label style="margin:10px;" for="' + e.editor.checkbox.get("id") + '">' + e.editor.get("label") + '</label>';
                domConstruct.place(labelNode, editorWrapper);
            }

            domConstruct.place(this.currentEditorHtmlValue, e.cell.element, "first");

            // reset the editor's content box so when FormContainer do the layout, it will resize
            // its children based on their actual size, not the specific one, which has the incorrect value.
            e.editor._contentBox = null;

            var beforeBlurHandle = aspect.before(e.editor, "onBlur", function () {
                //we need to move the editor back to the grid before "blur"
                //so that the dgrid/editor plugin can do its save/"hide editor" magic

                //move the editor to a temporary div first to prevent issues in IE
                //when we move the editors domNode as the only child to e.cell.element
                var tempDiv = domConstruct.create("div");
                domConstruct.place(e.editor.domNode, tempDiv);
                //then move it as the only child to the element we're editing.
                domConstruct.place(e.editor.domNode, e.cell.element, "only");
                beforeBlurHandle.remove();
            });
        }
    });
});
