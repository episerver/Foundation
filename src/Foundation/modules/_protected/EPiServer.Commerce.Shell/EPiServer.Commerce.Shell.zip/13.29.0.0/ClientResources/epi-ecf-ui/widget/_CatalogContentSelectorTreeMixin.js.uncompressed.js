﻿define("epi-ecf-ui/widget/_CatalogContentSelectorTreeMixin", [
    // dojo
    "dojo/_base/declare",
    "dojo/aspect"
], function (
    // dojo
    declare,
    aspect
) {
        return declare(null, {
            _setupContentSelectorTree: function (contentTree) {
                // summary:
                //      Add "toplevel" query parameter to the query of content tree's store.
                //      In additional, verifies that we do not set selection on a tree node twice.
                // contentTree: [object]
                //      An instance of epi-cms/widget/ContentTree.
                // tags:
                //      protected

                contentTree.own(
                    aspect.before(contentTree.model.store, "query", function (query, queryOptions) {
                        query.toplevel = true;
                    }, true)
                );

                var self = this;
                this.own(
                    aspect.around(contentTree.model, "filterAncestors", function (originalMethod) {
                        return function (ancestors) {
                            if (ancestors instanceof Array && ancestors.length > 0 && !!self._contextualParentLink) {
                                ancestors.splice(ancestors.length - 1, 0, self._contextualParentLink);
                            }

                            return originalMethod.apply(this, arguments);
                        };
                    }),
                    aspect.around(contentTree, "selectContent", function (originalMethod) {
                        return function (contentReferenceAsString, setFocus, needParentRefresh, onComplete) {
                            if ((this.selectedItem && this.selectedItem.contentLink) === contentReferenceAsString) {
                                return;
                            }

                            originalMethod.apply(this, arguments);
                        };
                    })
                );
            }
        });
    });