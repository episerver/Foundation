define([
    "epi/shell/socket/hub",
    "epi/shell/TaskQueue"
],
    function (
        hub,
        TaskQueue
    ) {
        function initializeWebsocket() {
            function processMessage(message) {
                if (message) {
                    if (!(message instanceof Array)) {
                        message = [message];
                    }

                    var results = message.map(function (item) {
                        var id = item["id"];
                        var action = item.action;

                        switch (action) {
                        case 1: // Save/Update
                            var event = new CustomEvent("ContentManagerNotificationEvent", { detail: action });
                            window.dispatchEvent(event);
                            break;
                            case 2: // Delete
                            //TODO: EXTERNAL_GRID for now we will refresh list of comments, but later we can just remove the comment from the list
                            var event = new CustomEvent("ContentManagerNotificationEvent", { detail: action });
                            window.dispatchEvent(event);
                            break;
                        default: // in case some unknown action from server
                            return true;
                        }
                    });

                    return true;
                }

                return true;
            }

            var queue = new TaskQueue(processMessage, { throttle: 5 });
            hub.subscribe("/episerver/cms/notification", queue.enqueue);

        }

        // Polyfill the CustomEvent() constructor functionality for IE
        (function () {
            if (typeof window.CustomEvent === "function") return false;

            function CustomEvent(event, params) {
                params = params || { bubbles: false, cancelable: false, detail: null };
                var evt = document.createEvent('CustomEvent');
                evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
                return evt;
            }

            window.CustomEvent = CustomEvent;
        })();

        return initializeWebsocket;
    });
