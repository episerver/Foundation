define([
    "dojo/_base/declare",

    "epi/_Module",
    "epi/routes",

     "epi/shell/store/JsonRest"
], function (
    declare,

    _Module,
    routes,

    JsonRest
) {
    return declare([_Module], {
        initialize: function () {
            this.inherited(arguments);

            var registry = this.resolveDependency("epi.storeregistry");

            // Register Children store
            registry.add("content-manager.store",
                new JsonRest({
                    target: routes.getRestPath({ moduleArea: "episerver-labs-content-manager", storeName: "content-manager" }),
                    idProperty: "contentLink"
                })
            );
        }
    });
});
