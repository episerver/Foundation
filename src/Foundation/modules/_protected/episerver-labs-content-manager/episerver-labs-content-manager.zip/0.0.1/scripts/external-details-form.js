define([
    "dojo/_base/declare",
    "dojo/when",
    "dojo/Deferred",
    "dojo/dom-construct",
    "dojo/on",

    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    "epi/dependency",
    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/ContentViewModel",
    "episerver-labs-block-enhancements/inline-editing/block-edit-form-container",
    "episerver-labs-block-enhancements/create-new/translate-block-edit-form-container",
    "episerver-labs-block-enhancements/create-new/create-new-block-edit-form-container",
    "epi/shell/command/builder/ButtonBuilder",

    "epi-cms/contentediting/command/SendForReview",
    "epi-cms/contentediting/command/Withdraw",

    "epi-cms/content-approval/command/ReadyForReview",
    "epi-cms/content-approval/command/CancelReview",

    "dojo/text!episerver-labs-content-manager/external-details-form.html",

    // referenced in the template
    "dijit/layout/BorderContainer",
    "dijit/layout/ContentPane",
    "dijit/form/ToggleButton",

    "xstyle/css!./styles.css"
],
    function (
        declare,
        when,
        Deferred,
        domConstruct,
        on,

        _LayoutWidget,
        _TemplatedMixin,
        _WidgetsInTemplateMixin,

        dependency,
        _ContentContextMixin,
        ContentViewModel,
        FormContainer,
        TranslateFormContainer,
        CreateNewBlockEditFormContainer,
        ButtonBuilder,
        SendForReview,
        Withdraw,

        ReadyForReview,
        CancelReview,

        template
    ) {

        return declare([_LayoutWidget, _TemplatedMixin, _WidgetsInTemplateMixin, _ContentContextMixin], {

            templateString: template,

            postCreate: function () {
                this.inherited(arguments);

                var registry = dependency.resolve("epi.storeregistry");
                this._approvalService = dependency.resolve("epi.cms.ApprovalService");
                this._contentStore = registry.get("epi.cms.content.light");
                this._contentDataStore = registry.get("epi.cms.contentdata");
                this._gridStore = registry.get("childGrid.store");
            },

            // editing content
            editContent: function (contentLink) {
                // show approval status
                when(this._gridStore.executeMethod("GetApprovalComment", null, { contentLink: contentLink })).then(
                    function (comment) {
                        this.contentStatusMessage.classList.toggle("dijitHidden", !comment);
                        this.contentStatusMessage.innerHTML = comment;
                    }.bind(this));

                // show form
                var container = domConstruct.create("div");

                this._clearForm();
                domConstruct.place(container, this.content);
                this.formContainer = new FormContainer({
                    isInlineCreateEnabled: true
                }, container, "last");
                this.formContainer.set("contentLink", contentLink);
                this.own(this.formContainer);
                this.resize(); // contentLayoutWidget
                return this;
            },

            translateContent: function (contentLink, language) {
                // show translate form
                var container = domConstruct.create("div");

                this._clearForm();
                domConstruct.place(container, this.content);
                this.formContainer = new TranslateFormContainer({
                    isInlineCreateEnabled: this.isInlineCreateEnabled,
                    isTranslationNeeded: true
                }, container, "last");

                when(this._contentStore.get(contentLink)).then(function (contentData) {
                    this.formContainer.reloadMetadata(contentData, contentData.contentTypeID);
                    this.formContainer.createContentViewModel.parent.missingLanguageBranch = {
                        preferredLanguage: language
                    }
                }.bind(this));

                this.own(this.formContainer);
                this.resize(); // contentLayoutWidget
                this.translate = true;
                return this;
            },

            saveForm: function () {
                if (!this.formContainer.validate()) {
                    return new Deferred().reject();
                }

                //TODO: CreateFormContainer from block-enhancements should return a promise, fix it and bump the dependency version
                //TODO: that 'when' should not be needed after that change
                return when(this.formContainer.saveForm());
            },

            createContent: function (contentTypeId, parentContentId) {
                this.contentStatusMessage.classList.toggle("dijitHidden", true);

                var container = domConstruct.create("div");

                this._clearForm();
                domConstruct.place(container, this.content);

                when(this._contentStore.get(parentContentId)).then(function (content) {
                    if (!content) {
                        return;
                    }

                    this.formContainer = new CreateNewBlockEditFormContainer({
                        autoPublish: true //temporary true, because otherwise content will be automatically added to the repository
                    }, container, "last");

                    this.formContainer.createContentViewModel.createAsLocalAsset = false;

                    this.formContainer.reloadMetadata(content, contentTypeId).then(function () {
                        this.formContainer.createContentViewModel.autoPublish = false;
                    }.bind(this));
                    this.own(on(this.formContainer, "formCreated", function () {
                        this.resize(); // contentLayoutWidget
                    }.bind(this)));
                    this.own(this.formContainer);
                }.bind(this));

                return this;
            },

            markAsReady: function () {
                var contentViewModel = this.formContainer._model;

                if (this._isTransitionAvailable(contentViewModel.contentData, "readyforreview")) {
                    var readyForReview = new ReadyForReview();
                    readyForReview.set("model", contentViewModel);
                    return readyForReview.execute();
                } else {
                    var sendForReview = new SendForReview();
                    sendForReview.set("model", contentViewModel);
                    return sendForReview.execute();
                }
            },

            cancelReview: function (contentLink) {
                return when(this._contentDataStore.get(contentLink)).then(function (content) {
                    var viewModel = new ContentViewModel({
                        contentLink: contentLink,
                        contextTypeName: "epi.cms.contentdata"
                    });

                    if (this._isTransitionAvailable(content, "cancelreview")) {
                        var cancelReview = new CancelReview();
                        cancelReview.set("model", viewModel);
                        return this._approvalService.getApproval(contentLink).then(function (approval) {
                            cancelReview.set({
                                canExecute: !!approval,
                                approval: approval
                            });
                            return cancelReview.execute();
                        }.bind(this));
                    } else {
                        var withdrawCommand = new Withdraw();
                        withdrawCommand.set("model", viewModel);
                        return withdrawCommand.execute();
                    }
                }.bind(this));
            },

            _isTransitionAvailable: function (content, transition) {
                return content.transitions.some(function (x) {
                    return x.name === transition;
                });
            },

            _clearForm: function () {
                if (this.formContainer) {
                    this.formContainer.destroyRecursive();
                }
                if (this.content.hasChildNodes()) {
                    this.formContainer.destroy();
                    while (this.content.firstChild) {
                        this.content.removeChild(this.content.firstChild);
                    }
                }
            }
        });
    });
