define([
    "dojo/_base/declare",

    "epi/_Module",
    "epi/routes",

    "epi/shell/applicationSettings",
    "epi-cms/contentediting/command/BlockEdit",
    
    "epi/shell/store/JsonRest"
], function (
    declare,

    _Module,
    routes,

    applicationSettings,
    BlockEdit,
    JsonRest
) {
    return declare([_Module], {
        initialize: function () {
            this.inherited(arguments);

            if (!applicationSettings.isInContentManagerMode) {
                return;
            }

            var registry = this.resolveDependency("epi.storeregistry");

            // Register Children store
            registry.add("content-manager.store",
                new JsonRest({
                    target: routes.getRestPath({ moduleArea: "episerver-labs-content-manager", storeName: "content-manager" }),
                    idProperty: "contentLink"
                })
            );

            // hide 'Edit' ContentArea menu
            var originalOnModelChange = BlockEdit.prototype._onModelValueChange;
            BlockEdit.prototype._onModelValueChange = function () {
                originalOnModelChange.apply(this, arguments);

                this.set("isAvailable", false);
            };
        }
    });
});
