﻿define([
    // dojo 
    "dojo/_base/declare",
    "dojo/_base/lang",

    // epi-addons 
    "epi-forms/contentediting/editors/ChoiceWithEditor",

    // resources
    "epi/i18n!epi/cms/nls/episerver.campaign.editview",
],
    function (
        // dojo 
        declare,
        lang,

        // epi-addons 
        ChoiceWithEditor,

        // resources
        res
    ) {

        // module: 
        //      connectforcampaign/widget/ChoiceWithRecipientAndOptInEditor
        // summary: 
        //      Override to pass additional item params which are used to create RecipientAndOptInSelector item later.
        // tags: 
        //      Override

        return declare([ChoiceWithEditor], {
            // ======================================================================= 
            // Public, overrided stubs 
            // ======================================================================= 

            res: res,

            postMixInProperties: function () {

                this.inherited(arguments);

                !this.itemParams && (this.itemParams = {});

                lang.mixin(this.itemParams, {
                    campaignDataStoreName: this.campaignDataStoreName,
                    campaignAdaptedConnectorId: this.campaignAdaptedConnectorId,
                    campaignDatasourceFormat: this.campaignDatasourceFormat,
                    marketingConnectorsId: this.marketingConnectorsId
                });
            },

            _buildItemParams: function (/*Object*/item) {
                // summary: 
                //      Override to set extendedWidgetType to connectforcampaign/widget/RecipientAndOptInSelector if the item is Marketing Connectors.
                // tags:
                //      Override

                var itemParams = this.inherited(arguments);

                if (item.value.indexOf(this.marketingConnectorsId) == 0) {
                    lang.mixin(itemParams, {
                        extendedWidgetType: "connectforcampaign/widget/RecipientAndOptInSelector"
                    });
                }

                return itemParams;
            },

            getErrorMessage: function () {
                // summary:
                //      Return message when validation fail.
                // tags:
                //      override

                return res.errormessage;
            }
        });
    });