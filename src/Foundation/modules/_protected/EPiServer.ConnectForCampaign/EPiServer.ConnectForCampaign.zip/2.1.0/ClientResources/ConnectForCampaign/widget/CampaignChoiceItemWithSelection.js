﻿﻿define([
    // dojo
    'dojo/_base/declare',
    'dojo/_base/lang',
    // epi-addons
    'epi-forms/widget/ChoiceItemWithSelection'
],
    function (
        // dojo
        declare,
        lang,
        // epi-addons
        ChoiceItemWithSelection
    ) {

        // module:
        //      connectforcampaign/widget/CampaignChoiceItemWithSelection
        // summary:
        //      Extend Forms's ChoiceItemWithSelection to support the extended widget type RecipientAndOptInSelector
        // tags:
        //      public

        return declare([ChoiceItemWithSelection], {

            _getParams: function (item) {
                // summary:
                //      Override to add additional params if the item is Marketing Connectors
                // tags:
                //      Override

                var params = this.inherited(arguments);

                if (item.value.indexOf(this.marketingConnectorsId) == 0) {
                    lang.mixin(params, {
                        campaignDataStoreName: this.campaignDataStoreName,
                        campaignAdaptedConnectorId: this.campaignAdaptedConnectorId,
                        campaignDatasourceFormat: this.campaignDatasourceFormat
                    });
                }

                return params;
            }

        });

    });