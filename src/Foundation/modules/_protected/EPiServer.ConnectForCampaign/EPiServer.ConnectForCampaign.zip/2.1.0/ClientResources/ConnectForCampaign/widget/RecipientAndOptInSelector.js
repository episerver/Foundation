﻿﻿define([
    // dojo
    "dojo/_base/declare",
    "dojo/on",
    "dojo/Deferred",
    "dojo/when",
    "dojo/store/Memory",
    "dojo/_base/lang",
    "dojo/dom-style",
    'dojo/Evented',
    // epi
    "epi-cms/_ContentContextMixin",
    "epi/dependency",
    // dijit
    "dijit/_WidgetBase",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/FilteringSelect",
    // resources
    "epi/i18n!epi/cms/nls/episerver.campaign.editview",
    "dojo/text!./../templates/RecipientAndOptInSelector.html"

], function (
    // dojo
    declare,
    on,
    Deferred,
    when,
    Memory,
    lang,
    domStyle,
    Evented,
    // epi
    _ContentContextMixin,
    dependency,
    // dijit
    _WidgetBase,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    FilteringSelect,
    // resources
    res,
    template

) {
        // module:
        //      connectforcampaign/widget/RecipientAndOptInSelector
        // summary:
        //      Multiple dropdowns for select Recipient and OptIn widget.
        // tags:
        //      public
        return declare([_WidgetBase, _TemplatedMixin, _WidgetsInTemplateMixin, _ContentContextMixin, Evented], {
            res: res,
            // store: [readonly] Rest store
            //      The connect for campaign data store
            store: null,

            recipientListDDLLabel: res.recipientlist,
            optInProcessDDLLabel: res.optinprocess,
            clearLabel: res.clearlabel,

            value: null,
            templateString: template,


            // =======================================================================
            // Public, overrided stubs
            // =======================================================================
            postCreate: function () {
                // summary:
                //      Post widget creation handler.
                // tags:
                //      protected
                this.inherited(arguments);

                var registry = dependency.resolve("epi.storeregistry");
                this.store = this.store || registry.get(this.campaignDataStoreName);

                when(this._getRecipientList(), lang.hitch(this, function (results) {
                    this._setrecipientAndOptinStore(this.recipientListDDL, results);
                }));


                when(this._getOptInProcessList(), lang.hitch(this, function (results) {
                    this._setrecipientAndOptinStore(this.optInProcessDDL, results);
                }));

                on(this.recipientListDDL, "focus", lang.hitch(this, function (e) {
                    this._dropdownOnFocus(this, e);
                }));

                on(this.recipientListDDL, "change", lang.hitch(this, function () {
                    this._dropDownChange();
                }));

                on(this.optInProcessDDL, "change", lang.hitch(this, function () {
                    this._dropDownChange();
                }));

                on(this.optInProcessDDL, "focus", lang.hitch(this, function (e) {
                    this._dropdownOnFocus(this, e);
                }));

                on(this.clearNode, "click", lang.hitch(this, function (e) {
                    this._clearSelections(this, e);
                }));

                on(this.clearNode, "focus", lang.hitch(this, function (e) {
                    this._clearNodeFocus(this, e);
                }));
            },

            isValid: function () {
                // tags:
                //      public, extensions
                if ((this.recipientListDDL && this.recipientListDDL.get('value') && this.optInProcessDDL && this.recipientListDDL.get('value'))
                    || (this.recipientListDDL && !this.recipientListDDL.get('value') && this.optInProcessDDL && !this.recipientListDDL.get('value')))
                    return true;
                return false;
            },

            // =======================================================================
            // Protected stubs
            // =======================================================================
            _setValueAttr: function (value) {
                // summary:
                //      Set value for this editor.
                // value: [String]
                //      
                // tags:
                //      protected, extensions

                // Make sure value is in correct format before parsing and assigning to dropdowns
                var regexp = new RegExp(this.campaignDatasourceFormat);
                if (value && regexp.test(value)) {
                    this._set("value", JSON.parse(value));
                    this._setDropDownsValue();
                }
            },

            _setReadOnlyAttr: function (value) {
                //summary:
                //    ReadOnly's setter.
                //
                // value: String
                //    Value to be set.
                //
                // tags:
                //    protected

                this.recipientListDDL.set("readOnly", value);
                this.optInProcessDDL.set("readOnly", value);

                domStyle.set(this.clearNode, "display", value ? "none" : "");
            },

            _getValueAttr: function () {
                // summary:
                //      Value's getter
                // tags:
                //      protected
                var item = { recipient: { name: "", id: "" }, optIn: { name: "", id: "" } };
                if (this.recipientListDDL.get('value')) {
                    item.recipient.id = this.recipientListDDL.get('value');
                    item.recipient.name = this.recipientListDDL.get('displayedValue');
                }
                if (this.optInProcessDDL.get('value')) {
                    item.optIn.id = this.optInProcessDDL.get('value');
                    item.optIn.name = this.optInProcessDDL.get('displayedValue');
                }
                return JSON.stringify(item);
            },

            // =======================================================================
            // Private stubs
            // =======================================================================
            _getRecipientList: function () {
                // summary:
                //      Gets Recipient list
                // returns: [Object]
                //      A collection of Recipient.
                // tags:
                //      private
                var deferred = new Deferred();

                when(this.store.executeMethod('GetRecipientList', null, null), function (result) {
                    deferred.resolve(result);
                });

                return deferred;
            },

            _getOptInProcessList: function () {
                // summary:
                //      Gets Opt-in Process list
                // returns: [Object]
                //      A collection of Opt-in Process.
                // tags:
                //      private
                var deferred = new Deferred();

                when(this.store.executeMethod('GetOptInList', null, null), function (result) {
                    deferred.resolve(result);
                });

                return deferred;
            },

            _setrecipientAndOptinStore: function (ddl, data) {
                // summary:
                //      set data store for dropdownlists
                // ddl: 
                //      the dropdownlist for setting store
                // data: 
                //      data for creating store
                // tags:
                //      private
                var source = [];
                data.forEach(function (item) {
                    source.push({ name: item.text, id: item.value });
                });

                if (source.length > 0) {
                    var memoryStore = new Memory({ data: source });
                    ddl.store = memoryStore;
                    ddl.set('required', false);
                    ddl.startup();

                    this._setDropDownsValue();
                }
            },

            _clearSelections: function () {
                // summary:
                //      clear selection on dropdownlists
                // tags:
                //      private
                if (this.recipientListDDL && this.optInProcessDDL) {
                    this.recipientListDDL.set('value', "");
                    this.optInProcessDDL.set('value', "");
                    this.emit('change', this.get("value"));
                }
            },

            _clearNodeFocus: function (obj, e) {
                this.onFocus(e); // need this to make the editor start editing
            },

            _dropdownOnFocus: function (obj, e) {
                this.onFocus(e); // need this to make the editor start editing
            },

            _dropDownChange: function () {
                if (!this.recipientListDDL.get('value')) {
                    return;
                }

                if (this.isCampaignDatasourceSelected()) {
                    this.setOptInProcessDisplayStatus(true);
                    if (this.optInProcessDDL.get('value')) {
                        this.emit('change', this.get("value"));
                    }
                }
                else {
                    this.setOptInProcessDisplayStatus(false);
                    this.optInProcessDDL.set('value', '', false);
                    this.emit('change', this.get("value"));
                }
            },

            _setDropDownsValue: function () {
                // summary:
                //      set value for dropdownlists
                // tags:
                //      private
                var currentValue = this.value;

                if ((currentValue || {}).recipient && this.recipientListDDL) {
                    this.recipientListDDL.set('value', currentValue.recipient.id, false);
                }

                if ((currentValue || {}).optIn && this.optInProcessDDL) {
                    if (this.isCampaignDatasourceSelected()) {
                        this.setOptInProcessDisplayStatus(true);
                        this.optInProcessDDL.set('value', currentValue.optIn.id, false);
                    }
                    else {
                        this.setOptInProcessDisplayStatus(false);
                        this.optInProcessDDL.set('value', '', false);
                    }
                }
            },

            isCampaignDatasourceSelected: function () {
                // summary:
                //      check whether the current selected recipient list belongs to Campaign connector or not
                // tags:
                //      protected

                var selectedRecipientList = this.recipientListDDL.get('value');
                return selectedRecipientList && selectedRecipientList.toLowerCase().indexOf(this.campaignAdaptedConnectorId.toLowerCase()) == 0;
            },

            setOptInProcessDisplayStatus: function (isVisible) {
                // summary:
                //      show/hide the opt-in process drop-down list
                // isVisible:
                //      the visibility status of the drop-down list
                // tags:
                //      protected

                domStyle.set(this.optInProcessDDLContainer, "display", isVisible ? '' : 'none');
            }
        });
    });