define(
"dojo/cldr/nls/en-au/gregorian", //begin v1.x content
{
	"dateFormatItem-yMd": "d/M/y",
	"dateFormat-medium": "dd/MM/yyyy",
	"dateFormatItem-MMMEd": "E, d MMM",
	"dateFormatItem-MMdd": "dd/MM",
	"dateFormatItem-MEd": "E, d/M",
	"dateFormatItem-yMEd": "E, d/M/y",
	"dateFormatItem-yMMMd": "d MMM y",
	"timeFormat-full": "h:mm:ss a zzzz",
	"dateFormatItem-yyyyMMMM": "MMMM y",
	"dateFormatItem-MMMMd": "d MMMM",
	"dateFormatItem-yyyyMM": "MM/yyyy",
	"timeFormat-medium": "h:mm:ss a",
	"dateFormat-long": "d MMMM y",
	"dateFormat-short": "d/MM/yy",
	"timeFormat-short": "h:mm a",
	"timeFormat-long": "h:mm:ss a z",
	"dateFormat-full": "EEEE, d MMMM y",
	"dateFormatItem-MMMd": "d MMM"
}
//end v1.x content
);