﻿define([
    
],
    function () {

            // module:
            //      personalization-cms-ui/ModuleSettings
            // summary:
            //      Module settings for EPiServer Personalization.
            //      Stores shared settings, constants for entire system.
            // tags:
            //      public
        return {

        };
    });
