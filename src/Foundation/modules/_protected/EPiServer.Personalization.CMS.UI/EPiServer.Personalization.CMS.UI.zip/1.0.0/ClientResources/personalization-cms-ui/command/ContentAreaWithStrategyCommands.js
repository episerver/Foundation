﻿define([
    "dojo/_base/declare",
    "epi-cms/contentediting/command/ContentAreaCommands",
  
    "personalization-cms-ui/_StrategyCommandMixin"
], function (
    declare,
    ContentAreaCommands,

    _StrategyCommandMixin) {

    return declare([_StrategyCommandMixin, ContentAreaCommands], {
        // tags:
        //      internal

        constructor: function () {
            this.inherited(arguments);
            this.addStrategyCommand(this.commands);
        }
   });
});

