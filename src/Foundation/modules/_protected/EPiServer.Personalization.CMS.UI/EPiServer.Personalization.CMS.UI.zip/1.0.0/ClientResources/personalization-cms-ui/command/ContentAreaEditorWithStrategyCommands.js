﻿define([
    "dojo/_base/declare",
    "epi-cms/contentediting/editors/ContentAreaEditor",

    "personalization-cms-ui/_StrategyCommandMixin"
], function (
    declare,
    ContentAreaEditor,

    _StrategyCommandMixin) {

    return declare([_StrategyCommandMixin, ContentAreaEditor], {
            // tags:
            //      internal

            postMixInProperties: function () {
                this.inherited(arguments);
                this.addStrategyCommand(this.commands);
            }
        });
    });