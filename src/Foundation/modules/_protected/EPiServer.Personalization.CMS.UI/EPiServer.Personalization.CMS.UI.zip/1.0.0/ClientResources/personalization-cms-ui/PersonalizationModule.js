﻿define([
    // dojo
    "dojo/_base/declare",

    // epi
    "epi/_Module",
    "epi/routes",
    // epi-strategy
    "personalization-cms-ui/ModuleSettings"
],  
    function (
        // dojo
        declare,

        // epi
        _Module,
        routes,
        // epi-strategy
        ModuleSettings
    ) {

        return declare([_Module], {

            // _settings: [private] Object
            //      Information which sent by Personalization module (in module.config file). We can read helpPath, moduleDependencies, routes, ... from here
            _settings: null,

            constructor: function (settings) {
                this._settings = settings;
                declare.safeMixin(ModuleSettings, this._settings);
            },

            initialize: function () {
                // summary:
                //      Initialize module
                //
                // description:
                //      Dependencies registered by this module are: 'LanguageManage application'

                this.inherited(arguments);

                var registry = this.resolveDependency("epi.storeregistry"),
                    route = this._getRestPath("strategydata");
                registry.create("epi-personalization.cms.ui", route, { idProperty: "id" });
                registry.create("epi.goal", this._getRestPath("goal"), {});
            },

            _getRestPath: function (name) {
                // summary:
                //      Get the rest path to a specified store.
                // prameters:
                //      name: The name of the store to get.
                // tags:
                //      private

                return routes.getRestPath({ moduleArea: "EPiServer.Personalization.CMS.UI", storeName: name });
            }
        });

    });
