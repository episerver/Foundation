﻿define([
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    // epi-cms
    "epi-cms/contentediting/command/_ContentAreaCommand",
    "epi-cms/contentediting/viewmodel/ContentBlockViewModel",

    // epi-strategy
    "personalization-cms-ui/widget/StrategySelector",
    "personalization-cms-ui/ModuleSettings",

    // resources
    "epi/i18n!epi/cms/nls/episerver.personalizationcms.strategymenu"
], function (
    // dojo
    declare,
    lang,

    // epi-cms
    _ContentAreaCommand,
    ContentBlockViewModel,

    // epi-strategy
    StrategySelector,
    ModuleSettings,

    // resources
    resources
   ) {

    return declare([_ContentAreaCommand], {
        // tags:
        //      internal

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: resources.label,

        // category: [readonly] String
        //      A category which hints that this item should be displayed as an popup menu.
        category: "popup",

        constructor: function () {
            this.popup = new StrategySelector();
        },

        postscript: function () {
            this.inherited(arguments);

            this.popup.watch("model", lang.hitch(this, this._setCommandAvailable));
            this.popup.watch("strategyOptions", lang.hitch(this, this._setCommandAvailable));
        },

        destroy: function () {
            this.inherited(arguments);

            this.popup && this.popup.destroyRecursive();
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute after the model value has changed.
            // tags:
            //      protected

            this.inherited(arguments);

            this.popup.set("model", this.model);
            this.set("canExecute", !!this.model && this.model.contentLink && !this.model.get("readOnly"));
        },

        _setCommandAvailable: function (name, oldValue, newValue) {
            // summary:
            //      Set command available
            // strategyOptions: [Array]
            //      Collection of strategies
            // tags:
            //      private

            var strategyOptions = this.popup.strategyOptions,
                model = this.popup.model;

            this.set("isAvailable", strategyOptions && strategyOptions.length > 0 // should have at least a strategy
                                    && model instanceof ContentBlockViewModel        // model should be a ContentBlockViewModel 
                                    && ModuleSettings.allowedTypeIdentifiers.indexOf(model.typeIdentifier) !== -1); // model.typeidentifier should be in the allowed list of content types for selector
        }
    });
});
