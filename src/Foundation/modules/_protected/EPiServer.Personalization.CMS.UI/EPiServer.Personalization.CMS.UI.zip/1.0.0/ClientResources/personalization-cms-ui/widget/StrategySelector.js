﻿define([
    // dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/when",
    "dojo/_base/lang",
    // dijit
    "dijit/MenuSeparator",

    // epi-cms
    "epi/dependency",
    "epi/shell/DestroyableByKey",
    "epi-cms/widget/SelectorMenuBase",
    "epi/shell/widget/RadioMenuItem",

    // personalization-cms-ui
    "personalization-cms-ui/ModuleSettings",

    // resources
    "epi/i18n!epi/cms/nls/episerver.personalizationcms.strategymenu"
], function (
    // dojo
    array,
    declare,
    when,
    lang,

    // dijit
    MenuSeparator,

    // epi-cms
    dependency,
    DestroyableByKey,
    SelectorMenuBase,
    RadioMenuItem,

    // personalization-cms-ui
    ModuleSettings,

    // resources
    res
) {

        return declare([SelectorMenuBase, DestroyableByKey], {
            // summary:
            //      Used for selecting strategy options for a block in a content area
            // tags:
            //      internal

            // model: [public] epi-cms/contentediting/viewmodel/ContentBlockViewModel
            //      View model for the selector
            model: null,

            // Override default value in SelectorMenuBase
            headingText: res.headingtext,

            // store: Rest store
            //      The store for getting strategies.
            strategyStore: null,


            postCreate: function () {
                // summary:
                //      Create the selector template and query for strategy options

                this.inherited(arguments);
                var registry = dependency.resolve("epi.storeregistry");
                this.strategyStore = this.strategyStore || registry.get("epi-personalization.cms.ui");
            },

            destroy: function () {
                this.inherited(arguments);
            },

            _setModelAttr: function (model) {
                this._set("model", model);
                this._setupMenu();
            },


            _setupMenu: function () {
                // summary:
                //      Setup strategy menu
                // tags:
                //      private

                when(this.strategyStore.query({}), lang.hitch(this, function (strategies) {
                    this._removeMenuItems();
                    if (!strategies || strategies.length < 1) {
                        return;
                    }
                    this.set("strategyOptions", strategies);

                    var currentStrategy = this.model.attributes["data-strategy"] || ModuleSettings.defaultStrategyValue,
                        defaultOption = {
                            strategyId: ModuleSettings.defaultStrategyValue,
                            name: res.defaultoptiontext
                        };
                    // Add default option to strategy source
                    var strategySource = [defaultOption].concat(strategies);

                    array.forEach(strategySource, function (strategyOption) {
                        var item = new RadioMenuItem({
                            label: strategyOption.name,
                            strategyId: strategyOption.strategyId,
                            checked: currentStrategy.toString() === strategyOption.strategyId
                        });

                        this._handleCheckingMenuItem(item);
                        this.addChild(item);

                        // Add the MenuSeparator 
                        if (strategyOption.strategyId === defaultOption.strategyId) {
                            this.addChild(new MenuSeparator({ baseClass: "epi-menuSeparator" }));
                        }
                    }, this);
                }));
            },

            _handleCheckingMenuItem: function (menuItem) {
                // summary:
                //      Handle MenuItem checked event 
                // menuItem: [RadioMenuItem]
                //      RadioMenuItem
                // tags:
                //      private

                this.ownByKey("items", menuItem.watch("checked", function (property, oldValue, newValue) {
                    if (!newValue ||
                        this.model.attributes["data-strategy"] === menuItem.strategyId ||
                        (!this.model.attributes["data-strategy"] &&
                            menuItem.strategyId === ModuleSettings.defaultStrategyValue)) {
                        return;
                    }

                    this.model.modify(function () {
                        this.model.attributes["data-strategy"] = menuItem.strategyId;
                    }, this, true);
                }.bind(this)));
            },

            _removeMenuItems: function () {
                var items = this.getChildren();
                this.destroyByKey("items");
                items.forEach(function (item) {
                    this.removeChild(item);
                    item.destroy();
                }, this);
            }
        });
    });
