﻿define([
    // Dojo
    "dojo/_base/declare",

    "epi-cms/widget/overlay/Block",
    "personalization-cms-ui/command/ContentAreaWithStrategyCommands"
], function (
    // Dojo
    declare,

    Block,
    ContentAreaWithStrategyCommands
) {

    return declare([Block], {

        postMixInProperties: function () {

            this.inherited(arguments);

            this.own(
                this.commandProvider = this.commandProvider || new ContentAreaWithStrategyCommands({ model: this.viewModel }),
            );
        }
    });
});