﻿define([
    "dojo/_base/declare",
    "epi-cms/contentediting/command/Personalize",
    "personalization-cms-ui/command/SelectStrategy"
], function (
    declare,
    Personalize,

    SelectStrategy) {

        return declare([], {
            addStrategyCommand: function (/*[Object]*/commands) {
                // summary:
                //      Insert SelectStrategy command into commands.
                // tags:
                //      public

                var personalize = commands.filter(function (x) { return x instanceof Personalize; })[0],
                    indexToInsert = 0;

                if (personalize) {
                    indexToInsert = commands.indexOf(personalize);
                }

                commands.splice(indexToInsert, 0, new SelectStrategy());
                commands.forEach(function (command) {
                    this.own(command);
                }, this);
            }
        });
    });

