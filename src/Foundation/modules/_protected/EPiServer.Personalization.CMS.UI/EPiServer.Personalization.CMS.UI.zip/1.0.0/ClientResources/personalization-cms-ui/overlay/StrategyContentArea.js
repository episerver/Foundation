﻿define([
    // Dojo
    "dojo/_base/declare",

    "epi-cms/widget/overlay/ContentArea",
    "personalization-cms-ui/overlay/StrategyBlock"

], function (
        // Dojo
        declare,

        ContentArea,
        StrategyBlock
    ) {

    return declare([ContentArea], {
        // blockClass: [public] Class
        //      Used to inject block overlay class.
        blockClass: StrategyBlock
    });
});