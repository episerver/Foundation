﻿define([
    // dojo
    "dojo/_base/declare",
    "dojo/Evented",
    "dojo/Stateful",

    "./childrenGridFilterModel"
], function (
    declare,
    Evented,
    Stateful,

    ChildrenGridFilterModel
) {
    return declare([Stateful, Evented], {
        selectedContentReferences: [],

        filters: null,

        postscript: function () {
            this.inherited(arguments);
            this.filters = new ChildrenGridFilterModel();
        },

        parseFunctionRenderer: function (renderer, thisValue) {
            try {
                var func = "var f = function (item, value, node, options) {" + renderer + "}.bind(thisValue); f({ properties: {} }, {}, {innerHTML: {}}, {})";
                eval(func);

                var renderFunction = new Function("item", "value", "node", "options", renderer);
                return renderFunction;
            } catch (e) {
                if (e instanceof SyntaxError) {
                    throw new Error("Cannot find renderer '" + renderer + "'" + e);
                }
            }

            return "";
        }
    });
});