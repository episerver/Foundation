define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/when",
    "dojo/topic",
    "dojo/on",
    "dojo/dom-construct",
    "dojo/dom-class",

    "dijit/popup",
    "dijit/TooltipDialog",

    "epi/dependency",
    "epi/datetime",
    "epi/shell/DialogService",
    "epi/shell/StickyViewSelector",
    "epi/shell/TypeDescriptorManager",
    "epi-cms/contentediting/command/BlockInlineEdit",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/dgrid/formatters",
    "epi-cms/ContentLanguageHelper",

    "epi/i18n!epi/cms/nls/contentchildren.renderers"
],

function (
    declare,
    lang,
    all,
    when,
    topic,
    on,
    domConstruct,
    domClass,

    popup,
    TooltipDialog,

    // epi-cms
    dependency,
    epiDatetime,
    DialogService,
    StickyViewSelector,
    TypeDescriptorManager,
    BlockInlineEdit,
    ContentActionSupport,
    formatters,
    ContentLanguageHelper,

    resources
) {

    var columnRenderrers = {

        action: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                ///
                ///  Renderer for actions menu
                ///

                node.innerHTML =
                    '<span class="dijitInline dijitIcon epi-iconContextMenu epi-floatRight" title="Options">&nbsp;</span>';
            };
        },

        categories: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                ///
                /// Renderer for Content categories
                ///   Display coma-separated list
                ///

                if (!this._categoriesStore) {
                    var registry = dependency.resolve("epi.storeregistry");
                    this._categoriesStore = registry.get("epi.cms.category");
                }

                var categories = item.properties.pageCategory;
                if (!categories) {
                    node.innerHTML = "";
                    return;
                }

                var dfdList = [];
                categories.forEach(function (categoryId) {
                    dfdList.push(this._categoriesStore.get(categoryId));
                }, this);

                all(dfdList)
                    .then(lang.hitch(this, function (categories) {
                        var categoriesStr = [];
                        categories.forEach(function (category) {
                            if (category && category.visible) {
                                categoriesStr.push(category.name);
                            }
                        }, this);
                        node.innerHTML = categoriesStr.join(", ");
                    }));
            };
        },

        contentName: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                ///
                /// Renderer for Content name
                ///    Display information about Name and current language
                ///

                node.innerHTML = formatters.contentItem(item.typeIdentifier, item.missingLanguageBranch, item.name);

                var missingLanguageMessage = ContentLanguageHelper.getMissingLanguageMessage(item);
                when(missingLanguageMessage)
                    .then(function (result) {
                        if (result) {
                            node.title = result;
                            domClass.add(node, "epi-ct-missingLanguageRow");
                        }
                    });

                // when content has no children, then should not be possible possible to enter this node
                if (item.hasChildren) {
                    var handle = on(node, "dblclick", function () {
                        handle.remove();
                        grid.onContentRequestNodeClicked(item);
                    }.bind(this));
                    // "this" is a grid
                    grid.own(handle);
                }
            };
        },

        contentTypeName: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                ///
                ///  Renderer for localized type name
                ///

                if (!this._contentTypeStore) {
                    var registry = dependency.resolve("epi.storeregistry");
                    this._contentTypeStore = registry.get("epi.cms.contenttype");
                }
                node.innerHTML = value;
                when(this._contentTypeStore.get(item.contentTypeID))
                    .then(function (type) {
                        node.innerHTML = type.localizedName;
                    }.bind(this));
            };
        },

        currentLanguageBranch: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                ///
                ///  Renderer list of language branches
                ///    Display clickable flags
                ///

                var languageTemplate = "<img src=\"/App_Themes/Default/Images/flags/{0}.gif\" title=\"{1}\" />";

                if (!grid.availableLanguages) {
                    node.innerHTML = "No language info"; //TODO: translation
                    return;
                }

                grid.availableLanguages.forEach(function (l) {
                    if (!item.existingLanguages) {
                        node.innerHTML = "";
                        return;
                    }

                    var missingTranslateion = item.existingLanguages.indexOf(l.value) === -1;
                    var title = l.label;
                    if (missingTranslateion) {
                        title += " - missing translation";
                    }
                    var n = domConstruct.create("a", {
                        innerHTML: lang.replace(languageTemplate, [l.value, title]),
                        href: "#"
                    }, node, "last");
                    if (missingTranslateion) {
                        domClass.add(n, "no-translation");
                    }

                    var handle = on(n, "click", function () {
                        handle.remove();
                        topic.publish("/epi/shell/context/request", { uri: item.uri }, { sender: this, forceReload: true });
                        var subscription = topic.subscribe("/epi/shell/action/viewchanged", function (type, args, data) {
                            subscription.remove();
                            window.location.replace(window.location.origin + window.location.pathname + "/?language=" + l.value);
                        });
                    });
                });
            };
        },

        date: function (propertyName, customRendererSettings, grid) {
            ///
            ///  Renderer for Content version status
            ///
            return function (item, value, node, options) {
                node.innerHTML = epiDatetime.toUserFriendlyHtml(item.properties[propertyName]);
            };
        },

        edit: function (propertyName, customRendererSettings, grid) {
            var self = this;

            return function (item, value, node, options) {
                ///
                ///  Renderer for Edit content link
                ///

                self._createEditLink(grid, node, item.typeIdentifier, (customRendererSettings && customRendererSettings.linkTitle) || resources.editrenderer.edit, item.uri);
            };
        },

        editableContentReference: function (propertyName, customRendererSettings, grid) {
            var self = this;

            return function (item, value, node, options) {
                ///
                /// Renderer for ContentCeference
                ///    Render a link to a content
                ///

                var contentReferenceValue = item.properties[propertyName];
                if (!contentReferenceValue) {
                    node.innerHTML = "Not set";
                    return;
                }
                node.innerHTML = "-";
                when(grid.getContentStore().get(contentReferenceValue))
                    .then(function (contentData) {
                        node.innerHTML = "";
                        self._createEditLink(grid, node, contentData.typeIdentifier, contentData.name, contentData.uri);
                    }.bind(this));
            }
        },

        _createEditLink: function (grid, node, typeIdentifier, linkText, uri) {
            var viewName = TypeDescriptorManager.getValue(typeIdentifier, "defaultView");
            if (!viewName || viewName === "searchContent") { //TODO: read from settings
                viewName = "formedit";
            }

            var editLink = domConstruct.create("a", { href: "#", innerHTML: linkText }, node, "last");

            var handle = on(editLink, "click", function () {
                handle.remove();

                var stickyViewSelector = new StickyViewSelector();
                stickyViewSelector.save(true, typeIdentifier, viewName);
                topic.publish("/epi/shell/context/request", { uri: uri }, { sender: this, forceReload: true });
            });
            grid.own(handle);
        },

        image: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                node.innerHTML = "-";
                var imageReference = item.properties[propertyName];
                if (imageReference) {
                    when(grid.getContentStore().get(imageReference)).then(function (contentData) {
                        var self = {};

                        function showTooltip () {
                            if (!self._tooltip) {
                                var dialogContentWrapper = domConstruct.create("div", { "class": "content-children_image-dialog" });
                                domConstruct.create("img", { src: contentData.previewUrl }, dialogContentWrapper, "last");
                                var imageNameNode = domConstruct.create("a", { href: "#", innerHTML: contentData.name }, dialogContentWrapper, "last");
                                grid.own(
                                    on(imageNameNode, "click", function () {
                                        popup.close(self._tooltip);

                                        var stickyViewSelector = new StickyViewSelector();
                                        stickyViewSelector.save(true, contentData.typeIdentifier, "onpageedit");
                                        topic.publish("/epi/shell/context/request", { uri: contentData.uri }, { sender: this, forceReload: true });
                                    })
                                );

                                grid.own(
                                    self._tooltip = new TooltipDialog({
                                        label: "the text for the tooltip",
                                        content: dialogContentWrapper,
                                        closable: true,
                                        onMouseLeave: function () {
                                            popup.close(self._tooltip);
                                        }
                                    })
                                );
                            }
                            popup.open({ popup: self._tooltip, around: node });
                        };

                        if (customRendererSettings && customRendererSettings.thumbnailName) {
                            contentData.thumbnailUrl = contentData.thumbnailUrl.replace("/Thumbnail?epieditmode=False",
                                "/" + customRendererSettings.thumbnailName + "?epieditmode=False");
                        }
                        var imageHtml = formatters.thumbnail(contentData.thumbnailUrl);
                        node.innerHTML = "";
                        var link = domConstruct.create("a", { innerHTML: imageHtml }, node, "last");
                        grid.own(on(link, "click", showTooltip));
                    });
                }
            }
        },

        thumbnailImage: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                node.innerHTML = "-";
                var imageReference = item.properties[propertyName];
                if (imageReference) {
                    when(grid.getContentStore().get(imageReference)).then(function (contentData) {
                        var thumbnailUrl = contentData.thumbnailUrl.replace("/Thumbnail?epieditmode=False",
                            "/" + customRendererSettings.thumbnailName + "?epieditmode=False");
                        node.innerHTML = formatters.thumbnail(thumbnailUrl);
                    });
                };
            }
        },

        pageVisibleInMenu: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                ///
                ///  Renderer for Is Visible in Menu
                ///    Display checkbox
                ///

                var properties = {
                    type: "checkbox",
                    readonly: "readonly",
                    disabled: "disabled"
                };
                if (item.properties.pageVisibleInMenu) {
                    properties.checked = "checked";
                }
                domConstruct.create("input", properties, node, "last");
            };
        },

        createdBy: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                var elem = domConstruct.create("span");
                elem.innerHTML = formatters.userName(item.createdBy);
                node.appendChild(elem);
            };
        },

        previewableContentReference: function (propertyName, customRendererSettings, grid) {
            var self = this;

            return function (item, value, node, options) {
                ///
                /// Renderer for ContentCeference
                ///    Render a link to a content
                ///

                var contentReferenceValue = item.properties[propertyName];
                if (!contentReferenceValue) {
                    node.innerHTML = "Not set";
                    return;
                }
                node.innerHTML = "-";
                when(grid.getContentStore().get(contentReferenceValue))
                    .then(function (contentData) {
                        node.innerHTML = "";
                        var linkSettings = {
                            href: contentData.previewUrl,
                            innerHTML: contentData.name,
                            target: "_blank"
                        };
                        domConstruct.create("a", linkSettings, node, "last");
                    }.bind(this));
            }
        },

        previewUrl: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                ///
                ///  Renderer link with URL to Content Preview
                ///    If preview is not available the information text is rendered
                ///

                if (!item.hasTemplate) {
                    node.innerHTML = "<span class=\"disabled\">[No preview]</span>"; //TODO: translation
                    return;
                }
                var template = "<a href=\"{0}\" target=\"_blank\" >Preview</a>";
                node.innerHTML = lang.replace(template, [item.previewUrl]);
            };
        },

        property: function (propertyName) {
            ///
            /// Renderer for properties not available directly under "item" object
            ///

            return function (item, value, node, options) {
                if (typeof propertyName === "undefined") {
                    node.innerHTML = "propertyName not set";
                    return;
                }
                node.innerHTML = item.properties[propertyName];
            }.bind(this);
        },

        status: function (propertyName, customRendererSettings, grid) {
            ///
            ///  Renderer for Content version status
            ///
            return function (item, value, node, options) {
                node.innerHTML = ContentActionSupport.getVersionStatus(item.status);
            };
        },

        conditionalEdit: function (propertyName, customRendererSettings, grid) {
            var self = this;

            return function (item, value, node, options) {
                ///
                ///  Renderer for Edit for pages and InlineEdit for blocks
                ///

                if (item.capabilities.isBlock) {
                    return self.inlineEdit(propertyName, customRendererSettings, grid)(item, value, node, options);
                } else {
                    return self.edit(propertyName, customRendererSettings, grid)(item, value, node, options);
                }
            };
        },

        inlineEdit: function (propertyName, customRendererSettings, grid) {
            return function (item, value, node, options) {
                function getErrorMessage(contentData) {
                    if (contentData === null) {
                        return resources.inlinerenderer.cannotedit.languagemissing;
                    }

                    if (contentData.status === ContentActionSupport.versionStatus.CheckedIn) {
                        return resources.inlinerenderer.cannotedit.checkedin;
                    }

                    if (contentData.status === ContentActionSupport.versionStatus.PreviouslyPublished) {
                        return resources.inlinerenderer.cannotedit.previouslypublished;
                    }

                    if (contentData.status === ContentActionSupport.versionStatus.DeplayedPublished) {
                        return resources.inlinerenderer.cannotedit.delayedpublished;
                    }

                    if (contentData.status === ContentActionSupport.versionStatus.AwaitingApproval) {
                        return resources.inlinerenderer.cannotedit.awaitingapproval;
                    }

                    if (contentData.isDeleted) {
                        return resources.inlinerenderer.cannotedit.isdeleted;
                    }

                    if (!ContentActionSupport.hasAccess(contentData.accessMask, ContentActionSupport.accessLevel.Edit)){
                        return resources.inlinerenderer.cannotedit.accessright;
                    }

                    if (!ContentActionSupport.hasProviderCapability(contentData.providerCapabilityMask, ContentActionSupport.providerCapabilities.Edit)) {
                        return resources.inlinerenderer.cannotedit.providernotsupport;
                    }

                    if (contentData.inUseNotifications && contentData.inUseNotifications.length > 0) {
                        var inuseMessage = resources.inlinerenderer.cannotedit.inuse;
                        return inuseMessage.replace("{0}", contentData.inUseNotifications[0].userName);
                    }

                }
                function onInlineEditClick() {
                    var command = new BlockInlineEdit();
                    command.set("model", item);

                    // For BlockInlineEdit command, the availibility flags are calculated in _refreshContentSettings
                    // after getting the latest content version from the server. So we cannot call command.execute() right after
                    // setting model.

                    // manually get content data and calculate the most recent availability flags
                    when(command._getContentData()).then(function (contentData) {
                        command._refreshContentSettings(contentData);
                        if (command.get("isAvailable") && command.get("canExecute")) {
                            return command.execute();
                        }

                        DialogService.alert({
                            heading: resources.inlinerenderer.cannotedit.title,
                            description: getErrorMessage(contentData)
                        });
                        return false;
                    });
                }

                if (!item.capabilities.isBlock) {
                    node.innerHTML = "<span class=\"disabled\">-</span>";
                    return;
                }


                var link = domConstruct.create("a", { innerHTML: "Edit" }, node, "last");

                var handle = on(link, "click", onInlineEditClick.bind(this));
                grid.own(handle);
            };
        }
    };

    return columnRenderrers;
});
