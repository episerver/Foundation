﻿define([
    "dojo",
    "dojo/_base/declare",

    "dijit/form/ToggleButton",

    "epi-cms/component/command/_GlobalToolbarCommandProvider",

    "./commands/manageContentContainer"
], function (
    dojo,
    declare,
    ToggleButton,
    _GlobalToolbarCommandProvider,
    ManageContentContainer
) {
    return declare([_GlobalToolbarCommandProvider], {
        //
        //  Global command provider that adds ManageContentContainer to toolbar
        //

        constructor: function () {
            this.inherited(arguments);

            var manageContentContainer = new ManageContentContainer({});
            this.addToLeading(manageContentContainer,
            {
                showLabel: false,
                widget: ToggleButton,
                "class": "manage-content-container-button epi-mediumButton epi-input-margin--right"
            });
        }
    });
});