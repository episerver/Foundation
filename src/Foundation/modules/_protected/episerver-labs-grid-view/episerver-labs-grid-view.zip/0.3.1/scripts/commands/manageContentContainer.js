﻿define([
        "dojo/_base/declare",
        "dojo/when",

        "epi/dependency",
        "epi/shell/DialogService",
        "epi/shell/command/_Command",
        "epi-cms/_ContentContextMixin",
        "epi-cms/contentediting/ContentActionSupport",

        "epi/i18n!epi/cms/nls/contentchildren.commands.managecontentcontainer"
    ],
    function(
        declare,
        when,

        dependency,
        dialogService,
        _Command,
        _ContentContextMixin,
        ContentActionSupport,

        res
    ) {
        var ContentContainerStatus = {
            standardPage: 0,
            containerPage: 1,
            globalContainer: 2
        };

        return declare([_Command, _ContentContextMixin], {
            //
            // Command for adding and removing content from Content Containers
            //
            label: "Manage Content Container",
            tooltip: "Manage Content Container",
            iconClass: 'epi-iconBundle--medium',
            canExecute: true,

            constructor: function () {
                var registry = dependency.resolve("epi.storeregistry");
                this.contentContainerStore = registry.get("contentContainer.store");
                this._setCommandState();
            },

            _setCommandState: function () {
                //
                //  set command state based on current content context
                //

                this.set("canExecute", false);
                when(this.getCurrentContent())
                    .then(function (content) {
                        var hasAdminAccess = ContentActionSupport.hasAccess(content.accessMask,
                            ContentActionSupport.accessLevel.Administer);

                        if (!hasAdminAccess) {
                            return;
                        }
                        this.contentContainerStore.get(content.contentLink)
                            .then(function (result) {
                                this._updateStatus(result);
                            }.bind(this));
                    }.bind(this));
            },

            _updateStatus: function (status) {
                switch (status) {
                    case ContentContainerStatus.standardPage:
                        {
                            this.set("active", false);
                            this.set("canExecute", true);
                            this.isContentContainer = false;
                            this.set('label', res.labels.standard);
                            break;
                        }
                    case ContentContainerStatus.containerPage:
                        {
                            this.set("active", true);
                            this.set("canExecute", true);
                            this.isContentContainer = true;
                            this.set('label', res.labels.container);
                            break;
                        }
                    case ContentContainerStatus.globalContainer:
                        {
                            this.set("active", true);
                            this.set("canExecute", false);
                            this.isContentContainer = true;
                            this.set('label', res.labels.global);
                            break;
                        }
                    default:
                        console.log("unknown container status: " + status);
                }
            },

            _execute: function () {
                var msg;
                var settings = {};
                if (this.isContentContainer) {
                    msg = res.disablecontainer;
                } else {
                    msg = res.enablecontainer;
                }
                settings.title = msg.title;
                settings.description = msg.description;

                dialogService.confirmation(settings)
                    .then(function () {
                            this.isContentContainer = !this.isContentContainer;

                            when(this.getCurrentContext())
                                .then(function (currentContext) {
                                    var postParams = {
                                        contentReference: currentContext.id,
                                        setAsContainer: this.isContentContainer
                                    };
                                    this.contentContainerStore.add(postParams)
                                        .then(function (result) {
                                            window.location.reload(true);
                                        }.bind(this));
                                }.bind(this));
                        }.bind(this),
                        function () {
                            this.set("active", this.isContentContainer);
                        }.bind(this));
            },

            contentContextChanged: function (context) {
                this._setCommandState();
            }
        });
    });