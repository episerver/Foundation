﻿define([
    "dojo/_base/declare",
    "dojo/dom-class",
    "dojo/when",
    "dojo/Evented",
    "dojo/dom-construct",
    "dojo/html",
    "dojo/dom-geometry",
    "dijit/Viewport",

    // djit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",

    // EPI
    "epi/shell/command/DelegateCommand",
    "epi/shell/command/builder/ButtonBuilder",

    "epi/dependency",

    "epi-cms/core/ContentReference",

    "./childrenContentFilteredGrid",

    "dojo/text!./templates/childrenGridDialogContentTemplate.html",

    "epi/i18n!epi/cms/nls/contentchildren.commands",

    "xstyle/css!./styles.css"
], function(
    declare,
    domClass,
    when,
    Evented,
    domConstruct, //TODO: unused
    html,
    domGeometry,
    Viewport,

    // dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,

    // EPI
    DelegateCommand,
    ButtonBuilder,
    dependency,

    ContentReference,

    ContentFilteredGrid,

    template,

    resources
) {
    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin, Evented], {
        templateString: template,

        startup: function() {
            if (this._started) {
                return;
            }

            this.inherited(arguments);

            this.own(Viewport.on("resize", this.resize.bind(this)));
        },

        postMixInProperties: function() {
            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this._contentLightStore = registry.get("epi.cms.content.light");
            this._contentStore = registry.get("epi.cms.contentdata");
        },

        buildRendering: function () {
            this.inherited(arguments);

            this._moveUpCommand = new DelegateCommand({
                name: "moveLevelUp",
                label: null,
                tooltip: resources.moveup,
                isAvailable: true,

                settings: {
                    "class": "move-up epi-chromeless epi-flat",
                    iconClass: "epi-iconUp",
                    showLabel: false
                },
                delegate: function () {
                    this.setContext({ id: this._currentParentContentLink }, this._gridSettings);
                }.bind(this)
            });

            this.own(this._moveUpCommand);

            var builder = new ButtonBuilder();
            builder.settings = this._moveUpCommand.settings;
            builder.create(this._moveUpCommand, this.moveUpCommandNode);

            this.own(
                this.filteredGrid.model.watch("selectedContentReferences", function () {//TODO: refactor event name
                    this.emit("selectionChanged", this.filteredGrid.model.get("selectedContentReferences"));
                }.bind(this))
            );
        },

        setContext: function(ctx, gridSettings, contentsToSelect) {
            this._gridSettings = gridSettings;

            var contentLink = ctx.id;

            var contentLinkWithoutVersion =  (new ContentReference(contentLink)).createVersionUnspecificReference().toString();
            when(this._contentLightStore.refresh(contentLinkWithoutVersion)).then(function (contentData) {
                if (!contentData) {
                    return;
                }
                this._currentParentContentLink = contentData.parentLink;

                this._moveUpCommand.set("canExecute", this._currentParentContentLink);

                html.set(this.header, contentData.name);

                var contentViewModel = this.filteredGrid.createContentViewModel(contentData, ctx);

                this._moveUpCommand.set("model", contentViewModel);

                this.filteredGrid.changeDisplayedContext(ctx.id, contentData, gridSettings);
                if (contentsToSelect) {
                    this.selectRows(contentsToSelect);
                }
            }.bind(this));
        },

        selectRows: function (contentsToSelect) {
            this.filteredGrid.selectItems(contentsToSelect);
        },

        resize: function () {
            // set grid haight
            var cb = domGeometry.getMarginBox(this.domNode);
            var ocb = this._oldContentBox;

            if (cb && ocb) {
                if (cb.w === ocb.w && cb.h === ocb.h) {
                    return;
                }
            }
            this._oldContentBox = cb;

            var top = domGeometry.getMarginBox(this.header).h;
            top += domGeometry.getMarginBox(this.filteredGrid.filters.domNode).h;

            domGeometry.setMarginBox(this.filteredGrid.contentQuery.domNode, {
                w: cb.w - 1,
                h: cb.h - top - 20
            });
        },
        
        _getSelectedContentReferencesAttr: function () {
            return this.filteredGrid.model.get("selectedContentReferences");
        },

        _setGridSelectionModeAttr: function (value) {
            this.filteredGrid.set("selectionMode", value);
        },
                    
        _setDndDisabledAttr: function (value) {
            this.filteredGrid.set("dndDisabled", value);
        }
    });
});