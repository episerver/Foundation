define("epi-forms/contentediting/editors/ConditionCollectionEditor", [// dojo
"dojo/_base/declare", "dojo/_base/lang", "dojo/when", "dojo/dom-class", "dojo/dom-attr", // dojox
"dojox/html/entities", // epi-addons
"epi/dependency", "epi-forms/contentediting/editors/_PlaceHolderMixin", "epi-forms/contentediting/editors/CollectionEditor", // cms
"epi-cms/_ContentContextMixin", // resources
"epi/i18n!epi/cms/nls/episerver.forms.contentediting.fielddependency"], function ( // dojo
declare, lang, when, domClass, domAttr, // dojox
HtmlEntities, // epi-addons
dependency, _PlaceHolderMixin, CollectionEditor, // cms
_ContentContextMixin, // resources
resources) {
  // module:
  //      epi-forms/contentediting/editors/ConditionCollectionEditor
  // summary:
  //
  // tags:
  //      public
  return declare([_PlaceHolderMixin, CollectionEditor, _ContentContextMixin], {
    _currentContext: null,
    // =======================================================================
    // Protected, overrided stubs
    // =======================================================================
    // override:
    postscript: function postscript() {
      this.inherited(arguments);
      when(this.getCurrentContent(), lang.hitch(this, function (currentContent) {
        this._currentContext = currentContent;
      }));
    },
    // override:
    postMixInProperties: function postMixInProperties() {
      this.inherited(arguments);
      var self = this; // Initialize grid settings

      this.gridSettings = lang.mixin(this.gridSettings || {}, {
        renderRow: function renderRow(rowData) {
          var rowElement = this.inherited(arguments); // get mapped item which is dependant condition details

          var mappedItem = self._getMappedItemById(rowData.field); // if item is not valid, make it highlighted


          if (mappedItem && !mappedItem.isValid) {
            domClass.add(rowElement, "epi-forms-dgrid-row-invalid-condition");
            domAttr.set(rowElement, "title", resources.invalidcondition);
          }

          return rowElement;
        }
      });
    },
    // override:
    _getDialogTitleText: function _getDialogTitleText(existingItem) {
      return resources.conditiondialog.title;
    },
    // override:
    _getGridDefinition: function _getGridDefinition() {
      // summary:
      //      Overrided function to register formatter for depend field and depend condition
      // tags:
      //      protected, extensions
      var result = this.inherited(arguments);
      result.operator.formatter = lang.hitch(this, this._operatorFormatter);
      result.field.formatter = lang.hitch(this, this._fieldFormatter);
      return result;
    },
    _getMappedItemById: function _getMappedItemById(id) {
      // summary:
      //      Get mapped item by id
      // tags:
      //      private
      if (!this.mappeditems || !this.mappeditems.length) {
        return null;
      }

      for (var i = 0; i < this.mappeditems.length; i++) {
        var item = this.mappeditems[i];

        if (item.id === id) {
          return item;
        }
      }

      return null;
    },
    _operatorFormatter: function _operatorFormatter(value) {
      // summary:
      //      Format depend field, display element name instead of element id
      // tags:
      //      protected, extensions
      if (!this.qualifiers || !this.qualifiers.length) {
        return "-";
      }

      if (!this.qualifiers[value]) {
        return value;
      }

      return this.qualifiers[value].name;
    },
    _fieldFormatter: function _fieldFormatter(value) {
      // summary:
      //      Format depend condition, display condition name instead of value (base on the mapped table, taken from "mappeditems" in the metadata of the property)
      // tags:
      //      protected, extensions
      if (!this.mappeditems || !this.mappeditems.length) {
        return value;
      }

      for (var i = 0; i < this.mappeditems.length; i++) {
        var item = this.mappeditems[i];

        if (item.id === value) {
          return HtmlEntities.encode(item.name);
        }
      }

      return value;
    },
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    onExecuteDialog: function onExecuteDialog() {
      // summary:
      //      Overrided function to display element name instead of element id
      // tags:
      //      public, extensions
      var item = this._itemEditor.get("value");

      var contentlink = item.field;

      if (!contentlink) {
        return;
      }

      var registry = dependency.resolve("epi.storeregistry");
      var store = registry.get("epi.cms.content.light");
      when(store.get(contentlink), lang.hitch(this, function (returnValue) {
        var contentData = returnValue;
        this.mappeditems.push({
          id: contentlink,
          name: contentData.name,
          isValid: true
        }); // add new item to the mapped table, because editor can choose new field, with new fieldname (does not exist in the old mappeditems)

        if (this._editingItemIndex !== undefined) {
          this.model.saveItem(item, this._editingItemIndex);
        } else {
          this.model.addItem(item);
        }
      }));
    }
  });
});