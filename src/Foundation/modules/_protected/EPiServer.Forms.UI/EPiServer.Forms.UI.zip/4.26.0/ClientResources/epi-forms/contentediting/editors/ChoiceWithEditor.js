define("epi-forms/contentediting/editors/ChoiceWithEditor", [// dojo
"dojo/_base/array", "dojo/_base/declare", "dojo/_base/lang", // epi-addons
"epi-forms/contentediting/editors/ChoiceEditor"], function ( // dojo
array, declare, lang, // epi-addons
ChoiceEditor) {
  // module:
  //      epi-forms/contentediting/editors/ChoiceWithEditor
  // summary:
  //      RadioButton|CheckBox selector with a type of drop-down button list widget.
  // tags:
  //      protected
  return declare([ChoiceEditor], {
    // =======================================================================
    // Public, overrided stubs
    // =======================================================================
    postMixInProperties: function postMixInProperties() {
      this.inherited(arguments);
      !this.itemParams && (this.itemParams = {});
      lang.mixin(this.itemParams, {
        extendedWidgetType: this.extendedWidgetType
      });
    },
    // =======================================================================
    // Protected stubs
    // =======================================================================
    _setValueAttr: function _setValueAttr(
    /*String*/
    value) {
      // summary:
      //      Calculates the period string
      // value: [String]
      //
      // tags:
      //      protected, extensions
      this.inherited(arguments);

      if (!value) {
        return;
      }

      var values = value.split(this._recordSeparator);
      var selectors = this.get("itemWidgets");

      this._toggleOnChangeActive(false);

      array.forEach(selectors, function (selector) {
        var itemValue = array.filter(values, function (item) {
          var selectorValue = item.split(selector._recordFieldSeparator)[0];
          return selectorValue && selector.get("selectorValue") && selector.get("selectorValue").indexOf(selectorValue) === 0;
        })[0];

        if (selector._extendedWidget) {
          selector.set("extendedWidgetValue", {
            value: itemValue
          });
          selector._calculateSelectorValue && selector._calculateSelectorValue();
        }
      });

      this._toggleOnChangeActive(true);
    }
  });
});