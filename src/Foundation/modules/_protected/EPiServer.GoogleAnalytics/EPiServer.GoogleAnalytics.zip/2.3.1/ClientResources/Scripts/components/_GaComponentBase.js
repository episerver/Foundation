﻿(function ($) {
    define([
        // Dojo
        "dojo/_base/declare",
        "dojo/_base/lang",
        "dojo/aspect",
        "dojo/when",
        "dojo/query",

        // Dijit
        "dijit/_TemplatedMixin",
        "dijit/_WidgetBase",
        "dijit/_Container",
        "dijit/layout/_LayoutWidget",
        "dijit/_WidgetsInTemplateMixin",

        // Dojox
        "dojox/layout/ContentPane",

        // EPi Framework
        "epi/dependency",
        "epi/routes",
        "epi/shell/widget/_ModelBindingMixin",
        "epi/shell/command/_WidgetCommandProviderMixin",

        // GA

        // Resources
        "epi/i18n!epi/cms/nls/episerver.googleanalytics"
    ],
        function (
            // Dojo
            declare,
            lang,
            aspect,
            when,
            query,

            // Dijit
            _TemplatedMixin,
            _WidgetBase,
            _Container,
            _LayoutWidget,
            _WidgetsInTemplateMixin,

            // Dojox
            ContentPane,

            // EPi Framework
            dependency,
            routes,

            _ModelBindingMixin,
            _WidgetCommandProviderMixin,
            
            // GA

            // Resources
            res
        ) {

            return declare([_WidgetBase, ContentPane, _TemplatedMixin, _WidgetsInTemplateMixin, _ModelBindingMixin, _WidgetCommandProviderMixin], {

                templateString: "<div class=\"epi-gadgetInner auto-height\" data-dojo-attach-point=\"gadgetContainer\"> \
                                     <div class=\"epi-gadgetContent\" ioArgs=\"{ preventCache: true }\" data-dojo-type=\"dojox/layout/ContentPane\" data-dojo-attach-point=\"gadgetContent\"></div> \
                                     <div class=\"epi-gadgetFeedback\"></div>\
                                </div>",

                // componentId: [public] Guid
                //    Unique component identifier.
                componentId: null,

                // element: [public] String
                //    The gadget's DOM element.
                element: null,

                // defaultRouteParams: [public] Object
                //    The default gadget route information.
                defaultRouteParams: null,

                // routeData: [public] Object
                //   Gadget's route data.
                routeData: null,

                postscript: function () {
                    // summary:
                    //      Initialize view model, setting up the grid and register events as well.
                    // tags:
                    //      protected

                    this.inherited(arguments);

                    this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

                },

                startup: function () {

                    this.inherited(arguments);

                    var gadgetInstance = this.getInstance(),
                        event = jQuery.Event("epigadgetinit");
                    this._initComponent(event, gadgetInstance);

                    this.defaultRouteParams = {};

                    // Discard any properties starting with underscore (data store internals)
                    for (var param in this.routeData) {
                        if (param[0] !== "_") {
                            this.defaultRouteParams[param] = this.routeData[param];
                        }
                    }

                    gadgetInstance.routeParams = lang.mixin(this.defaultRouteParams, { gadgetId: this.componentId });
                    $(gadgetInstance.element).bind("_epigadgetloadedinternal", dojo.hitch(this, this._onEpiGadgetLoaded));

                    this.connect(this.gadgetContent, "onDownloadEnd", function () {
                        $(gadgetInstance.element).trigger("_epigadgetloadedinternal");
                    });

                    this.loadView(this.defaultRouteParams);
                },

                getActionPath: function (/*Object*/routeParams) {
                    // summary:
                    //    Get the gadget's action path.
                    //
                    // routeParams:
                    //    An object with optional route parameters overriding the default route parameters.
                    //    Example: {moduleArea: "CMS", controller: "MyGadget", action:"Show"}
                    //    The URL for the configured default action is returned if no routeParameters are appended.
                    //
                    // tags:
                    //    public
                    return routes.getActionPath(this._mergeRouteParameters(routeParams), null);
                },

                _initComponent: function (event, gadgetInstance) {
                    // summary:
                    //    Init component, will call to init context gadget or dashboard gadget.
                    //    The concrete class should override this method to init theirself.  
                    //
                    // tags:
                    //    protected

                },

                _onEpiGadgetLoaded: function () {
                    // summary:
                    //    Raises the epigadgetloaded event after internal setup is done.
                    //
                    // tags:
                    //    private callback

                    var gadgetInstance = this.getInstance();

                    // Must be run before custom gadget load handlers, and it seems the execution order may differ from the bind order in IE9
                    $("form.epi-gadgetform", gadgetInstance.element).validate({ errorElement: "span" });
                    $("form.epi-gadgetform", gadgetInstance.element).bind("submit", gadgetInstance, this._submitHandler);
                    $("form.epi-gadgetform .epi-gadgetCancel", gadgetInstance.element).bind("click", gadgetInstance, this._onCancelHandler);

                    // Raise the public loaded event for other custom handlers
                    $(gadgetInstance.element).trigger("gagadgetloaded", gadgetInstance);
                },

                _mergeRouteParameters: function (routeParameters) {
                    // summary:
                    //    Merge the route parameters.
                    //
                    // routeParams:
                    //    An object with optional route parameters overriding the default route parameters.
                    //    Example: {moduleArea: "CMS", controller: "MyGadget", action:"Show"}
                    //    The URL for the configured default action is returned if no routeParameters are appended.
                    //
                    // tags:
                    //    private
                    return lang.mixin({}, this.defaultRouteParams, routeParameters);
                },

                _onCancelHandler: function (e) {
                    // summary:
                    //    Handle event when user click on Cancel button inside the Component.
                    //
                    //  tags:
                    //      private

                    e.preventDefault();
                    var gadgetInstance = e.data;
                    gadgetInstance.loadView();
                },

                _submitHandler: function (e) {
                    // summary:
                    //    Handle event when user click on OK button inside the Component.
                    //
                    //  tags:

                    //      private
                    var gadgetInstance = e.data;
                    var formElement = this;

                    if ($(formElement).valid()) {

                        var submitEvent = jQuery.Event("epigadgetsubmit");
                        submitEvent.target = formElement;

                        $(formElement).trigger(submitEvent, gadgetInstance);

                        if (!submitEvent.isDefaultPrevented()) {
                            var formData = $(formElement).serializeArray();
                            formData.push({ name: "gadgetId", value: gadgetInstance.id });

                            gadgetInstance.ajax({
                                url: formElement.action,
                                dataType: "html",
                                data: formData,
                                success: function (data) {
                                    gadgetInstance.routeParams = {};
                                    gadgetInstance.gadgetContent.set("content", data.toString());
                                    $(gadgetInstance.element).trigger("_epigadgetloadedinternal");
                                }
                            });
                        }
                    }

                    e.preventDefault();
                },

                loadView: function (/*Object*/routeParams) {
                    // summary:
                    //    Load the gadget view.
                    //
                    // routeParams:
                    //    An object with optional route parameters overriding the default route parameters.
                    //    Example: {moduleArea: "CMS", controller: "MyGadget", action:"Show"}
                    //    The URL for the configured default action is returned if no routeParameters are appended.
                    //
                    // tags:
                    //   public
                    this.isVisible = true;
                    var gadgetInstance = this.getInstance();
                    if (routeParams) {
                        gadgetInstance.routeParams = routeParams;
                    } else {
                        gadgetInstance.routeParams = this.defaultRouteParams;
                    }

                    // this was previously epigadgetloadview handler
                    var url = gadgetInstance.getActionPath(gadgetInstance.routeParams);

                    this.gadgetContent.set("href", url);
                },
                resize: function (newSize) {
                    // summary:
                    //      Customize default resize method
                    // tags:
                    //      Public

                    this.inherited(arguments);
                    this.gadgetContent.resize(newSize);
                },
                getInstance: function () {
                    // summary:
                    //    Get a backward compatible wrapped gadget instance
                    //
                    // tags:
                    //    public
                    //
                    // returns:
                    //    An instance of gadget.
                    if (this.instance) {
                        return this.instance;
                    }

                    this.instance = this._gadgetInstance();
                    return this.instance; // gadget instance
                },


                _gadgetInstance: function () {
                    // summary:
                    //    Convenience wrapper for a gadget instance.
                    //
                    // returns:
                    //    The gadget instance.
                    //
                    // tags:
                    //    private

                    var gadget = this;

                    var pub = {
                        id: gadget.componentId,
                        // The unique id of the gadget

                        element: gadget.gadgetContainer,
                        // The gadget container DOM element.

                        gadgetContent: gadget.gadgetContent,

                        routeParams: {} // this is updated by the widget's init method
                        // The route params for the gadget.
                    };

                    pub.getActionPath = function (/*Object*/routeParams) {
                        // summary:
                        //    Gets the URL for a gadget action based on routeParameters
                        //
                        // routeParams:
                        //    An object with optional route parameters overriding the default route parameters.
                        //    Example: {moduleArea: "CMS", controller: "MyGadget", action:"Show"}
                        //    The URL for the configured default action is returned if no routeParameters are appended.
                        //
                        // tags:
                        //    public
                        //
                        // returns:
                        //    The URL for a gadget action
                        return gadget.getActionPath(routeParams); //String
                    };

                    pub.loadView = function (/*Object*/routeParams) {
                        // summary:
                        //    Loads a new view into the gadget
                        //
                        // routeParams:
                        //    An object with optional route parameters overriding the default route parameters.
                        //    Example: {action: "Show"}
                        //    The URL for the configured default action is returned if no routeParameters are appended.
                        //
                        // tags:
                        //    public
                        gadget.loadView(routeParams);
                    };

                    pub.ajax = function (/*Object*/ajaxOptions) {
                        // summary:
                        //    Sends an AJAX request using jQuery AJAX functionalityserverSets an error message in the gadget heading area.
                        //
                        // ajaxOptions:
                        //    A jQuery AJAX parameter object overriding default options.
                        //
                        // tags:
                        //    public

                        // Merge any custom properties into the default ones

                        // Don't even try converting this to dojo methods until there are unit tests validating the post data conversion

                        var self = this;
                        var options = {
                            dataType: "json",
                            feedbackMessage: "",
                            cache: false,
                            type: "POST",
                            ajaxLoader: true,
                            error: function (xmlHttpRequest, status, errorThrown) {
                                console.error(xmlHttpRequest, status, errorThrown);
                            },
                            success: function (data) {
                            }
                        };

                        // Add antiforgery protection data to the request data
                        var antiforgeryToken = $("input[name=__RequestVerificationToken]", this.element);
                        if (antiforgeryToken.length > 0) {
                            var validationData = { __RequestVerificationToken: antiforgeryToken.val() };
                            if (ajaxOptions.data) {
                                if (!ajaxOptions.data.__RequestVerificationToken) {
                                    ajaxOptions.data = $.extend(ajaxOptions.data, validationData);
                                }
                            } else {
                                ajaxOptions.data = validationData;
                            }
                        }

                        if ($.isFunction(ajaxOptions.success)) {
                            var tempSuccess = ajaxOptions.success;
                            ajaxOptions.success = function (data, textStatus) {
                                tempSuccess.call(this, data, textStatus);
                            };
                        }
                        if ($.isFunction(ajaxOptions.error)) {
                            var tempError = ajaxOptions.error;
                            ajaxOptions.error = function (xmlHttpRequest, status, errorThrown) {
                                tempError.call(this, xmlHttpRequest, status, errorThrown);
                            };
                        }

                        options = $.extend(options, ajaxOptions);
                        $.ajax(options);
                    };

                    return pub; //gadget instance
                }
            });
        });

})(epiJQuery);