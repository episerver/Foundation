﻿define("epi-languagemanager/LanguageManagerModule", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    // epi
    "epi/_Module",
    "epi/routes",
    "epi/dependency",
    "epi/shell/request/mutators",
    // epi-cms
    "epi-cms/project/viewmodels/_ProjectViewModel",
    "epi-cms/project/ProjectItemQueryEngine",

    // language manager
    "epi-languagemanager/ModuleSettings",
    "epi-languagemanager/component/command/DownloadTranslationPackage",
    "epi-languagemanager/component/command/UploadTranslationPackages",
    "epi-languagemanager/component/viewmodel/UploadTranslationPackagesViewModel",
    "epi-languagemanager/request/LanguageManagerContentLanguage",
    "epi-languagemanager/request/LanguageManagerProjectMode"
],
function (
// dojo
    declare,
    lang,

    // epi
    _Module,
    routes,
    dependency,
    mutators,

    // epi-cms
    _ProjectViewModel,
    projectItemQueryEngine,

    // language manager
    ModuleSettings,
    DownloadTranslationPackage,
    UploadTranslationPackages,

    UploadTranslationPackagesViewModel,
    languageManagerContentLanguage,
    languageManagerProjectMode
) {

    return declare([_Module], {

        // _settings: [private] Object
        //      Information which sent by LanguageManager module (in module.config file). We can read helpPath, moduleDependencies, routes, ... from here
        _settings: null,

        constructor: function (settings) {
            this._settings = settings;
        },

        initialize: function () {
            // summary:
            //      Initialize module
            //
            // description:
            //      Dependencies registered by this module are: 'LanguageManage application'

            this.inherited(arguments);

            mutators.add(languageManagerProjectMode);
            mutators.add(languageManagerContentLanguage);

            declare.safeMixin(ModuleSettings, this._settings);

            // Initialize stores
            var registry = this.resolveDependency("epi.storeregistry"),
                route = this._getRestPath("language");

            this._hashWrapper = dependency.resolve("epi.shell.HashWrapper");

            registry.add("epi-languagemanager.settings", this._settings);
            registry.create("epi-languagemanager.language", route, { idProperty: "id" });
            // We need to create projectItemStore ourself to inject X-EPiContentLanguage as header param later
            registry.create("epi-languagemanager.project.item", this._getCMSRestPath("project-item"), { queryEngine: projectItemQueryEngine });
            registry.create("epi-languagemanager.project", this._getCMSRestPath("project"));

            this._injectCommandsToProjectView();

            // Register route for "epi.cms.languagemanager.compareediting" context
            var contextService = this.resolveDependency("epi.shell.ContextService");
            contextService.registerRoute("epi.cms.languagemanager.compareediting", lang.hitch(this, this._redirectContext));
        },

        _redirectContext: function (/*Object*/context, /*Object*/callerData) {
            // summary:
            //      Redirect context
            // tags:
            //      private

            this._hashWrapper.onContextChange(context, callerData);
        },

        _getCMSRestPath: function (name) {
            return routes.getRestPath({ moduleArea: "cms", storeName: name });
        },

        _getRestPath: function (name) {
            // summary:
            //      Get the rest path to a specified store.
            // prameters:
            //      name: The name of the store to get.
            // tags:
            //      private

            return routes.getRestPath({ moduleArea: "EPiServer.Labs.LanguageManager", storeName: name });
        },

        _injectCommandsToProjectView: function () {
            // summary:
            //      HACK: inject menu items [Download Translation Package] and [Upload Translation Package] into Project view
            // tags:
            //      private

            var exportingUrl = this._settings.exportingUrl;

            var orgMethod = _ProjectViewModel.prototype.postscript;

            lang.mixin(_ProjectViewModel.prototype, {
                postscript: function () {

                    orgMethod.call(this);

                    var commands = this.get("commands");
                    commands.push(
                        new DownloadTranslationPackage({
                            category: "publishmenu",
                            model: this,
                            sortOrder: 400,
                            exportingUrl: exportingUrl
                        }),
                        new UploadTranslationPackages({
                            category: "publishmenu",
                            model: new UploadTranslationPackagesViewModel(),
                            sortOrder: 500
                        })
                    );
                }
            });
        }
    });

});
