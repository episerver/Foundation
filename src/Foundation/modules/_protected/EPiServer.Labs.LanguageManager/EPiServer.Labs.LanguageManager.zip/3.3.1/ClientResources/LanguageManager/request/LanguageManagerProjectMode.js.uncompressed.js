﻿define("epi-languagemanager/request/LanguageManagerProjectMode", [
    "dojo/Deferred"
], function (Deferred) {

    return {
        beforeSend: function (params) {
            // summary:
            //      Request mutator for adding the currently selected project to a xhr request
            //      By the default, the Cms UI always sends the header key "x-EPiCurrentProject" with value is the current active project.
            //      This header value will take over the custom projectId which we want to add item to.
            //      This module will chain the request and change the header key "x-EPiCurrentProject" with our custom project-Id.
            // params: Object
            //      The request parameters
            // tags: internal

            var options = params.options;
            if (options.postData) {
                var data;
                try {
                    data = JSON.parse(options.postData);
                } catch (e) { /*quiet*/ }

                if (data && data.modifyHeader === true && data.id) {
                    options.headers["X-EPiCurrentProject"] = data.id;
                }
            }

            var result = new Deferred();
            result.resolve(params);

            return result.promise;
        }
    };

});
