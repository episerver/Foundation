﻿define("epi-languagemanager/component/viewmodel/CompareEditingViewModel", [
// Dojo
    "dojo/_base/declare",
    "dojo/_base/Deferred",
    "dojo/_base/lang",
    "dojo/promise/all",
    "dojo/when",
    "dojo/Stateful",

    //EPi Framework
    "epi/dependency",

    //CMS
    "epi/shell/_ContextMixin",
    "epi-cms/_ContentContextMixin",
    "epi-cms/contentediting/ContentViewModel"
],

function (
// Dojo
    declare,
    Deferred,
    lang,
    all,
    when,
    Stateful,

    // EPi
    dependency,

    //CMS
    _ContextMixin,
    _ContentContextMixin,
    ContentViewModel
) {

    // summary:
    //      View model object for the CompareEditing controller.
    return declare([Stateful, _ContextMixin, _ContentContextMixin], {

        // contentDataStore: [protected] Object
        //      Rest store for manipulate model data.
        contentDataStore: null,

        // contextStore: [protected] JsonRestStore
        //      Rest store for get content context.
        contextStore: null,

        // contentVersionStore: [protected] Object
        //      Rest store for get content versions.
        contentVersionStore: null,

        // languageManagerStore: [protected] JsonRestStore
        //      Rest store for translating property.
        languageManagerStore: null,

        // currentContentViewModel: [public] ContentViewModel
        //      The content view model of current content.
        currentContentViewModel: null,

        // masterContentViewModel: [public] ContentViewModel
        //      The content view model of master content.
        masterContentViewModel: null,

        // contentLinkSyncChange: [public] Boolean
        //      The flag to indicate that the current content link is changed.
        contentLinkSyncChange: false,

        // isTranslatingServiceAvailable: [public] Boolean
        //      The flag to indicate that the translating service is available or not.
        isTranslatingServiceAvailable: false,

        postscript: function () {
            // summary:
            //      Initialize stores
            // tags:
            //      protected

            this.inherited(arguments);

            var registry = dependency.resolve("epi.storeregistry");
            this.contentDataStore = this.contentDataStore || registry.get("epi.cms.contentdata");
            this.contextStore = this.contextStore || registry.get("epi.shell.context");
            this.contentVersionStore = this.contentVersionStore || registry.get("epi.cms.contentversion");
            this.languageManagerStore = this.languageManagerStore || registry.get("epi-languagemanager.language");

            when(this.languageManagerStore.executeMethod("IsTranslatingServiceAvailable", null, null),
                lang.hitch(this, function (result) {
                    this.set("isTranslatingServiceAvailable", result);
                })
            );
        },

        _isContentContext: function (ctx) {
            // summary:
            //      We change the context to "epi.cms.languagemanager.compareediting",
            //      so we need to override _ContentContextMixin._isContentContext
            // ctx: context
            //      The context to check
            // tags:
            //      protected

            return true;
        },
        _createViewModel: function (contentData, ctx) {
            // summary:
            //      Create new content view model instance.
            //      mixin contentLinkChanged method.
            // tags:
            //      private


            // Create new content view model
            var viewModel = new ContentViewModel({
                    contentLink: contentData.contentLink,
                    contextTypeName: "epi.cms.contentdata",
                    // TECHNOTE:
                    //  + Commerce use this prop to check current content language or not.
                    //      See "CatalogContentDetails.js" line 72
                    //  + CMS doesn't (CMS use isCurrentLanguage that is returned from server (contentdata)
                    //      See "ContentDetails.js" line 81
                    currentContentLanguage: ctx.languageContext.language
                }),
                self = this;

            // Update content view model
            viewModel.set("contentData", contentData);
            viewModel.set("languageContext", ctx.languageContext);

            var contentLinkChanged = function () {
                var newContentLink = viewModel.get("contentLink");
                var contentLink = newContentLink,
                    newContextParams = { uri: "epi.cms.contentdata:///" + contentLink };
                all({
                    currentContent: this.contentDataStore.get(contentLink),
                    currentContext: this.contextStore.query(newContextParams)
                }).then(function (result) {
                    var currentContent = result.currentContent,
                        currentContext = result.currentContext;

                    viewModel.set("contentData", currentContent);
                    viewModel.set("languageContext", currentContext.languageContext);
                    self.set("contentLinkSyncChange", true);
                });
            };

            viewModel.onContentLinkChange = contentLinkChanged;

            return viewModel;
        },

        _getAndUpdateViewModel: function (content, context) {
            // summary:
            //      Create and update content view model metadata.
            // tags:
            //      private

            var dfd = new Deferred();

            var viewModel = this._createViewModel(content, context);
            viewModel.reload().then(lang.hitch(this, function () {
                dfd.resolve(viewModel);
            }));

            return dfd;
        },

        getCurrentContentViewModel: function () {
            // summary:
            //      Initializer content view model of current content.
            // tags:
            //      public virtual

            var dfd = new Deferred(),
                self = this;

            // Update model then return imerdiately when already have.
            if (this.currentContentViewModel) {
                this.currentContentViewModel.reload().then(function () {
                    dfd.resolve(self.currentContentViewModel);
                });
                return dfd;
            }

            all({
                currentContent: this.getCurrentContent(),
                currentContext: this.getCurrentContext()
            }).then(function (result) {
                var currentContent = result.currentContent,
                    currentContext = result.currentContext;

                self._getAndUpdateViewModel(currentContent, currentContext).then(function (viewModel) {
                    self.currentContentViewModel = viewModel;
                    dfd.resolve(viewModel);
                });
            });

            return dfd;
        },

        getMasterContentViewModel: function () {
            // summary:
            //      Initializer content view model of master content.
            // tags:
            //      public virtual

            var dfd = new Deferred();
            // Update model then return immediately when already have.
            if (this.masterContentViewModel) {
                var masterModel = this.masterContentViewModel;
                masterModel.reload().then(function () {
                    // update masterContentViewModel
                    this.masterContentViewModel = masterModel;
                    dfd.resolve(masterModel);
                }.bind(this));
                return dfd;
            }

            var self = this;
            when(this.getCurrentContent(), function (currentContent) {
                when(self.languageManagerStore.executeMethod("GetMasterLanguageContentLink", currentContent.contentLink), function (masterVersion) {
                    all({
                        masterContent: self.contentDataStore.refresh(masterVersion),
                        masterContext: self.contextStore.query({ uri: "epi.cms.contentdata:///" + masterVersion })
                    }).then(function (result) {
                        var masterContent = result.masterContent,
                            masterContext = result.masterContext;

                        self._getAndUpdateViewModel(masterContent, masterContext).then(function (viewModel) {
                            lang.mixin(viewModel, {
                                canChangeContent: function () {
                                    return false;
                                }
                            });
                            self.masterContentViewModel = viewModel;
                            dfd.resolve(viewModel);
                        });
                    });

                });
            });

            return dfd;
        },

        contextChanged: function (ctx, callerData) {
            // summary:
            //      Listen on context changed to update model
            // tags:
            //      protected override

            this.inherited(arguments);

            // reset masterContentViewModel since the context has been chanaged.
            // this will make the CompareEditing load the new one when it is openning.
            this.masterContentViewModel = null;

            if (!this._isContentContext(ctx) || !this.currentContentViewModel) {
                return;
            }

            var self = this;
            this.getCurrentContent().then(function (currentContent) {
                self.currentContentViewModel.set("contentData", currentContent);
                self.currentContentViewModel.set("languageContext", ctx.languageContext);
                self.currentContentViewModel.set("contentLinkSyncChange", true);
            });
        }
    });
});
