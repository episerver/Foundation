define("epi-cms/contentediting/inline-editing/InlineEditBlockDialog", [
    "dojo/_base/declare",
    "epi/shell/widget/dialog/Dialog",
    "epi/i18n!epi/cms/nls/episerver.shared.action"
], function (
    declare,
    Dialog,
    actionRes
) {
    return declare([Dialog], {
        // summary:
        //      Dialog used to display inline edit form

        // saveLabel: [public] String
        //      Label for saving form
        saveLabel: actionRes.save,

        // mainCommand: [public] Object
        //      The command for changing the content's status (Publish, Ready to Publish, Ready for Review)
        mainCommand: null,

        postMixInProperties: function () {
            this.inherited(arguments);

            this.dialogClass = "epi-dialog-portrait inline-edit-dialog";

            var containerNode = document.createElement("div");
            this.content = containerNode;
            this.contentClass = "epi-wrapped epi-mediaSelector";
        },

        getActions: function () {
            var actions = this.inherited(arguments);

            var saveButton = actions[0];
            saveButton.label = this.saveLabel;

            this._mainButtonName = "mainButton";
            var mainButton = {
                name: this._mainButtonName,
                label: this.mainCommand && this.mainCommand.label,
                title: null,
                settings: {
                    "class": "epi-success main-button"
                },
                action: function () {
                    this.onMainCommand();
                }.bind(this)
            };
            if (this.mainCommand) {
                actions.push(mainButton);
            }

            return actions;
        },

        hideSaveButton: function () {
            this.definitionConsumer.setItemProperty(this._okButtonName, "class", "dijitHidden");
        },

        toggleDisabledSaveButton: function (shouldDisable) {
            this.definitionConsumer.setItemProperty(this._okButtonName, "disabled", shouldDisable ? "disabled" : "");
        },

        toggleMainButton: function (visible) {
            if (visible) {
                this.definitionConsumer.setItemProperty(this._mainButtonName, "class", "epi-success main-button");
            } else {
                this.definitionConsumer.setItemProperty(this._mainButtonName, "class", "dijitHidden");
            }
        },

        toggleDisabledMainButton: function (shouldDisable) {
            this.definitionConsumer.setItemProperty(this._mainButtonName, "disabled", shouldDisable ? "disabled" : "");
        },

        _setCloseTextAttr: function (label) {
            this.definitionConsumer.setItemProperty(this._cancelButtonName, "label", label);
        },

        onMainCommand: function () {
        }
    });
});
