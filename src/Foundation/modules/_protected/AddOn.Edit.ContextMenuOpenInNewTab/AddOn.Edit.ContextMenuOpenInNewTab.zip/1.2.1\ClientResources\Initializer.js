define([
    "dojo/_base/declare",
    "epi/_Module",
    "open-in-new-tab/ContextMenuCommandProvider"
], function(declare, _Module) {

    return declare([_Module], {});

});
